# Estado de continuidade — SRD Card Game 607

**Data:** 2026-10-10  
**Último pacote de saída gerado:** 1.5.0, lote 15, 2026-10-09.  
**Este pacote de continuidade não é a versão final das fichas/imagens.**

## O que está concluído

- Catálogo com 607 IDs preservados; os índices de fichas e imagens foram auditados com 607 IDs cada, sem duplicações ou reintrodução dos 28 homebrews próprios excluídos.
- Foram preservadas 108 fichas SRD 5.2.1 locais.
- Na versão de saída 1.5.0 há 71 fichas externas completas, 9 fichas externas parciais e 428 IDs incompletos. As 9 parciais estão dentro dos 428 incompletos.
- Foram mantidas as fontes e diferenças de sistemas de terceiros; há fichas A5E, Kobold Press e MCDM. Resumos factuais são usados quando a reprodução integral não está autorizada.
- A saída v1.5.0 verifica 16 imagens diretas e mantém 5 candidatas não verificadas; restam 591 criaturas sem imagem direta confirmada. As 5 candidatas contam dentro das 591 pendências.
- O relatório do lote 15 identifica 91 páginas individuais conhecidas, 20 ainda incompletas e 408 pendências sem página individual confirmada.

## Diferença entre a saída e o construtor atual

O arquivo `build_deliverables.py` ainda está rotulado como versão 1.5.0/lote 15, mas contém cinco imagens adicionais já verificadas manualmente: **TF-016, TF-183, TF-484, TF-487 e TF-488**. O construtor lista 21 imagens verificadas e remove essas cinco candidatas; porém, os arquivos já gerados em `outputs/` continuam na situação anterior: 16 verificadas e 5 candidatas. O próximo processo deve atualizar a versão/lote para 1.6.0/lote 16, regenerar todos os seis artefatos e o ZIP, validar as contagens e só então publicar a nova versão.

As verificações de imagem confirmam carregamento no navegador, MIME, dimensões e correspondência visual. O navegador não expôs o código HTTP numérico, portanto ele não deve ser preenchido por suposição.

## Pesquisa adicional ainda não integrada

Foram pesquisados três registros Kobold Press que estavam bloqueados por páginas com JavaScript: **KP-S002 Forest Emperor**, **KP-S004 Ychen Bannog** e **TF-007 Yann-An-Oed**. O índice oficial da editora confirma nome, publicação, porte/tipo e ND; páginas secundárias fornecem estatísticas mecânicas úteis. Esses dados estão registrados em `PESQUISA_KOBOLD_LOTE16.md`, mas não foram integrados ao JSON, DOCX ou auditoria. Yaojing/KP-S005 já aparece como ficha integrada no relatório v1.5.0; a consulta adicional de Yaojing deve ser usada apenas como conferência de discrepância, sem duplicar o registro.

Não trate uma página de referência, uma listagem de editora ou um resultado de busca como ficha completa. No caso de Forest Emperor faltam os seis valores de atributo no levantamento corrente. Para Ychen Bannog, rejeite a página oficial antiga de 2009 (Pathfinder 3.5, CR 12); a variante pertinente é 5e, Tome of Beasts 1, ND 11. Registre fontes secundárias como secundárias e mantenha o texto mecânico em resumo factual.

## Próximos passos

1. Conferir o inventário deste ZIP e comparar os artefatos no `outputs/` com o construtor.
2. Ajustar a versão para 1.6.0/lote 16, atualizar a lista de imagens confirmadas e regenerar os documentos/índices/ZIP.
3. Revisar e integrar somente os fatos que puderem ser confirmados para KP-S002, KP-S004 e TF-007; tirar os casos da lista de bloqueios apenas quando a ficha passar pelo critério de completude. Manter Yaojing/KP-S005 sem duplicação.
4. Auditar os mesmos 607 IDs, divergências de ND, publicações, sistemas, formas e estados em todos os arquivos.
5. Continuar com as pendências restantes por lotes, priorizando as páginas individuais conhecidas; pesquisar imagens em paralelo e verificar cada URL direta.
6. Atualizar arquivos e relatório ao fim de cada lote. Não declarar conclusão enquanto houver ficha incompleta ou imagem direta não verificada.

## Arquivos-base incluídos

O ZIP inclui o pacote inicial enviado para o worker, os arquivos de trabalho extraídos, o construtor, os seis artefatos de saída da versão 1.5.0 e o ZIP v1.5.0. O prompt de retomada está em `PROMPT_PROXIMO_PROCESSO.txt`.
