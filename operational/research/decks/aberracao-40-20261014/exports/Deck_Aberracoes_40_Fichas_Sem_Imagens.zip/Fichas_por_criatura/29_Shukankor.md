# Shukankor

- Posição do deck: 29/40
- Tipo: Aberração
- ND: 9
- Raridade: Incomum
- ID de catálogo: TF-283
- Origem: CATALOGO_607
- Publicação: Tome of Beasts 2
- Referência: https://koboldpress.com/tools/kobold-press-monsters/
- CA: 17
- PV: 115
- Iniciativa: +1 (DES derivada)
- Status: **FICHA DE PESQUISA NÃO VALIDADA — NÃO HOMOLOGADA**

## Habilidade de suporte selecionada (candidata)

**Beak (D)**

+10, 2d8+6 perfurante.

**Revisão:** Many Eyes beneficiaria só testes raros; dano mais aplicável.

## Mecânica disponível na fonte do pacote

Bloco estruturado de pesquisa individual; pode conter lacunas e conflitos de edição.

```json
{
  "estatisticas": {
    "armor_class": 17,
    "hit_points": 115,
    "hit_dice": "11d12+44",
    "ability_scores": {
      "STR": 22,
      "DEX": 12,
      "CON": 18,
      "INT": 8,
      "WIS": 12,
      "CHA": 6
    },
    "speeds": {
      "walk_ft": 50
    },
    "senses": {
      "darkvision_ft": 120,
      "passive_perception": 19
    },
    "skills": {
      "Athletics": 10,
      "Perception": 9
    },
    "saving_throws": [],
    "languages": [
      "Deep Speech"
    ],
    "damage_resistances": [
      {
        "types": [
          "bludgeoning",
          "piercing",
          "slashing"
        ],
        "source": "nonmagical_attacks"
      }
    ],
    "damage_immunities": [
      "poison"
    ],
    "damage_vulnerabilities": [],
    "condition_immunities": [
      "poisoned"
    ],
    "armor_class_type": "natural_armor",
    "ability_modifiers": {
      "STR": 6,
      "DEX": 1,
      "CON": 4,
      "INT": -1,
      "WIS": 1,
      "CHA": -2
    }
  },
  "mecanicas": {
    "traits": [
      {
        "name": "Many Eyes",
        "category": "advantage",
        "skill_checks": {
          "Perception": "when_relying_on_sight"
        },
        "saving_throws": {
          "vs_blinded": true
        }
      },
      {
        "name": "Self-made Pack",
        "category": "conditional_attack_advantage",
        "condition": {
          "one_or_more_of_own_replicas_within_ft_of_target": 5,
          "replica_not_incapacitated": true
        }
      }
    ],
    "actions": [
      {
        "name": "Multiattack",
        "category": "multiattack",
        "action_economy": "action",
        "sequence": [
          {
            "attack": "Beak",
            "count": 1
          },
          {
            "attack": "Claws",
            "count": 2
          }
        ]
      },
      {
        "name": "Beak",
        "category": "attack",
        "action_economy": "action",
        "attack_type": "melee_weapon",
        "attack_bonus": 10,
        "reach_ft": 10,
        "targets": {
          "count": 1
        },
        "hit": {
          "damage": [
            {
              "dice": "2d8",
              "flat": 6,
              "average": 15,
              "type": "piercing"
            }
          ]
        }
      },
      {
        "name": "Claws",
        "category": "attack",
        "action_economy": "action",
        "attack_type": "melee_weapon",
        "attack_bonus": 10,
        "reach_ft": 5,
        "targets": {
          "count": 1
        },
        "hit": {
          "damage": [
            {
              "dice": "2d6",
              "flat": 6,
              "average": 13,
              "type": "slashing"
            }
          ]
        }
      },
      {
        "name": "Duplicating Terror",
        "category": "summon_replicas",
        "action_economy": "action",
        "uses_per_day": 1,
        "spawn_count": 4,
        "replica_statblock": "axe beak",
        "trait_overrides": [
          "Many Eyes",
          "Self-made Pack"
        ],
        "control": {
          "telepathy_ft": 120,
          "replicas_allies": true,
          "obey_commands": true
        },
        "duration": "until_killed_or_dismissed",
        "dismiss_cost": "bonus_action",
        "on_death_or_dismiss": "replica_disintegrates_to_green_goo",
        "after_hours_alive": 24,
        "then": {
          "control_link_severed": true,
          "replica_becomes_independent": true,
          "after_additional_time": "1_month",
          "matures_to": "full_shukankor"
        }
      }
    ],
    "bonus_actions": [
      {
        "name": "Dismiss Duplicating Terror replicas",
        "category": "dismiss_summons",
        "action_economy": "bonus_action",
        "precondition": "one_or_more_replica_alive_and_bound",
        "effect": "dismiss_replicas"
      }
    ],
    "reactions": [
      {
        "name": "Sacrifice Replica",
        "category": "redirect_attack",
        "action_economy": "reaction",
        "trigger": "visible_creature_targets_shukankor_with_attack",
        "require_replica_within_ft": 5,
        "redirect_target": "chosen_replica",
        "replica_becomes_attack_target": true
      }
    ],
    "legendary_actions": [],
    "lair_actions": [],
    "mythic_actions": [],
    "spellcasting": [],
    "other": [
      {
        "name": "Axe beak dependency",
        "category": "external_statblock",
        "creature": "axe_beak",
        "mechanical_details_referenced_not_embedded": true
      }
    ]
  }
}
```

### Observações

Esta é uma ficha de pesquisa; a existência de informações não comprova a homologação. A ativação da carta de suporte não gasta ação, seus efeitos seguem SRD e ficha original e a carta utilizada vai para a pilha de descarte. Não inferir condições nem números ausentes.
