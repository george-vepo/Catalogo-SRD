# Astral Snapper

- Posição do deck: 11/40
- Tipo: Aberração
- ND: 3
- Raridade: Comum
- ID de catálogo: TF-004
- Origem: CATALOGO_607
- Publicação: Creature Codex
- Referência: https://koboldpress.com/tools/kobold-press-monsters/
- CA: 12
- PV: 78
- Iniciativa: Não confirmada neste registro
- Status: **FICHA DE PESQUISA NÃO VALIDADA — NÃO HOMOLOGADA**

## Habilidade de suporte selecionada (candidata)

**Claws (D)**

+4, 2d6+2 cortante.

**Revisão:** Substitui Astral Devour (parasitismo fora do fluxo de turno); ficha parcial.

## Mecânica disponível na fonte do pacote

Bloco estruturado de pesquisa individual; pode conter lacunas e conflitos de edição.

```json
{
  "estatisticas": {
    "armor_class": 12,
    "hit_points": 78,
    "hit_dice": "12d8+24",
    "ability_scores": {
      "STR": 12,
      "DEX": 15,
      "CON": 14,
      "INT": 12,
      "WIS": 16,
      "CHA": 8
    },
    "speeds": "40 ft.",
    "senses": [
      "darkvision 60 ft."
    ],
    "skills": {
      "Arcana": 4,
      "Deception": 1,
      "Perception": 5,
      "Stealth": 4
    },
    "saving_throws": {
      "CON": 4
    },
    "languages": [
      "Deep Speech"
    ],
    "damage_resistances": [
      "bludgeoning n?o m?gico",
      "slashing n?o m?gico"
    ],
    "damage_immunities": null,
    "damage_vulnerabilities": null,
    "condition_immunities": null
  },
  "mecanicas": {
    "traits": [
      {
        "name": "Astral Devour",
        "category": "passive",
        "previous_summary_for_context": "Hospedeiro submetido a Sabedoria CD 13 ap?s descansos longos: sucesso expulsa criatura ao Plano Material e deixa atordoada por 1 rodada; falha reduz Constitui??o em 1d4, levando ? morte se chegar a 0. Ao sair, redu??o dura at? descanso longo ap?s expuls?o.",
        "status": "PENDENTE_ESTRUTURACAO_INTEGRAL",
        "attack_bonus": null,
        "range": null,
        "target": null,
        "damage": null,
        "save_dc": null,
        "save_ability": null,
        "conditions": null,
        "duration": null,
        "recharge": null,
        "trigger": null,
        "uses": null
      }
    ],
    "actions": [
      {
        "name": "Multiattack",
        "category": "action",
        "previous_summary_for_context": "Dois ataques com Claws; se ambos acertarem mesmo alvo, Sabedoria CD 13 ou ferida forma passagem astral e ativa Astral Devour.",
        "status": "PENDENTE_ESTRUTURACAO_INTEGRAL",
        "attack_bonus": null,
        "range": null,
        "target": null,
        "damage": null,
        "save_dc": null,
        "save_ability": null,
        "conditions": null,
        "duration": null,
        "recharge": null,
        "trigger": null,
        "uses": null
      },
      {
        "name": "Claws",
        "category": "action",
        "previous_summary_for_context": "Ataque corpo a corpo +4, alcance 5 ft.; 2d6+2 cortante.",
        "status": "PENDENTE_ESTRUTURACAO_INTEGRAL",
        "attack_bonus": null,
        "range": null,
        "target": null,
        "damage": null,
        "save_dc": null,
        "save_ability": null,
        "conditions": null,
        "duration": null,
        "recharge": null,
        "trigger": null,
        "uses": null
      }
    ],
    "bonus_actions": null,
    "reactions": null,
    "legendary_actions": null,
    "lair_actions": null,
    "spellcasting": null,
    "other": null
  }
}
```

### Observações

Esta é uma ficha de pesquisa; a existência de informações não comprova a homologação. A ativação da carta de suporte não gasta ação, seus efeitos seguem SRD e ficha original e a carta utilizada vai para a pilha de descarte. Não inferir condições nem números ausentes.
