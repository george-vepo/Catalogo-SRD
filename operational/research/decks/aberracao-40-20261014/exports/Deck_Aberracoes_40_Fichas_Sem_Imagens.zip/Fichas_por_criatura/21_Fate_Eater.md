# Fate Eater

- Posição do deck: 21/40
- Tipo: Aberração
- ND: 6
- Raridade: Incomum
- ID de catálogo: TF-279
- Origem: CATALOGO_607
- Publicação: Tome of Beasts 1
- Referência: https://koboldpress.com/tools/kobold-press-monsters/
- CA: 16
- PV: 130
- Iniciativa: +1 (DES derivada)
- Status: **FICHA DE PESQUISA NÃO VALIDADA — NÃO HOMOLOGADA**

## Habilidade de suporte selecionada (candidata)

**Alter Fate (E/D)**

Carisma CD 15; na falha, 8d8 psíquico e efeito de destino sorteado 1d6, conforme ficha.

**Revisão:** Recarga 5–6; não simplificar tabela de efeitos.

## Mecânica disponível na fonte do pacote

Bloco estruturado de pesquisa individual; pode conter lacunas e conflitos de edição.

```json
{
  "estatisticas": {
    "armor_class": 16,
    "hit_points": 130,
    "hit_dice": "20d8+40",
    "ability_scores": {
      "STR": 18,
      "DEX": 12,
      "CON": 14,
      "INT": 18,
      "WIS": 16,
      "CHA": 9
    },
    "speeds": {
      "walk_ft": 40,
      "climb_ft": 40
    },
    "senses": {
      "truesight_ft": 60,
      "passive_perception": 13
    },
    "skills": {
      "Arcana": 7,
      "History": 7,
      "Insight": 6,
      "Religion": 7
    },
    "saving_throws": {
      "CON": 5
    },
    "languages": {
      "understands": "all_languages",
      "can_speak": false,
      "telepathy_ft": 100
    },
    "damage_resistances": [],
    "damage_immunities": [],
    "damage_vulnerabilities": [],
    "condition_immunities": [
      "charmed",
      "frightened"
    ],
    "armor_class_type": "natural_armor",
    "ability_modifiers": {
      "STR": 4,
      "DEX": 1,
      "CON": 2,
      "INT": 4,
      "WIS": 3,
      "CHA": -1
    }
  },
  "mecanicas": {
    "traits": [
      {
        "name": "Visionary Flesh",
        "category": "postmortem_consumption",
        "trigger": "consumes_fate_eater_flesh",
        "save": {
          "ability": "CON",
          "dc": 15
        },
        "failure": {
          "condition": "poisoned",
          "duration": "1_hour"
        },
        "success": {
          "spell_effect": "divination",
          "details": "spell reference not fully transcribed"
        }
      }
    ],
    "actions": [
      {
        "name": "Multiattack",
        "category": "multiattack",
        "action_economy": "action",
        "sequence": [
          {
            "attack": "Bite",
            "count": 2
          }
        ]
      },
      {
        "name": "Bite",
        "category": "attack",
        "action_economy": "action",
        "attack_type": "melee_weapon",
        "attack_bonus": 7,
        "reach_ft": 5,
        "targets": {
          "count": 1
        },
        "hit": {
          "damage": [
            {
              "dice": "2d8",
              "flat": 4,
              "average": 13,
              "type": "slashing"
            },
            {
              "dice": "2d6",
              "flat": 0,
              "average": 7,
              "type": "necrotic"
            }
          ]
        },
        "miss": {
          "damage": 0
        }
      },
      {
        "name": "Alter Fate",
        "category": "save_random_effect",
        "action_economy": "action",
        "recharge": "5-6",
        "target": {
          "count": 1,
          "visible": true,
          "range_ft": 30
        },
        "save": {
          "ability": "CHA",
          "dc": 15,
          "on_failure": {
            "damage": [
              {
                "dice": "8d8",
                "average": 36,
                "type": "psychic"
              }
            ],
            "random_effect": "1d6"
          },
          "on_success": {
            "damage_multiplier": 0.5,
            "no_random_effect": true
          }
        },
        "outcomes": [
          {
            "roll": 1,
            "name": "Forgotten Training",
            "duration": "1_minute",
            "effect": "lose_one_random_class_feature"
          },
          {
            "roll": 2,
            "name": "Lost Potential",
            "duration": null,
            "effect": "reduce_one_random_ability_score_by_2"
          },
          {
            "roll": 3,
            "name": "Seeing the Alternates",
            "duration": "1_minute",
            "condition": "incapacitated"
          },
          {
            "roll": 4,
            "name": "Shifting Memories",
            "duration": null,
            "effect": "lose_one_random_skill_proficiency_gain_another_random_skill_proficiency"
          },
          {
            "roll": 5,
            "name": "Took the Lesser Path",
            "duration": null,
            "effect": "current_hp_becomes_current_maximum_hp"
          },
          {
            "roll": 6,
            "name": "Untied from the Loop",
            "duration": "1_minute",
            "effect": "movement_direction_random"
          }
        ],
        "repeat_save": {
          "short_effects": "end_of_each_affected_turn",
          "other_effects": "end_of_each_long_rest",
          "ability": "CHA",
          "dc": 15,
          "success_ends": true
        }
      }
    ],
    "bonus_actions": [],
    "reactions": [],
    "legendary_actions": [],
    "lair_actions": [],
    "mythic_actions": [],
    "spellcasting": [],
    "other": [
      {
        "name": "Divination spell",
        "category": "external_rule_dependency",
        "verified_spell_effects": false
      }
    ]
  }
}
```

### Observações

Esta é uma ficha de pesquisa; a existência de informações não comprova a homologação. A ativação da carta de suporte não gasta ação, seus efeitos seguem SRD e ficha original e a carta utilizada vai para a pilha de descarte. Não inferir condições nem números ausentes.
