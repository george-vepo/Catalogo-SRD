# Voidling

- Posição do deck: 34/40
- Tipo: Aberração
- ND: 11
- Raridade: Rara
- ID de catálogo: TF-018
- Origem: CATALOGO_607
- Publicação: Tome of Beasts 1
- Referência: https://koboldpress.com/tools/kobold-press-monsters/
- CA: 15
- PV: 180
- Iniciativa: Não confirmada neste registro
- Status: **FICHA DE PESQUISA NÃO VALIDADA — NÃO HOMOLOGADA**

## Habilidade de suporte selecionada (candidata)

**Shadow's Grasp (E/D)**

Destreza CD 17; 14d6 necrótico e Contido na falha, conforme ficha.

**Revisão:** Recarga 5–6, duração/testes, edição.

## Mecânica disponível na fonte do pacote

Bloco estruturado de pesquisa individual; pode conter lacunas e conflitos de edição.

```json
{
  "estatisticas": {
    "armor_class": 15,
    "hit_points": 180,
    "hit_dice": "24d10+48",
    "ability_scores": {
      "STR": 15,
      "DEX": 21,
      "CON": 15,
      "INT": 14,
      "WIS": 16,
      "CHA": 10
    },
    "speeds": {
      "andar_ft": 0,
      "voar_ft": 50,
      "hover": true
    },
    "senses": [
      "truesight 60 ft."
    ],
    "skills": {
      "Stealth": 9
    },
    "saving_throws": {
      "CON": 6,
      "INT": 6,
      "WIS": 7,
      "CHA": 4
    },
    "languages": [
      "Void Speech",
      "telepathy 60 ft."
    ],
    "damage_resistances": null,
    "damage_immunities": [
      "necrotic"
    ],
    "damage_vulnerabilities": [
      "radiant"
    ],
    "condition_immunities": [
      "exhaustion",
      "petrified",
      "prone"
    ]
  },
  "mecanicas": {
    "traits": [
      {
        "name": "Darkness Regeneration",
        "kind": "passive",
        "legacy_summary": "Recupera 5 PV no início do turno em penumbra/trevas, desde que esteja vivo.",
        "status": "INCOMPLETA",
        "attack_bonus": null,
        "range": null,
        "targets": null,
        "damage": null,
        "dc": null,
        "save": null,
        "conditions": null,
        "duration": null,
        "recharge": null,
        "uses": null
      },
      {
        "name": "Magic Resistance",
        "kind": "passive",
        "legacy_summary": "Vantagem em salvaguardas contra magia.",
        "status": "INCOMPLETA",
        "attack_bonus": null,
        "range": null,
        "targets": null,
        "damage": null,
        "dc": null,
        "save": null,
        "conditions": null,
        "duration": null,
        "recharge": null,
        "uses": null
      },
      {
        "name": "Void Traveler",
        "kind": "passive",
        "legacy_summary": "Não necessita de ar, alimento, líquidos, sono ou pressão ambiente.",
        "status": "INCOMPLETA",
        "attack_bonus": null,
        "range": null,
        "targets": null,
        "damage": null,
        "dc": null,
        "save": null,
        "conditions": null,
        "duration": null,
        "recharge": null,
        "uses": null
      }
    ],
    "actions": [
      {
        "name": "Multiattack",
        "kind": "action",
        "legacy_summary": "Quatro ataques, alternando Shadow Tendril ou Necrotic Bolt. Se dois projéteis acertarem mesmo alvo, SAB CD 17 ou medo até fim do próximo turno.",
        "status": "INCOMPLETA",
        "attack_bonus": null,
        "range": null,
        "targets": null,
        "damage": null,
        "dc": null,
        "save": null,
        "conditions": null,
        "duration": null,
        "recharge": null,
        "uses": null
      },
      {
        "name": "Shadow Tendril",
        "kind": "action",
        "legacy_summary": "+9; 10 ft.; 1d6+5 contundente e 3d6 necrótico.",
        "status": "INCOMPLETA",
        "attack_bonus": null,
        "range": null,
        "targets": null,
        "damage": null,
        "dc": null,
        "save": null,
        "conditions": null,
        "duration": null,
        "recharge": null,
        "uses": null
      },
      {
        "name": "Necrotic Bolt",
        "kind": "action",
        "legacy_summary": "+7; 120 ft.; 4d6+3 necrótico.",
        "status": "INCOMPLETA",
        "attack_bonus": null,
        "range": null,
        "targets": null,
        "damage": null,
        "dc": null,
        "save": null,
        "conditions": null,
        "duration": null,
        "recharge": null,
        "uses": null
      },
      {
        "name": "Shadow's Grasp",
        "kind": "action",
        "legacy_summary": "Recarga 5–6; DES CD 17 em 20 ft., 14d6 necrótico e restrição por até 1 minuto; sucesso reduz pela metade sem restrição.",
        "status": "INCOMPLETA",
        "attack_bonus": null,
        "range": null,
        "targets": null,
        "damage": null,
        "dc": null,
        "save": null,
        "conditions": null,
        "duration": null,
        "recharge": null,
        "uses": null
      }
    ],
    "bonus_actions": null,
    "reactions": null,
    "legendary_actions": null,
    "lair_actions": null,
    "spellcasting": null,
    "other": null
  }
}
```

### Observações

Esta é uma ficha de pesquisa; a existência de informações não comprova a homologação. A ativação da carta de suporte não gasta ação, seus efeitos seguem SRD e ficha original e a carta utilizada vai para a pilha de descarte. Não inferir condições nem números ausentes.
