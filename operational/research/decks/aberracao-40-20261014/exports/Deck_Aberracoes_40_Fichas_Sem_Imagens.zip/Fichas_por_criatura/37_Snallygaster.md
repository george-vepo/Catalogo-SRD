# Snallygaster

- Posição do deck: 37/40
- Tipo: Aberração
- ND: 15
- Raridade: Rara
- ID de catálogo: TF-285
- Origem: CATALOGO_607
- Publicação: Tome of Beasts 3
- Referência: https://www.5esrd.com/database/creature/snallygaster/
- CA: 16
- PV: 207
- Iniciativa: Não confirmada neste registro
- Status: **FICHA DE PESQUISA NÃO VALIDADA — NÃO HOMOLOGADA**

## Habilidade de suporte selecionada (candidata)

**Regeneration (Cura→Ativa)**

Proposta: a criatura ativa recupera 15 PV no início do seu turno se tiver pelo menos 1 PV e o efeito de suporte ainda estiver ativo conforme fonte/SRD; respeitar limite dos PV máximos.

**Revisão:** Ícone: Cura verde. A ativação da carta não tem custo; duração e acúmulo seguem a ficha/SRD e a carta vai ao descarte. Ficha local TF-285 segue incompleta, embora a Regeneration esteja documentada na fonte pública.

## Mecânica disponível na fonte do pacote

Bloco estruturado de pesquisa individual; pode conter lacunas e conflitos de edição.

```json
{
  "estatisticas": {
    "nd_catalogo": "15",
    "nd_fonte": "15",
    "ca": 16,
    "pv": 207,
    "dados_vida": null,
    "porte": null,
    "tipo": null,
    "alinhamento": null,
    "atributos": null,
    "modificadores": null,
    "deslocamentos": null,
    "pericias": null,
    "salvaguardas": null,
    "sentidos": null,
    "percepcao_passiva": null,
    "idiomas": null,
    "resistencias": null,
    "imunidades_dano": null,
    "imunidades_condicao": null,
    "vulnerabilidades": null
  },
  "mecanicas": {
    "tracos": null,
    "acoes": null,
    "ataques": [],
    "multiataque": null,
    "acoes_bonus": null,
    "reacoes": null,
    "acoes_lendarias": null,
    "acoes_covil": null,
    "conjuracao": [],
    "custos_lendarios": null
  }
}
```

### Observações

Esta é uma ficha de pesquisa; a existência de informações não comprova a homologação. A ativação da carta de suporte não gasta ação, seus efeitos seguem SRD e ficha original e a carta utilizada vai para a pilha de descarte. Não inferir condições nem números ausentes.
