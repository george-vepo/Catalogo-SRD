# Xhkarsh

- Posição do deck: 30/40
- Tipo: Aberração
- ND: 9
- Raridade: Incomum
- ID de catálogo: TF-012
- Origem: CATALOGO_607
- Publicação: Tome of Beasts 1
- Referência: https://koboldpress.com/tools/kobold-press-monsters/
- CA: 18
- PV: 171
- Iniciativa: Não confirmada neste registro
- Status: **FICHA DE PESQUISA NÃO VALIDADA — NÃO HOMOLOGADA**

## Habilidade de suporte selecionada (candidata)

**Fate-Altering Stinger (E/D)**

+8, 2d10+4 perfurante; Carisma CD 16 pode corromper o destino.

**Revisão:** Fixar edição 2023 antes de executar.

## Mecânica disponível na fonte do pacote

Bloco estruturado de pesquisa individual; pode conter lacunas e conflitos de edição.

```json
{
  "estatisticas": {
    "armor_class": 18,
    "hit_points": 171,
    "hit_dice": "18d10+72",
    "ability_scores": {
      "STR": 17,
      "DEX": 19,
      "CON": 18,
      "INT": 15,
      "WIS": 16,
      "CHA": 15
    },
    "speeds": {
      "andar_ft": 50,
      "escalar_ft": 30
    },
    "senses": [
      "darkvision 60 ft.",
      "tremorsense 120 ft."
    ],
    "skills": {
      "Insight": 7,
      "Perception": 7,
      "Stealth": 8
    },
    "saving_throws": {
      "CHA": 6
    },
    "languages": [
      "Common",
      "Deep Speech",
      "Undercommon",
      "telepathy 60 ft."
    ],
    "damage_resistances": null,
    "damage_immunities": null,
    "damage_vulnerabilities": null,
    "condition_immunities": null
  },
  "mecanicas": {
    "traits": [
      {
        "name": "Corruption's Bond",
        "kind": "passive",
        "legacy_summary": "Mantém localização, saúde e telepatia sem limite de distância com alvos cujo destino tenha corrompido, inclusive em outros planos.",
        "status": "INCOMPLETA",
        "attack_bonus": null,
        "range": null,
        "targets": null,
        "damage": null,
        "dc": null,
        "save": null,
        "conditions": null,
        "duration": null,
        "recharge": null,
        "uses": null
      },
      {
        "name": "Interdimensional Nature",
        "kind": "passive",
        "legacy_summary": "Dispensa ar, alimentação, líquidos, sono e pressão ambiente.",
        "status": "INCOMPLETA",
        "attack_bonus": null,
        "range": null,
        "targets": null,
        "damage": null,
        "dc": null,
        "save": null,
        "conditions": null,
        "duration": null,
        "recharge": null,
        "uses": null
      }
    ],
    "actions": [
      {
        "name": "Multiattack",
        "kind": "action",
        "legacy_summary": "Dois ataques com garras e uma ferroada alteradora do destino.",
        "status": "INCOMPLETA",
        "attack_bonus": null,
        "range": null,
        "targets": null,
        "damage": null,
        "dc": null,
        "save": null,
        "conditions": null,
        "duration": null,
        "recharge": null,
        "uses": null
      },
      {
        "name": "Claw",
        "kind": "action",
        "legacy_summary": "+8; 5 ft.; 2d8+4 cortante mais 2d8 veneno.",
        "status": "INCOMPLETA",
        "attack_bonus": null,
        "range": null,
        "targets": null,
        "damage": null,
        "dc": null,
        "save": null,
        "conditions": null,
        "duration": null,
        "recharge": null,
        "uses": null
      },
      {
        "name": "Fate-Altering Stinger",
        "kind": "action",
        "legacy_summary": "+8; 5 ft.; 2d10+4 perfurante e salvaguarda CAR CD 16, impondo corrupção do destino e impedimentos a adivinhação/detecção até magia apropriada.",
        "status": "INCOMPLETA",
        "attack_bonus": null,
        "range": null,
        "targets": null,
        "damage": null,
        "dc": null,
        "save": null,
        "conditions": null,
        "duration": null,
        "recharge": null,
        "uses": null
      },
      {
        "name": "Invisibility",
        "kind": "action",
        "legacy_summary": "Torna-se invisível até atacar, usar Seize Strand ou perder concentração.",
        "status": "INCOMPLETA",
        "attack_bonus": null,
        "range": null,
        "targets": null,
        "damage": null,
        "dc": null,
        "save": null,
        "conditions": null,
        "duration": null,
        "recharge": null,
        "uses": null
      },
      {
        "name": "Seize Strand",
        "kind": "action",
        "legacy_summary": "Alvo corrompido faz CAR CD 16; falha produz efeito análogo a geas por 8 horas; uso contra mesmo alvo no máximo uma vez por 24 horas.",
        "status": "INCOMPLETA",
        "attack_bonus": null,
        "range": null,
        "targets": null,
        "damage": null,
        "dc": null,
        "save": null,
        "conditions": null,
        "duration": null,
        "recharge": null,
        "uses": null
      }
    ],
    "bonus_actions": null,
    "reactions": null,
    "legendary_actions": null,
    "lair_actions": null,
    "spellcasting": null,
    "other": null
  }
}
```

### Observações

Esta é uma ficha de pesquisa; a existência de informações não comprova a homologação. A ativação da carta de suporte não gasta ação, seus efeitos seguem SRD e ficha original e a carta utilizada vai para a pilha de descarte. Não inferir condições nem números ausentes.
