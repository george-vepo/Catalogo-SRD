# Astral Devourer

- Posição do deck: 27/40
- Tipo: Aberração
- ND: 8
- Raridade: Incomum
- ID de catálogo: TF-009
- Origem: CATALOGO_607
- Publicação: Tome of Beasts 2
- Referência: https://www.5esrd.com/database/creature/astral-devourer/
- CA: 16
- PV: 90
- Iniciativa: +3
- Status: **RESUMO DE PESQUISA (NÃO INTEGRAL) — NÃO HOMOLOGADA**

## Habilidade de suporte selecionada (candidata)

**Serpent Spray (Cura→Ativa; dano associado)**

Destreza CD 16; 4d6 perfurante + 4d6 veneno na falha, metade no sucesso. A criatura ativa recuperaria PV iguais ao maior dano perfurante individual efetivamente causado pelo spray (proposta de transferência).

**Revisão:** Ícone: Cura verde. Recarga 6; efeito misto dano + cura; sem cura se não houver dano perfurante causado; a transferência é homebrew não homologado.

## Mecânica disponível na fonte do pacote

Resumo mecânico próprio coletado em fontes secundárias; não é ficha integral.

```json
{
  "fonte_publicacao": "Tome of Beasts 2",
  "editora_fonte": "Kobold Press / Open Design LLC",
  "sistema": "D&D 5e; metadados confirmados no índice oficial Kobold Press; bloco mecânico consultado em transcrições secundárias.",
  "terreno_fonte": [
    "Badlands",
    "Planar"
  ],
  "porte": "Medium",
  "tipo_fonte": "swarm of Tiny aberrations",
  "alinhamento": "chaotic evil",
  "nd_fonte": "8",
  "ca": 16,
  "ca_base": "natural armor",
  "pv": 90,
  "formula_pv": "12d8 + 36",
  "deslocamento": {
    "walk_ft": 30,
    "fly_ft": 30,
    "fly_hover": true,
    "swim_ft": 30
  },
  "salvaguardas": {
    "DEX": 6,
    "INT": 5
  },
  "pericias": {
    "Perception": 6,
    "Stealth": 6
  },
  "resistencias_dano": [
    "bludgeoning",
    "piercing",
    "slashing"
  ],
  "imunidades_dano": [
    "poison",
    "psychic"
  ],
  "vulnerabilidades_dano": [],
  "imunidades_condicao": [
    "grappled",
    "paralyzed",
    "petrified",
    "poisoned",
    "prone",
    "restrained",
    "stunned"
  ],
  "sentidos": [
    "darkvision 60 ft."
  ],
  "percepcao_passiva": 16,
  "idiomas": [
    "Deep Speech",
    "Void Speech"
  ],
  "bonus_proficiencia": 3,
  "bonus_proficiencia_origem": "derivado do ND 8 pela progressão de D&D 5e; não aparece como campo separado nas transcrições consultadas",
  "tracos": [
    {
      "nome": "Collective Mind",
      "resumo_mecanico": "Os indivíduos que formam o enxame compartilham uma mente. Pode comunicar-se telepaticamente com qualquer serpente individual a até 1 mile e não pode ser surpreendido."
    },
    {
      "nome": "Magic Resistance",
      "resumo_mecanico": "Tem vantagem em salvaguardas contra magias e outros efeitos mágicos."
    },
    {
      "nome": "Swarm",
      "resumo_mecanico": "Pode ocupar o espaço de outra criatura, e vice-versa, e atravessar qualquer abertura que caiba uma serpente Tiny. Não recupera PV nem recebe PV temporários, exceto por Serpent Spray e Recombine."
    }
  ],
  "acoes": [
    {
      "nome": "Multiattack",
      "resumo_mecanico": "Faz dois ataques corpo a corpo."
    },
    {
      "nome": "Hungering Serpents",
      "resumo_mecanico": "Ataque corpo a corpo +7, alcance 0 ft., contra um alvo no espaço do enxame; causa 8 (2d8) piercing e 14 (4d6) poison. Com metade dos PV ou menos, o dano piercing passa a 4 (1d8). A transcrição da página impressa registra média 8 para 2d8; Robinloft calcula 9.",
      "ataque": "+7",
      "alcance": "0 ft.",
      "dano": [
        {
          "dados": "2d8 (ou 1d8 com metade dos PV ou menos)",
          "tipo": "piercing; média impressa 8"
        },
        {
          "dados": "4d6",
          "tipo": "poison"
        }
      ]
    },
    {
      "nome": "Serpent Spray (Recharge 6)",
      "resumo_mecanico": "Arremessa serpentes astrais. Cada criatura a até 20 ft. faz salvaguarda de Destreza CD 16; sofre 14 (4d6) piercing e 14 (4d6) poison em falha, ou metade do dano em sucesso. Recupera PV iguais ao maior valor individual de dano piercing causado pelo spray.",
      "uso": "Recharge 6",
      "salvaguarda": "Dexterity DC 16",
      "alcance": "20 ft.",
      "dano": [
        {
          "dados": "4d6",
          "tipo": "piercing"
        },
        {
          "dados": "4d6",
          "tipo": "poison"
        }
      ]
    }
  ],
  "acoes_bonus": [],
  "reacoes": [
    {
      "nome": "Divide",
      "resumo_mecanico": "Quando sofre dano bludgeoning, piercing ou slashing e tem ao menos 10 PV, se for Small ou maior pode dividir-se em dois devourers novos. Cada um recebe metade dos PV originais (arredondada para baixo), fica uma categoria de tamanho menor e compartilha mente coletiva com o outro enquanto separados por até 1 mile."
    },
    {
      "nome": "Recombine",
      "resumo_mecanico": "Quando um ou mais devourers Small ou menores da mesma mente coletiva estão a até 5 ft. entre si, podem combinar-se. A nova criatura fica uma categoria de tamanho maior que a maior forma original e soma os PV; o total não pode exceder o máximo normal de PV de um devourer Medium."
    }
  ],
  "conjuracao": null,
  "secoes_nao_listadas": [
    "vulnerabilidades de dano",
    "ações bônus",
    "ações lendárias",
    "ações míticas",
    "ações de covil",
    "conjuração"
  ],
  "fontes_adicionais": [
    {
      "titulo": "Índice oficial Kobold Press 5e",
      "url": "https://koboldpress.com/tools/kobold-press-monsters/"
    },
    {
      "titulo": "Produto oficial Tome of Beasts 2 (5e)",
      "url": "https://koboldpress.com/kpstore/product/tome-of-beasts-2-for-5th-edition-hardcover-pdf/"
    },
    {
      "titulo": "Cópia secundária da página impressa A29",
      "url": "https://fliphtml5.com/rboli/yddi/kobold-press-tome-of-beasts-2-5e2020pdf_compress/32/"
    },
    {
      "titulo": "5eSRD (página individual exige JavaScript)",
      "url": "https://www.5esrd.com/database/creature/astral-devourer/"
    },
    {
      "titulo": "Robinloft (secundária; divergências mecânicas)",
      "url": "https://www.robinloft.com/monsters/astral-devourer/tome-of-beasts-2"
    }
  ],
  "classe_fonte": "O índice oficial confirma D&D 5e, Tome of Beasts 2, Medium Aberration e ND 8. A mecânica vem de D&D Grove e de cópia secundária da página impressa A29; 5eSRD exige JavaScript. A impressão registra Challenge 8, dano médio 8 e resistências B/P/S sem qualificador; Robinloft diverge (CR 5 próprio, média 9 para 2d8 e resistência só contra ataques não mágicos). Natação 30 ft. aparece na impressão e no resultado indexado 5eSRD, mas é omitida por Grove/Robinloft.",
  "completa": true,
  "variante": "Medium swarm of Tiny aberrations, D&D 5e, Tome of Beasts 2; não confundir com outras criaturas chamadas Astral Devourer.",
  "atributos": {
    "FOR": {
      "valor": 13,
      "modificador": 1
    },
    "DES": {
      "valor": 16,
      "modificador": 3
    },
    "CON": {
      "valor": 17,
      "modificador": 3
    },
    "INT": {
      "valor": 14,
      "modificador": 2
    },
    "SAB": {
      "valor": 16,
      "modificador": 3
    },
    "CAR": {
      "valor": 12,
      "modificador": 1
    }
  },
  "iniciativa": {
    "modificador_base_des": 3,
    "valor_formatado": "+3",
    "origem": "derivada do modificador de Destreza; fonte não informa bônus adicional"
  },
  "fonte_url": "https://www.dndgrove.com/bestiary/8/astral-devourer",
  "data_verificacao": "2026-10-10",
  "secoes_cobertas": [
    "identidade",
    "porte",
    "tipo",
    "ND",
    "CA",
    "PV e fórmula",
    "deslocamento",
    "atributos e modificadores",
    "salvaguardas",
    "perícias",
    "sentidos",
    "idiomas",
    "defesas",
    "traços",
    "ações",
    "recursos e recargas",
    "CDs e condições",
    "reações"
  ],
  "secoes_nao_listadas_na_fonte": [
    "vulnerabilidades de dano",
    "ações bônus",
    "ações lendárias",
    "ações míticas",
    "ações de covil",
    "conjuração"
  ],
  "transcricao_integral": false,
  "observacao_direitos": "Fatos mecânicos e resumo próprio; sem reprodução integral da redação externa."
}
```

### Observações

Esta é uma ficha de pesquisa; a existência de informações não comprova a homologação. A ativação da carta de suporte não gasta ação, seus efeitos seguem SRD e ficha original e a carta utilizada vai para a pilha de descarte. Não inferir condições nem números ausentes.
