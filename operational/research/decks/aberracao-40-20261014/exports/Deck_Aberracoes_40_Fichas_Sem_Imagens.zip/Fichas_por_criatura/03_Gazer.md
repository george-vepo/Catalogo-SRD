# Gazer

- Posição do deck: 3/40
- Tipo: Aberração
- ND: 1/2
- Raridade: Comum
- ID de catálogo: Não atribuído — externa
- Origem: CANDIDATO_EXTERNO_NAO_APROVADO
- Publicação: Mordenkainen Presents: Monsters of the Multiverse
- Referência: https://www.dndbeyond.com/monsters?page=4&sort=type
- CA: Não confirmada neste registro
- PV: Não confirmados neste registro
- Iniciativa: Não confirmada neste registro
- Status: **EXTERNA — SEM FICHA — NÃO HOMOLOGADA**

## Habilidade de suporte selecionada (candidata)

**Eye Rays (E/D)**

Dois raios determinados aleatoriamente, com controle/dano conforme edição.

**Revisão:** Ficha externa; sortear raios, não escolher livremente.

## Mecânica disponível na fonte do pacote

Não existe bloco mecânico recuperado neste pacote. Não criar poderes ou números para completar.

```json
{}
```

### Observações

Esta é uma ficha de pesquisa; a existência de informações não comprova a homologação. A ativação da carta de suporte não gasta ação, seus efeitos seguem SRD e ficha original e a carta utilizada vai para a pilha de descarte. Não inferir condições nem números ausentes.
