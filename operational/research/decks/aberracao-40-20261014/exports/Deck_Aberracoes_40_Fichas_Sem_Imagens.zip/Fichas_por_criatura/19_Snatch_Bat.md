# Snatch Bat

- Posição do deck: 19/40
- Tipo: Aberração
- ND: 5
- Raridade: Comum
- ID de catálogo: TF-278
- Origem: CATALOGO_607
- Publicação: Tome of Beasts 3
- Referência: https://koboldpress.com/tools/kobold-press-monsters/
- CA: 16
- PV: 97
- Iniciativa: +5 (DES derivada)
- Status: **FICHA DE PESQUISA NÃO VALIDADA — NÃO HOMOLOGADA**

## Habilidade de suporte selecionada (candidata)

**Pilfering Bite (D)**

Ataque +8, 2d4+5 perfurante na opção de dano.

**Revisão:** Não aplicar roubo de item sem regras de equipamentos.

## Mecânica disponível na fonte do pacote

Bloco estruturado de pesquisa individual; pode conter lacunas e conflitos de edição.

```json
{
  "estatisticas": {
    "armor_class": 16,
    "hit_points": 97,
    "hit_dice": "15d8+30",
    "ability_scores": {
      "STR": 16,
      "DEX": 20,
      "CON": 14,
      "INT": 6,
      "WIS": 12,
      "CHA": 5
    },
    "speeds": {
      "walk_ft": 20,
      "fly_ft": 40
    },
    "senses": {
      "blindsight_ft": 60,
      "blind_beyond_blindsight": true,
      "passive_perception": 14
    },
    "skills": {
      "Perception": 4,
      "Sleight_of_Hand": 8,
      "Stealth": 8
    },
    "saving_throws": [],
    "languages": {
      "understands": [
        "Deep Speech",
        "Umbral"
      ],
      "can_speak": false
    },
    "damage_resistances": [
      "force",
      "psychic"
    ],
    "damage_immunities": [],
    "damage_vulnerabilities": [],
    "condition_immunities": [
      "blinded",
      "charmed",
      "exhaustion"
    ],
    "armor_class_type": "natural_armor",
    "ability_modifiers": {
      "STR": 3,
      "DEX": 5,
      "CON": 2,
      "INT": -2,
      "WIS": 1,
      "CHA": -3
    }
  },
  "mecanicas": {
    "traits": [
      {
        "name": "Flyby",
        "category": "movement",
        "effect": {
          "opportunity_attack_triggered_by_flying_out_of_enemy_reach": false
        }
      },
      {
        "name": "Treasure Sense",
        "category": "object_sense",
        "targets": [
          "precious_metals",
          "gemstones",
          "jewelry"
        ],
        "pinpoint_scent_within_ft": 60,
        "direction_sensed_within_miles": 1
      }
    ],
    "actions": [
      {
        "name": "Multiattack",
        "category": "multiattack",
        "action_economy": "action",
        "choose_one_sequence": [
          [
            {
              "attack": "Claw",
              "count": 3
            }
          ],
          [
            {
              "attack": "Claw",
              "count": 2
            },
            {
              "attack": "Pilfering Bite",
              "count": 1
            }
          ]
        ]
      },
      {
        "name": "Claw",
        "category": "attack",
        "action_economy": "action",
        "attack_type": "melee_weapon",
        "attack_bonus": 8,
        "reach_ft": 5,
        "targets": {
          "count": 1
        },
        "hit": {
          "damage": [
            {
              "dice": "2d6",
              "flat": 5,
              "average": 12,
              "type": "slashing"
            }
          ]
        },
        "miss": {
          "damage": 0
        }
      },
      {
        "name": "Pilfering Bite",
        "category": "attack_or_steal",
        "action_economy": "action",
        "attack_type": "melee_weapon",
        "attack_bonus": 8,
        "reach_ft": 10,
        "targets": {
          "count": 1
        },
        "on_hit_choose_one": [
          {
            "mode": "damage",
            "damage": [
              {
                "dice": "2d4",
                "flat": 5,
                "average": 10,
                "type": "piercing"
              }
            ]
          },
          {
            "mode": "steal_instead_of_damage",
            "item_requirements": {
              "worn_or_carried_by_target": true,
              "max_weight_lb": 10,
              "must_not_be_weapon": true,
              "must_not_be_wrapped_around_or_firmly_attached_to_target": true
            },
            "stores_item_in": "long_neck_arm",
            "requires_regurgitating_held_item_before_next_pilfering_bite": true,
            "regurgitation_action_cost": "none"
          }
        ],
        "miss": {
          "damage": 0
        }
      }
    ],
    "bonus_actions": [],
    "reactions": [],
    "legendary_actions": [],
    "lair_actions": [],
    "mythic_actions": [],
    "spellcasting": [],
    "other": [
      {
        "name": "Pilfered Item Capacity",
        "category": "inventory_state",
        "maximum_items_carried_in_neck_arm_before_next_bite": 1,
        "must_regurgitate_first": true,
        "regurgitation_action_cost": "none",
        "note": "Creature might carry elsewhere but source only explicitly establishes the long neck-arm held item."
      }
    ]
  }
}
```

### Observações

Esta é uma ficha de pesquisa; a existência de informações não comprova a homologação. A ativação da carta de suporte não gasta ação, seus efeitos seguem SRD e ficha original e a carta utilizada vai para a pilha de descarte. Não inferir condições nem números ausentes.
