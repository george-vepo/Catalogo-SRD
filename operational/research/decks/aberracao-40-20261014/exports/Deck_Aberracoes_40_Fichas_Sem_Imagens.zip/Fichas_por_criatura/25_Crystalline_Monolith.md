# Crystalline Monolith

- Posição do deck: 25/40
- Tipo: Aberração
- ND: 7
- Raridade: Incomum
- ID de catálogo: KP-A001
- Origem: CATALOGO_607
- Publicação: Tome of Beasts 2
- Referência: https://www.5esrd.com/database/creature/crystalline-monolith/
- CA: 15
- PV: 123
- Iniciativa: +0
- Status: **RESUMO DE PESQUISA (NÃO INTEGRAL) — NÃO HOMOLOGADA**

## Habilidade de suporte selecionada (candidata)

**Psychic Burst (E/D)**

Inteligência CD 15; 8d6 psíquico e Atordoado na falha.

**Revisão:** Recarga 5–6 e novos testes; confirmar fonte bibliográfica.

## Mecânica disponível na fonte do pacote

Resumo mecânico próprio coletado em fontes secundárias; não é ficha integral.

```json
{
  "fonte_publicacao": "Tome of Beasts 2",
  "editora_fonte": "Kobold Press / Open Design LLC",
  "sistema": "D&D 5e (conteúdo de terceiro hospedado pelo KPOGL/5eSRD)",
  "porte": "Huge",
  "tipo_fonte": "aberration",
  "alinhamento": "lawful neutral",
  "nd_fonte": "7",
  "ca": 15,
  "ca_base": "natural armor",
  "pv": 123,
  "formula_pv": "13d12 + 39",
  "deslocamento": {
    "walk_ft": 0,
    "fly_ft": 30,
    "fly_hover": true
  },
  "salvaguardas": {},
  "pericias": {
    "Arcana": 7,
    "History": 7,
    "Insight": 6,
    "Nature": 7,
    "Perception": 6
  },
  "resistencias_dano": [
    "cold",
    "fire"
  ],
  "imunidades_dano": [
    "poison"
  ],
  "vulnerabilidades_dano": [],
  "imunidades_condicao": [
    "blinded",
    "paralyzed",
    "petrified",
    "poisoned",
    "prone"
  ],
  "sentidos": [
    "blindsight 120 ft. (blind beyond this radius)"
  ],
  "percepcao_passiva": 16,
  "idiomas": [
    "Deep Speech",
    "Undercommon",
    "telepathy 120 ft."
  ],
  "bonus_proficiencia": 3,
  "tracos": [
    {
      "nome": "False Appearance",
      "resumo_mecanico": "Enquanto imóvel, é indistinguível de um cristal gigante."
    },
    {
      "nome": "Magic Resistance",
      "resumo_mecanico": "Tem vantagem em salvaguardas contra magias e outros efeitos mágicos."
    },
    {
      "nome": "Powerful Mind",
      "resumo_mecanico": "Tem vantagem em salvaguardas e testes de Inteligência."
    },
    {
      "nome": "Innate Spellcasting (Psionics)",
      "resumo_mecanico": "Usa Inteligência, CD 15, sem componentes; à vontade detect magic, detect thoughts, mage hand e silent image; 3/dia clairvoyance, hypnotic pattern, stinking cloud e telekinesis; 1/dia confusion, dominate person e suggestion."
    }
  ],
  "acoes": [
    {
      "nome": "Multiattack",
      "resumo_mecanico": "Faz dois ataques Slam ou dois ataques Mind Spear. Se os dois Slam acertarem uma criatura Grande ou menor, o alvo faz salvaguarda de Constituição CD 14; em falha fica Restrained e depois Petrified até o efeito terminar."
    },
    {
      "nome": "Slam",
      "resumo_mecanico": "Ataque corpo a corpo +5, alcance 10 ft.; 11 (2d8+2) bludgeoning.",
      "ataque": "+5",
      "alcance": "10 ft.",
      "dano": [
        {
          "dados": "2d8+2",
          "tipo": "bludgeoning"
        }
      ]
    },
    {
      "nome": "Mind Spear",
      "resumo_mecanico": "Ataque mágico à distância +7, alcance 30 ft.; 14 (4d6) psychic.",
      "ataque": "+7",
      "alcance": "30 ft.",
      "dano": [
        {
          "dados": "4d6",
          "tipo": "psychic"
        }
      ]
    },
    {
      "nome": "Psychic Burst (Recharge 5-6)",
      "resumo_mecanico": "Cone de 30 ft.; cada criatura faz salvaguarda de Inteligência CD 15. Em falha sofre 28 (8d6) psychic e fica Stunned por 1 minuto; repete a salvaguarda no fim de cada turno.",
      "uso": "Recharge 5–6",
      "salvaguarda": "Intelligence DC 15",
      "alcance": "30-ft. cone",
      "dano": [
        {
          "dados": "8d6",
          "tipo": "psychic"
        }
      ]
    }
  ],
  "acoes_bonus": [],
  "reacoes": [],
  "acoes_lendarias": [
    {
      "nome": "Detect",
      "resumo_mecanico": "Faz um teste de Wisdom (Perception)."
    },
    {
      "nome": "Teleport",
      "resumo_mecanico": "Teleporta-se até 120 ft. para um espaço desocupado que possa ver.",
      "custo": "2 legendary actions",
      "alcance": "120 ft."
    },
    {
      "nome": "Cast a Spell",
      "resumo_mecanico": "Conjura uma magia da lista de Innate Spellcasting, gastando o uso correspondente.",
      "custo": "3 legendary actions"
    }
  ],
  "caracteristicas_de_covil": [
    {
      "nome": "Illusory Duplicate",
      "resumo_mecanico": "Na iniciativa 20, cria uma duplicata ilusória; ataques contra ela acertam apenas com resultado 11 ou mais no d20. Uma investigação CD 15 identifica a ilusão. Dura 1 minuto ou até usar esta ação novamente."
    },
    {
      "nome": "Tremor",
      "resumo_mecanico": "Na iniciativa 20, criaturas no solo a até 60 ft. fazem salvaguarda de Destreza CD 15 ou ficam Prone; o monólito é imune."
    },
    {
      "nome": "Charged Shards",
      "resumo_mecanico": "Na iniciativa 20, até duas criaturas a até 60 ft. são alvo de fragmentos; ataque +3 causa 1d4 piercing e 1d4 psychic."
    }
  ],
  "conjuracao": null,
  "nota_tatica": "",
  "secoes_nao_listadas": [
    "salvaguardas",
    "vulnerabilidades de dano",
    "ações bônus",
    "reações",
    "ações míticas"
  ],
  "fontes_adicionais": [
    {
      "titulo": "Índice oficial de monstros da Kobold Press (identidade, edição, porte, tipo e ND)",
      "url": "https://koboldpress.com/tools/kobold-press-monsters/"
    },
    {
      "titulo": "KPOGL, transcrição secundária explicitamente não endossada pela Kobold Press (mecânica)",
      "url": "https://kpogl.wikidot.com/monster:crystalline-monolith"
    },
    {
      "titulo": "Robinloft, transcrição secundária de conferência",
      "url": "https://robinloft.com/monsters/crystalline-monolith"
    }
  ],
  "classe_fonte": "O índice oficial confirma identidade, Tome of Beasts 2, porte Huge, tipo Aberration e ND 7. A mecânica foi resumida da transcrição KPOGL, que declara não ser publicada, endossada ou aprovada pela Kobold Press; não foi reproduzida integralmente.",
  "completa": true,
  "variante": "D&D 5e, Tome of Beasts 2",
  "atributos": {
    "FOR": {
      "valor": 14,
      "modificador": 2
    },
    "DES": {
      "valor": 10,
      "modificador": 0
    },
    "CON": {
      "valor": 16,
      "modificador": 3
    },
    "INT": {
      "valor": 19,
      "modificador": 4
    },
    "SAB": {
      "valor": 17,
      "modificador": 3
    },
    "CAR": {
      "valor": 17,
      "modificador": 3
    }
  },
  "iniciativa": {
    "modificador_base_des": 0,
    "valor_formatado": "+0",
    "origem": "derivada do modificador de Destreza; fonte não informa bônus adicional"
  },
  "fonte_url": "https://kpogl.wikidot.com/monster:crystalline-monolith",
  "data_verificacao": "2026-10-10",
  "secoes_cobertas": [
    "identidade",
    "porte",
    "tipo",
    "ND",
    "CA",
    "PV e fórmula",
    "deslocamento",
    "atributos e modificadores",
    "salvaguardas",
    "perícias",
    "sentidos",
    "idiomas",
    "defesas",
    "traços",
    "ações",
    "recursos e recargas",
    "CDs e condições",
    "ações lendárias",
    "características de covil"
  ],
  "secoes_nao_listadas_na_fonte": [
    "salvaguardas",
    "vulnerabilidades de dano",
    "ações bônus",
    "reações",
    "ações míticas"
  ],
  "transcricao_integral": false,
  "observacao_direitos": "Fatos mecânicos e resumo próprio; sem reprodução integral da redação externa."
}
```

### Observações

Esta é uma ficha de pesquisa; a existência de informações não comprova a homologação. A ativação da carta de suporte não gasta ação, seus efeitos seguem SRD e ficha original e a carta utilizada vai para a pilha de descarte. Não inferir condições nem números ausentes.
