# Kalaraq Quori

- Posição do deck: 39/40
- Tipo: Aberração
- ND: 19
- Raridade: Lendária
- ID de catálogo: Não atribuído — externa
- Origem: CANDIDATO_EXTERNO_NAO_APROVADO
- Publicação: Eberron: Rising from the Last War
- Referência: https://www.dndbeyond.com/monsters?page=177&sort=-type
- CA: Não confirmada neste registro
- PV: Não confirmados neste registro
- Iniciativa: Não confirmada neste registro
- Status: **EXTERNA — SEM FICHA — NÃO HOMOLOGADA**

## Habilidade de suporte selecionada (candidata)

**Swarm of Eyes (E/D)**

Sabedoria CD 21; 10d8 psíquico e possível Cego.

**Revisão:** Ficha externa Eberron não integrada; recarga 6, novos testes.

## Mecânica disponível na fonte do pacote

Não existe bloco mecânico recuperado neste pacote. Não criar poderes ou números para completar.

```json
{}
```

### Observações

Esta é uma ficha de pesquisa; a existência de informações não comprova a homologação. A ativação da carta de suporte não gasta ação, seus efeitos seguem SRD e ficha original e a carta utilizada vai para a pilha de descarte. Não inferir condições nem números ausentes.
