# Shoth, Sooze

- Posição do deck: 5/40
- Tipo: Aberração
- ND: 1/2
- Raridade: Comum
- ID de catálogo: TF-273
- Origem: CATALOGO_607
- Publicação: Creature Codex
- Referência: https://koboldpress.com/tools/kobold-press-monsters/
- CA: 12
- PV: 49
- Iniciativa: +0 (DES derivada)
- Status: **FICHA DE PESQUISA NÃO VALIDADA — NÃO HOMOLOGADA**

## Habilidade de suporte selecionada (candidata)

**Warrior (B→Ativa)**

Proposta: transferir +2 CA da variante Warrior.

**Revisão:** Dependente da escolha de variante; não transformar vantagem condicional em vantagem irrestrita.

## Mecânica disponível na fonte do pacote

Bloco estruturado de pesquisa individual; pode conter lacunas e conflitos de edição.

```json
{
  "estatisticas": {
    "armor_class": 12,
    "hit_points": 49,
    "hit_dice": "11d8",
    "ability_scores": {
      "STR": 14,
      "DEX": 10,
      "CON": 10,
      "INT": 10,
      "WIS": 14,
      "CHA": 16
    },
    "speeds": {
      "walk_ft": 30,
      "climb_ft": 10
    },
    "senses": {
      "blindsight_ft": 60,
      "passive_perception": 14
    },
    "skills": {
      "Perception": 4
    },
    "saving_throws": [],
    "languages": {
      "spoken": "all_languages",
      "telepathy_ft": 100
    },
    "damage_resistances": [
      "acid",
      "cold",
      "fire"
    ],
    "damage_immunities": [],
    "damage_vulnerabilities": [],
    "condition_immunities": [],
    "armor_class_type": "natural_armor",
    "armor_class_variants": {
      "base_or_laborer": 12,
      "warrior": 14
    },
    "ability_modifiers": {
      "STR": 2,
      "DEX": 0,
      "CON": 0,
      "INT": 0,
      "WIS": 2,
      "CHA": 3
    }
  },
  "mecanicas": {
    "traits": [
      {
        "name": "Amorphous",
        "category": "movement",
        "minimum_gap_inches": 1,
        "equipment_included": true,
        "no_squeezing_required": true
      },
      {
        "name": "Multiple Roles",
        "category": "mutually_exclusive_variant",
        "choose_exactly_one": [
          "Laborer",
          "Warrior"
        ],
        "options": [
          {
            "name": "Laborer",
            "condition_immunities_add": [
              "exhaustion"
            ],
            "bonus_action_options": [
              {
                "name": "Dash",
                "uses_per_day": 3
              }
            ]
          },
          {
            "name": "Warrior",
            "armor_class_increase": 2,
            "grants_action": "Longsword",
            "attack_advantage_if": {
              "friendly_ally_within_ft_of_target": 5,
              "ally_not_incapacitated": true
            }
          }
        ]
      }
    ],
    "actions": [
      {
        "name": "Oozing Slam",
        "category": "attack",
        "action_economy": "action",
        "attack_type": "melee_weapon",
        "attack_bonus": 4,
        "reach_ft": 5,
        "targets": {
          "count": 1
        },
        "hit": {
          "damage": [
            {
              "dice": "1d4",
              "flat": 2,
              "average": 4,
              "type": "bludgeoning"
            },
            {
              "dice": "1d4",
              "flat": 0,
              "average": 2,
              "type": "acid"
            }
          ]
        },
        "miss": {
          "damage": 0
        }
      },
      {
        "name": "Longsword",
        "category": "attack",
        "action_economy": "action",
        "precondition": "Multiple_Roles_selected_Warrior",
        "attack_type": "melee_weapon",
        "attack_bonus": 4,
        "reach_ft": 5,
        "targets": {
          "count": 1
        },
        "hit": {
          "one_handed": [
            {
              "dice": "1d8",
              "flat": 2,
              "average": 6,
              "type": "slashing"
            }
          ],
          "two_handed": [
            {
              "dice": "1d10",
              "flat": 2,
              "average": 7,
              "type": "slashing"
            }
          ]
        },
        "miss": {
          "damage": 0
        }
      },
      {
        "name": "Merge",
        "category": "conditional_fusion",
        "action_economy": "action",
        "precondition": {
          "current_hp_below_half_max": true,
          "ally_creature_type": "shoth",
          "ally_within_ft": 10
        },
        "effect": {
          "merge_actor_into_target": true,
          "hit_points_added": "actor_current_remaining_hit_points",
          "allows_ally_hp_above_its_normal_maximum": true
        },
        "receiving_creature_limit": {
          "mergers_accepted_per_24h": 1
        },
        "actor_removal_from_battle": true
      }
    ],
    "bonus_actions": [
      {
        "name": "Dash (Laborer)",
        "category": "movement",
        "action_economy": "bonus_action",
        "precondition": "Multiple_Roles_selected_Laborer",
        "uses_per_day": 3
      }
    ],
    "reactions": [],
    "legendary_actions": [],
    "lair_actions": [],
    "mythic_actions": [],
    "spellcasting": [],
    "other": []
  }
}
```

### Observações

Esta é uma ficha de pesquisa; a existência de informações não comprova a homologação. A ativação da carta de suporte não gasta ação, seus efeitos seguem SRD e ficha original e a carta utilizada vai para a pilha de descarte. Não inferir condições nem números ausentes.
