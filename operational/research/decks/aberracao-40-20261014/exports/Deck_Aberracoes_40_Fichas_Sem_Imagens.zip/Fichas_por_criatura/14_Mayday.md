# Mayday

- Posição do deck: 14/40
- Tipo: Aberração
- ND: 4
- Raridade: Comum
- ID de catálogo: TF-520
- Origem: CATALOGO_607
- Publicação: A5E — diversos suplementos
- Referência: https://a5e.tools/node/5326
- CA: 14
- PV: 300
- Iniciativa: Dex +2 (12), Insight +2 (12), Perception +2 (12)
- Status: **RESUMO DE PESQUISA (NÃO INTEGRAL) — NÃO HOMOLOGADA**

## Habilidade de suporte selecionada (candidata)

**Pseudopod (D/E)**

+6, 4d8+4 contundente; aplica Sticky conforme ficha.

**Revisão:** Preservar restrições de alvo não aderido e regras de sair do agarrão/adesão.

## Mecânica disponível na fonte do pacote

Resumo mecânico próprio coletado em fontes secundárias; não é ficha integral.

```json
{
  "fonte_publicacao": "Voidrunner's Codex",
  "editora_fonte": "EN Publishing",
  "sistema": "Level Up Advanced 5th Edition (página de ferramenta; não é o A5ESRD)",
  "porte": "Gargantuan",
  "tipo_fonte": "aberration",
  "alinhamento": "",
  "nd_fonte": "4",
  "ca": 14,
  "ca_base": "natural armor",
  "pv": 300,
  "formula_pv": "24d20 + 48; bloodied 150",
  "deslocamento": {
    "walk_ft": 0,
    "fly_ft": 80,
    "fly_qualifier": "spacefaring average"
  },
  "terreno_fonte": [
    "Astral Plane"
  ],
  "iniciativa_fonte": "Dex +2 (12), Insight +2 (12), Perception +2 (12)",
  "salvaguardas": {
    "STR": 4,
    "DEX": 2,
    "CON": 4,
    "INT": -2,
    "WIS": 2,
    "CHA": -1
  },
  "pericias": {},
  "resistencias_dano": [],
  "imunidades_dano": [],
  "vulnerabilidades_dano": [],
  "imunidades_condicao": [],
  "sentidos": [],
  "percepcao_passiva": 12,
  "idiomas": [],
  "bonus_proficiencia": 2,
  "maneuver_dc": 14,
  "tracos": [
    {
      "nome": "Communicator",
      "resumo_mecanico": "Pode escutar e replicar perfeitamente qualquer comunicação eletrônica, mas não altera a mensagem nem cria comunicação original."
    },
    {
      "nome": "False Appearance",
      "resumo_mecanico": "Enquanto imóvel, é indistinguível de objeto inanimado, como uma nave espacial."
    },
    {
      "nome": "Sticky",
      "resumo_mecanico": "Criatura ou objeto que toca Mayday fica preso. Uma criatura ou nave pode usar ação para fazer teste de Força CD 24; sucesso encerra o efeito. Mayday também pode encerrá-lo voluntariamente ou o efeito termina quando morre."
    }
  ],
  "acoes": [
    {
      "nome": "Multiattack",
      "resumo_mecanico": "Faz um ataque Pseudopod e um ataque Bite."
    },
    {
      "nome": "Bite",
      "resumo_mecanico": "Ataque corpo a corpo +6, alcance corpo a corpo conforme termo da fonte; um alvo preso a Mayday; 46 (4d20+4) piercing.",
      "ataque": "+6",
      "alcance": "melee range (termo da fonte)",
      "dano": [
        {
          "dados": "4d20+4",
          "tipo": "piercing"
        }
      ]
    },
    {
      "nome": "Pseudopod",
      "resumo_mecanico": "Ataque corpo a corpo +6, alcance “short” conforme termo da fonte; um alvo que não esteja preso; 22 (4d8+4) bludgeoning. Alvo fica sujeito a Sticky e é puxado para alcance corpo a corpo.",
      "ataque": "+6",
      "alcance": "short (termo da fonte)",
      "dano": [
        {
          "dados": "4d8+4",
          "tipo": "bludgeoning"
        }
      ]
    }
  ],
  "acoes_bonus": [
    {
      "nome": "Shapeshift",
      "resumo_mecanico": "Muda para forma aproximada de objeto que tenha visto, como nave, destroços ou asteroide, ou retorna à forma verdadeira de massa prateada. Objetos que carrega ou criaturas/objetos presos não se transformam; estatísticas não mudam; reverte ao morrer."
    }
  ],
  "secoes_nao_listadas": [
    "resistências e vulnerabilidades a dano",
    "imunidades a dano e condições",
    "perícias",
    "ações bônus adicionais",
    "reações",
    "ações lendárias",
    "ações míticas",
    "ações de covil",
    "conjuração"
  ],
  "atributos": {
    "FOR": {
      "valor": 18,
      "modificador": 4
    },
    "DES": {
      "valor": 14,
      "modificador": 2
    },
    "CON": {
      "valor": 18,
      "modificador": 4
    },
    "INT": {
      "valor": 6,
      "modificador": -2
    },
    "SAB": {
      "valor": 14,
      "modificador": 2
    },
    "CAR": {
      "valor": 8,
      "modificador": -1
    }
  },
  "iniciativa": {
    "valor_formatado": "Dex +2 (12), Insight +2 (12), Perception +2 (12)",
    "origem": "listada explicitamente pela fonte"
  },
  "fonte_url": "https://a5e.tools/node/5326",
  "variante": "Não indicada na fonte",
  "classe_fonte": "Página de ferramenta da editora; a própria página declara que não é o A5E SRD.",
  "data_verificacao": "2026-10-10",
  "secoes_cobertas": [
    "identidade",
    "porte",
    "tipo",
    "ND",
    "CA",
    "PV e fórmula",
    "deslocamento",
    "atributos e modificadores",
    "salvaguardas",
    "perícias",
    "sentidos",
    "idiomas",
    "defesas",
    "traços",
    "ações",
    "recursos e recargas",
    "CDs e condições",
    "ações bônus"
  ],
  "secoes_nao_listadas_na_fonte": [
    "resistências e vulnerabilidades a dano",
    "imunidades a dano e condições",
    "perícias",
    "ações bônus adicionais",
    "reações",
    "ações lendárias",
    "ações míticas",
    "ações de covil",
    "conjuração"
  ],
  "transcricao_integral": false,
  "observacao_direitos": "Fatos mecânicos e resumo próprio; sem reprodução integral da redação externa."
}
```

### Observações

Esta é uma ficha de pesquisa; a existência de informações não comprova a homologação. A ativação da carta de suporte não gasta ação, seus efeitos seguem SRD e ficha original e a carta utilizada vai para a pilha de descarte. Não inferir condições nem números ausentes.
