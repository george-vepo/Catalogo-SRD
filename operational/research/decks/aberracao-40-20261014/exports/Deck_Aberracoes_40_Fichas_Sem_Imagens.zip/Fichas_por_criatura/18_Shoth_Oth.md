# Shoth, Oth

- Posição do deck: 18/40
- Tipo: Aberração
- ND: 5
- Raridade: Comum
- ID de catálogo: TF-277
- Origem: CATALOGO_607
- Publicação: Creature Codex
- Referência: https://koboldpress.com/tools/kobold-press-monsters/
- CA: 15
- PV: 119
- Iniciativa: +0 (DES derivada)
- Status: **FICHA DE PESQUISA NÃO VALIDADA — NÃO HOMOLOGADA**

## Habilidade de suporte selecionada (candidata)

**Paladin of Shoth (B→Ativa)**

Proposta: +2 CA da variante Paladino transferidos à ativa.

**Revisão:** Variante escolhida é requisito; manter outros efeitos só se elegíveis.

## Mecânica disponível na fonte do pacote

Bloco estruturado de pesquisa individual; pode conter lacunas e conflitos de edição.

```json
{
  "estatisticas": {
    "armor_class": 15,
    "hit_points": 119,
    "hit_dice": "14d10+42",
    "ability_scores": {
      "STR": 16,
      "DEX": 10,
      "CON": 16,
      "INT": 11,
      "WIS": 14,
      "CHA": 18
    },
    "speeds": {
      "walk_ft": 30,
      "climb_ft": 10
    },
    "senses": {
      "blindsight_ft": 60,
      "passive_perception": 15
    },
    "skills": {
      "Arcana": 3,
      "Perception": 5,
      "Persuasion": 7,
      "Religion": 3
    },
    "saving_throws": [],
    "languages": {
      "spoken": "all_languages",
      "telepathy_ft": 100
    },
    "damage_resistances": [
      "acid",
      "cold",
      "fire"
    ],
    "damage_immunities": [],
    "damage_vulnerabilities": [],
    "condition_immunities": [],
    "armor_class_type": "natural_armor",
    "armor_class_variants": {
      "base_and_Dripping_Arcanist": 15,
      "Paladin_of_Shoth": 17
    },
    "ability_modifiers": {
      "STR": 3,
      "DEX": 0,
      "CON": 3,
      "INT": 0,
      "WIS": 2,
      "CHA": 4
    }
  },
  "mecanicas": {
    "traits": [
      {
        "name": "Amorphous",
        "category": "movement",
        "minimum_gap_inches": 1,
        "equipment_included": true,
        "no_squeezing_required": true
      },
      {
        "name": "Multiple Roles",
        "category": "exclusive_variant",
        "choose_exactly_one": [
          "Dripping Arcanist",
          "Paladin of Shoth"
        ],
        "options": [
          {
            "name": "Dripping Arcanist",
            "spellcasting_ability": "CHA",
            "spell_save_dc": 15,
            "spell_attack_bonus": 7,
            "components": [
              "V"
            ],
            "spells": {
              "at_will": [
                "fire bolt (2d10)",
                "light",
                "thaumaturgy"
              ],
              "per_day_3_each": [
                "command",
                "mage armor",
                "magic missile"
              ],
              "per_day_2_each": [
                "augury",
                "detect thoughts"
              ],
              "per_day_1_each": [
                "fireball"
              ]
            }
          },
          {
            "name": "Paladin of Shoth",
            "armor_class_increase": 2,
            "grants_attack": "Greatsword",
            "trait": {
              "name": "Shoth's Light",
              "trigger": "non_shoth_creature_starts_turn_within_5ft",
              "save": {
                "ability": "CHA",
                "dc": 15,
                "on_failure": {
                  "condition": "blinded",
                  "ends": "end_of_target_current_turn"
                },
                "on_success": {
                  "condition": null
                }
              }
            }
          }
        ]
      }
    ],
    "actions": [
      {
        "name": "Multiattack",
        "category": "multiattack",
        "action_economy": "action",
        "choose_one_sequence": [
          [
            {
              "attack": "Oozing Slam",
              "count": 2
            }
          ],
          [
            {
              "attack": "Oozing Slam",
              "count": 1
            },
            {
              "attack": "Greatsword",
              "count": 1,
              "requires_role": "Paladin of Shoth"
            }
          ]
        ]
      },
      {
        "name": "Oozing Slam",
        "category": "attack",
        "action_economy": "action",
        "attack_type": "melee_weapon",
        "attack_bonus": 6,
        "reach_ft": 5,
        "targets": {
          "count": 1
        },
        "hit": {
          "damage": [
            {
              "dice": "2d10",
              "flat": 3,
              "average": 14,
              "type": "bludgeoning"
            },
            {
              "dice": "1d4",
              "flat": 0,
              "average": 2,
              "type": "acid"
            }
          ]
        },
        "miss": {
          "damage": 0
        }
      },
      {
        "name": "Greatsword",
        "category": "attack",
        "action_economy": "action",
        "requires_role": "Paladin of Shoth",
        "attack_type": "melee_weapon",
        "attack_bonus": 6,
        "reach_ft": 10,
        "targets": {
          "count": 1
        },
        "hit": {
          "damage": [
            {
              "dice": "4d6",
              "flat": 3,
              "average": 17,
              "type": "slashing"
            }
          ]
        },
        "miss": {
          "damage": 0
        }
      },
      {
        "name": "Merge",
        "category": "conditional_fusion",
        "action_economy": "action",
        "precondition": {
          "remaining_hit_points_less_than_half_own_max": true,
          "other_shoth_within_ft": 10
        },
        "effect": {
          "remove_this_shoth": true,
          "other_shoth_gains_hit_points_equal_to_current_remaining_hp": true,
          "may_exceed_ordinary_hp_max": true
        },
        "receiving_creature_limit": "1_received_merge_per_24_hours"
      },
      {
        "name": "Spray",
        "category": "area_save",
        "action_economy": "action",
        "recharge": "6",
        "area": {
          "shape": "cone",
          "length_ft": 30
        },
        "targets": "all_creatures_in_area",
        "save": {
          "ability": "DEX",
          "dc": 15,
          "on_failure": {
            "damage": [
              {
                "dice": "5d8",
                "flat": 0,
                "average": 22,
                "type": "acid"
              }
            ]
          },
          "on_success": {
            "damage_multiplier": 0.5
          }
        }
      }
    ],
    "bonus_actions": [],
    "reactions": [],
    "legendary_actions": [],
    "lair_actions": [],
    "mythic_actions": [],
    "spellcasting": [
      {
        "name": "Dripping Arcanist",
        "requires_role": "Dripping Arcanist",
        "ability": "CHA",
        "spell_save_dc": 15,
        "spell_attack_bonus": 7,
        "components": [
          "V"
        ],
        "at_will": [
          "fire bolt",
          "light",
          "thaumaturgy"
        ],
        "uses_per_day": {
          "command": 3,
          "mage armor": 3,
          "magic missile": 3,
          "augury": 2,
          "detect thoughts": 2,
          "fireball": 1
        },
        "spell_specific_definitions_verified": false
      }
    ],
    "other": [
      {
        "name": "Role-based spells",
        "category": "cross_rule_dependency",
        "details": "Published creature block lists spells and resource limits but does not individually restate target/duration/material and effects of each spell; separate spell-definition verification required."
      }
    ]
  }
}
```

### Observações

Esta é uma ficha de pesquisa; a existência de informações não comprova a homologação. A ativação da carta de suporte não gasta ação, seus efeitos seguem SRD e ficha original e a carta utilizada vai para a pilha de descarte. Não inferir condições nem números ausentes.
