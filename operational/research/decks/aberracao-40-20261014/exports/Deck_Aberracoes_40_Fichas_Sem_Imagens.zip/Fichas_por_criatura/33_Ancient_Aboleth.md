# Ancient Aboleth

- Posição do deck: 33/40
- Tipo: Aberração
- ND: 11
- Raridade: Rara
- ID de catálogo: TF-017
- Origem: CATALOGO_607
- Publicação: Monstrous Menagerie
- Referência: https://a5e.tools/node/1459
- CA: 17
- PV: 342
- Iniciativa: +1
- Status: **RESUMO DE PESQUISA (NÃO INTEGRAL) — NÃO HOMOLOGADA**

## Habilidade de suporte selecionada (candidata)

**Legendary Resistance (B→Ativa)**

Proposta: a ativa pode transformar falha em resistência em sucesso.

**Revisão:** Fonte tem 3/dia; preservar os usos e limites conforme ficha/SRD. A carta de suporte não possui custo de ativação e segue para o descarte; validar transferência individual à ativa.

## Mecânica disponível na fonte do pacote

Resumo mecânico próprio coletado em fontes secundárias; não é ficha integral.

```json
{
  "fonte_publicacao": "Monstrous Menagerie",
  "editora_fonte": "EN Publishing",
  "sistema": "Level Up Advanced 5th Edition (página de ferramenta; não é o A5E SRD)",
  "porte": "Huge",
  "tipo_fonte": "aberration",
  "alinhamento": "",
  "nd_fonte": "11",
  "ca": 17,
  "ca_base": "natural armor",
  "pv": 342,
  "formula_pv": "36d10 + 144; bloodied 171",
  "deslocamento": {
    "walk_ft": 10,
    "swim_ft": 40
  },
  "tags": [
    "Elite",
    "Legendary"
  ],
  "salvaguardas": {
    "DEX": 5,
    "CON": 8,
    "INT": 9,
    "WIS": 9
  },
  "pericias": {
    "Deception": 8,
    "History": 9,
    "Stealth": 5
  },
  "resistencias_dano": [],
  "imunidades_dano": [],
  "vulnerabilidades_dano": [],
  "imunidades_condicao": [],
  "sentidos": [
    "blindsight 30 ft.",
    "darkvision 120 ft."
  ],
  "percepcao_passiva": 15,
  "idiomas": [
    "Deep Speech",
    "telepathy 120 ft."
  ],
  "bonus_proficiencia": 4,
  "maneuver_dc": 17,
  "tracos": [
    {
      "nome": "Amphibious",
      "resumo_mecanico": "Respira ar e água."
    },
    {
      "nome": "Legendary Resistance (3/day)",
      "resumo_mecanico": "Quando falha em salvaguarda, pode escolher ter sucesso. Cada uso escurece um dos três olhos; com todos negros, fica cego além do alcance de blindsight até completar descanso longo."
    }
  ],
  "acoes": [
    {
      "nome": "Multiattack",
      "resumo_mecanico": "Faz três ataques de Tentacle."
    },
    {
      "nome": "Tentacle",
      "resumo_mecanico": "Ataque corpo a corpo +9, alcance 15 ft.; 4d6+5 bludgeoning, ou pode escolher causar 0 dano. Criatura atingida faz salvaguarda de Constituição CD 16 ou contrai Sea Change; sucesso concede imunidade à doença por 24h. A doença impõe desvantagem em salvaguardas de Sabedoria; após 1h surgem guelras e pele viscosa, e sem pelo menos 1h submersa a cada 12h a criatura começa a sufocar. Magia de remoção de doença com espaço de 4º nível ou superior cura; termina 24h após a morte do aboleth.",
      "ataque": "+9",
      "alcance": "15 ft.",
      "dano": [
        {
          "dados": "4d6+5",
          "tipo": "bludgeoning; pode causar 0"
        }
      ],
      "salvaguarda": "Constitution DC 16; disease"
    },
    {
      "nome": "Slimy Cloud (1/day; while bloodied; underwater)",
      "resumo_mecanico": "Esfera de raio 30 ft. Cada criatura exceto aboleths na área faz salvaguarda de Constituição CD 16; falha causa 8d10 poison e condição Poisoned por 1 minuto. A área fica heavily obscured por 1 minuto ou até corrente forte dissipar a nuvem.",
      "uso": "1/day; while bloodied; underwater",
      "salvaguarda": "Constitution DC 16"
    }
  ],
  "acoes_lendarias": [
    {
      "nome": "Move",
      "resumo_mecanico": "Move até o deslocamento de natação sem provocar ataques de oportunidade."
    },
    {
      "nome": "Telepathic Summon",
      "resumo_mecanico": "Uma criatura a até 90 ft. faz salvaguarda de Sabedoria CD 16; falha obriga-a a usar sua reação, se disponível, para mover-se até o deslocamento em direção ao aboleth pela rota mais direta sem evitar ataques de oportunidade. É efeito mágico de encanto.",
      "salvaguarda": "Wisdom DC 16"
    },
    {
      "nome": "Baleful Charm (custa 2 ações)",
      "resumo_mecanico": "Alvo a até 60 ft. que contraiu Sea Change faz salvaguarda de Sabedoria CD 16; falha fica Charmed até o aboleth morrer. Repete o teste a cada 24h e ao sofrer dano do aboleth ou aliados. Encantado, comunica-se telepaticamente a qualquer distância e obedece ordens.",
      "uso": "2 legendary actions",
      "salvaguarda": "Wisdom DC 16"
    },
    {
      "nome": "Soul Drain (custa 2 ações)",
      "resumo_mecanico": "Uma criatura Charmed sofre 4d10 psychic; o aboleth recupera PV iguais ao dano.",
      "uso": "2 legendary actions"
    }
  ],
  "economia_lendaria": "2 ações lendárias por rodada; só uma opção por vez e ao fim do turno de outra criatura; recupera no início do próprio turno.",
  "acoes_especiais": [
    {
      "nome": "Elite Recovery (while bloodied)",
      "resumo_mecanico": "Encerra um efeito negativo que o afete; pode usar mesmo inconsciente ou incapacitado se tiver ao menos 1 PV."
    },
    {
      "nome": "Look Upon My Works (while bloodied; 1/day)",
      "resumo_mecanico": "Cada criatura a até 90 ft. faz salvaguarda de Sabedoria CD 16; falha sofre 6d10 psychic ao ver fragmento de memórias do aboleth. Depois do dano, esquece a visão, mas pode aprender uma informação de lore.",
      "uso": "1/day; while bloodied",
      "salvaguarda": "Wisdom DC 16"
    },
    {
      "nome": "Lunging Attack (while bloodied)",
      "resumo_mecanico": "Move até o deslocamento de natação sem provocar ataques de oportunidade e faz um ataque de Tentacle."
    }
  ],
  "conjuracao": {
    "atributo": "CHA",
    "cd": 16,
    "ataque_magia": null,
    "sem_componentes": [
      "todos"
    ],
    "3/day": [
      "detect thoughts (120 ft.)",
      "project image (1 mile)",
      "major image"
    ]
  },
  "nota_tatica": "Usa Tentacle para espalhar Sea Change e depois Baleful Charm nos alvos mais perigosos; bloodied, pode criar Slimy Cloud e escapar.",
  "secoes_nao_listadas": [
    "vulnerabilidades de dano",
    "imunidades a dano e condições",
    "ações bônus",
    "reações",
    "ações míticas",
    "ações de covil"
  ],
  "atributos": {
    "FOR": {
      "valor": 20,
      "modificador": 5
    },
    "DES": {
      "valor": 12,
      "modificador": 1
    },
    "CON": {
      "valor": 18,
      "modificador": 4
    },
    "INT": {
      "valor": 20,
      "modificador": 5
    },
    "SAB": {
      "valor": 20,
      "modificador": 5
    },
    "CAR": {
      "valor": 18,
      "modificador": 4
    }
  },
  "iniciativa": {
    "modificador_base_des": 1,
    "valor_formatado": "+1",
    "origem": "derivada do modificador de Destreza; fonte não informa bônus adicional"
  },
  "fonte_url": "https://a5e.tools/node/1459",
  "variante": "Não indicada na fonte",
  "classe_fonte": "Página de ferramenta da editora; a própria página declara que não é o A5E SRD.",
  "data_verificacao": "2026-10-10",
  "secoes_cobertas": [
    "identidade",
    "porte",
    "tipo",
    "ND",
    "CA",
    "PV e fórmula",
    "deslocamento",
    "atributos e modificadores",
    "salvaguardas",
    "perícias",
    "sentidos",
    "idiomas",
    "defesas",
    "traços",
    "ações",
    "recursos e recargas",
    "CDs e condições",
    "ações especiais da ficha",
    "ações lendárias",
    "conjuração"
  ],
  "secoes_nao_listadas_na_fonte": [
    "vulnerabilidades de dano",
    "imunidades a dano e condições",
    "ações bônus",
    "reações",
    "ações míticas",
    "ações de covil"
  ],
  "transcricao_integral": false,
  "observacao_direitos": "Fatos mecânicos e resumo próprio; sem reprodução integral da redação externa."
}
```

### Observações

Esta é uma ficha de pesquisa; a existência de informações não comprova a homologação. A ativação da carta de suporte não gasta ação, seus efeitos seguem SRD e ficha original e a carta utilizada vai para a pilha de descarte. Não inferir condições nem números ausentes.
