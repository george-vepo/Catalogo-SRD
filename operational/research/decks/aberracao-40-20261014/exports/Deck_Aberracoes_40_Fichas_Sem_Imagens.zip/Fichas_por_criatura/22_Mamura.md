# Mamura

- Posição do deck: 22/40
- Tipo: Aberração
- ND: 6
- Raridade: Incomum
- ID de catálogo: TF-280
- Origem: CATALOGO_607
- Publicação: Tome of Beasts 1
- Referência: https://koboldpress.com/tools/kobold-press-monsters/
- CA: 16
- PV: 112
- Iniciativa: +4 (DES derivada)
- Status: **FICHA DE PESQUISA NÃO VALIDADA — NÃO HOMOLOGADA**

## Habilidade de suporte selecionada (candidata)

**Whiptail Stinger (E/D)**

+7, 1d8+4 perfurante; Constituição CD 15 para veneno/Envenenado e efeitos subsequentes.

**Revisão:** Preservar dano adicional, duração e novos testes.

## Mecânica disponível na fonte do pacote

Bloco estruturado de pesquisa individual; pode conter lacunas e conflitos de edição.

```json
{
  "estatisticas": {
    "armor_class": 16,
    "hit_points": 112,
    "hit_dice": "15d6+60",
    "ability_scores": {
      "STR": 8,
      "DEX": 18,
      "CON": 19,
      "INT": 17,
      "WIS": 11,
      "CHA": 16
    },
    "speeds": {
      "walk_ft": 20,
      "fly_ft": 30
    },
    "senses": {
      "darkvision_ft": 60,
      "passive_perception": 16
    },
    "skills": {
      "Acrobatics": 7,
      "Perception": 6,
      "Stealth": 7
    },
    "saving_throws": {
      "DEX": 7,
      "CON": 7,
      "CHA": 6
    },
    "languages": [
      "Common",
      "Goblin",
      "Sylvan",
      "Void Speech"
    ],
    "damage_resistances": [
      {
        "types": [
          "bludgeoning",
          "piercing",
          "slashing"
        ],
        "from": "nonmagical_attacks"
      }
    ],
    "damage_immunities": [],
    "damage_vulnerabilities": [],
    "condition_immunities": [],
    "armor_class_type": "natural_armor",
    "ability_modifiers": {
      "STR": -1,
      "DEX": 4,
      "CON": 4,
      "INT": 3,
      "WIS": 0,
      "CHA": 3
    }
  },
  "mecanicas": {
    "traits": [
      {
        "name": "Distracting Babble",
        "category": "anti_spell",
        "radius_ft": 20,
        "concentrating_spellcaster_starts_turn": {
          "save": {
            "ability": "CON",
            "dc": 15
          },
          "on_failure": "lose_concentration"
        },
        "spellcaster_attempts_to_cast": {
          "save": {
            "ability": "CON",
            "dc": 15
          },
          "on_failure": {
            "cast_fails": true,
            "spell_slot_spent": false,
            "action_bonus_or_reaction_spent": true
          }
        }
      },
      {
        "name": "Flyby",
        "category": "movement",
        "opportunity_attack_when_flying_out_of_reach": false
      },
      {
        "name": "Magic Resistance",
        "category": "saving_throw_advantage",
        "against": [
          "spells",
          "magical_effects"
        ]
      },
      {
        "name": "Radial Eyes",
        "category": "defense",
        "advantage_on_sight_perception_checks": true,
        "advantage_on_saves_vs_blinded": true,
        "if_not_blinded": {
          "enemy_advantage_from_surrounding_or_ally_distraction_disabled": true,
          "examples": [
            "Pack Tactics",
            "Sneak Attack"
          ]
        }
      }
    ],
    "actions": [
      {
        "name": "Multiattack",
        "category": "multiattack",
        "action_economy": "action",
        "sequence": [
          {
            "attack": "Claw",
            "count": 3
          },
          {
            "attack": "Whiptail Stinger",
            "count": 1
          }
        ]
      },
      {
        "name": "Claw",
        "category": "attack",
        "action_economy": "action",
        "attack_type": "melee_weapon",
        "attack_bonus": 7,
        "reach_ft": 5,
        "hit": {
          "damage": [
            {
              "dice": "1d8",
              "flat": 4,
              "average": 8,
              "type": "slashing"
            }
          ]
        }
      },
      {
        "name": "Whiptail Stinger",
        "category": "attack",
        "action_economy": "action",
        "attack_type": "melee_weapon",
        "attack_bonus": 7,
        "reach_ft": 10,
        "hit": {
          "damage": [
            {
              "dice": "1d8",
              "flat": 4,
              "average": 8,
              "type": "piercing"
            }
          ]
        },
        "on_hit_save": {
          "ability": "CON",
          "dc": 15,
          "on_failure": {
            "extra_damage": [
              {
                "dice": "2d6",
                "average": 7,
                "type": "poison"
              }
            ],
            "condition": "poisoned",
            "duration": "1_minute",
            "ongoing_damage": {
              "dice": "1d6",
              "average": 3,
              "type": "poison",
              "timing": "start_of_affected_turn"
            },
            "repeat_save": {
              "ability": "CON",
              "dc": 15,
              "timing": "end_of_affected_turn",
              "success_ends": true
            }
          },
          "on_success": {
            "extra_damage": 0,
            "condition": null
          }
        }
      }
    ],
    "bonus_actions": [
      {
        "name": "Shadow Stealth",
        "category": "hide",
        "action_economy": "bonus_action",
        "precondition": "dim_light_or_darkness"
      }
    ],
    "reactions": [],
    "legendary_actions": [],
    "lair_actions": [],
    "mythic_actions": [],
    "spellcasting": [],
    "other": []
  }
}
```

### Observações

Esta é uma ficha de pesquisa; a existência de informações não comprova a homologação. A ativação da carta de suporte não gasta ação, seus efeitos seguem SRD e ficha original e a carta utilizada vai para a pilha de descarte. Não inferir condições nem números ausentes.
