# Aboleth

- Posição do deck: 31/40
- Tipo: Aberração
- ND: 10
- Raridade: Incomum
- ID de catálogo: AT-003
- Origem: CATALOGO_607
- Publicação: Catálogo ativo v1.1
- Referência: https://www.dndbeyond.com/sources/dnd/srd-5.2.1
- CA: 17
- PV: 150
- Iniciativa: +7 (17)
- Status: **FICHA INTEGRAL SRD ARQUIVADA — NÃO HOMOLOGADA**

## Habilidade de suporte selecionada (candidata)

**Dominate Mind (E)**

SRD 5.2.1: Sabedoria CD 16, 2/dia; Enfeitiçado e controle conforme ficha.

**Revisão:** Não tratar como vitória automática; usar gatilhos de fim do efeito.

## Mecânica disponível na fonte do pacote

Bloco integral SRD 5.2.1 (texto existente no repositório).

```json
{
  "ficha_integral_texto_local": "Aboleth | INCOMUM • ND 10\n\n\nTipo: Aberração  CA: 17  PV: 150  ND: 10\nLarge Aberration, Lawful Evil\nAC 17\nInitiative +7 (17)\nHP 150 (20d10 + 40)\nSpeed 10 ft., Swim 40 ft. Str  21 +5 +5 Dex     9 −1 +3 Con     15 +2 +6 Int       18 +4 +8 Wis     15 +2 +6 Cha     18 +4\n+4\nSkills History +12, Perception +10\nSenses Darkvision 120 ft.; Passive Perception 20\nLanguages Deep Speech; telepathy 120 ft.\nCR 10 (XP 5,900, or 7,200 in lair; PB +4)\nTraits\nAmphibious. The aboleth can breathe air and water.\nEldritch Restoration. If destroyed, the aboleth gains a new body in 5d10 days, reviving with all its Hit Points in the Far Realm or\nanother location chosen by the GM. Legendary Resistance (3/Day, or 4/Day in Lair). If the aboleth fails a saving throw, it can\nchoose to succeed instead.\nMucus Cloud. While underwater, the aboleth is surrounded by mucus. Constitution Saving Throw: DC 14, each creature in a 5-\nfoot Emanation originating from the aboleth at the end of the aboleth’s turn. Failure: The target is cursed. Until the curse ends,\nthe target’s skin becomes slimy, the target can breathe air and water, and it can’t regain Hit Points unless it is underwater. While\nthe cursed creature is outside a body of water, the creature takes 6 (1d12) Acid damage at the end of every 10 minutes unless\nmoisture is applied to its skin before those minutes have passed.\nProbing Telepathy. If a creature the aboleth can see communicates telepathically with the aboleth, the aboleth learns the\ncreature’s greatest desires.\nActions\nMultiattack. The aboleth makes two Tentacle attacks and uses either Consume Memories or Dominate Mind if available.\nTentacle. Melee Attack Roll: +9, reach 15 ft. Hit: 12 (2d6 + 5) Bludgeoning damage. If the target is a Large or smaller creature, it\nhas the Grappled condition (escape DC 14) from one of four tentacles.\nConsume Memories. Intelligence Saving Throw: DC 16, one creature within 30 feet that is Charmed or Grappled by the aboleth.\nFailure: 10 (3d6) Psychic damage.\nSuccess: Half damage. Failure or Success: The aboleth gains the target’s memories if the target is a Humanoid and is reduced to 0\nHit Points by this action.\nDominate Mind (2/Day). Wisdom Saving Throw: DC 16, one creature the aboleth can see within 30 feet. Failure: The target has\nthe Charmed condition until the aboleth dies or is on a different plane of existence from the target. While Charmed, the target\nacts as an ally to the aboleth and is under its control while within 60 feet of it. In addition, the aboleth and the target can\ncommunicate telepathically with each other over any distance. The target repeats the save whenever it takes damage as well as\nafter every 24 hours it spends at least 1 mile away from the aboleth, ending the effect on itself on a success.\nLegendary Actions\nLegendary Action Uses: 3 (4 in Lair). Immediately after another creature’s turn, the aboleth can expend a use to take one of the\nfollowing actions. The aboleth regains all expended uses at the start of each of its turns.\nLash. The aboleth makes one Tentacle attack.\nPsychic Drain. If the aboleth has at least one creature Charmed or Grappled, it uses Consume Memories and regains 5 (1d10) Hit\nPoints.\nFicha oficial em inglês: SRD 5.2.1, pág. 258."
}
```

### Observações

Esta é uma ficha de pesquisa; a existência de informações não comprova a homologação. A ativação da carta de suporte não gasta ação, seus efeitos seguem SRD e ficha original e a carta utilizada vai para a pilha de descarte. Não inferir condições nem números ausentes.
