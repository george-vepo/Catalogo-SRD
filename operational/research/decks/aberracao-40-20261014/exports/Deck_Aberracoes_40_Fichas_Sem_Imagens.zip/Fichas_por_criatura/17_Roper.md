# Roper

- Posição do deck: 17/40
- Tipo: Aberração
- ND: 5
- Raridade: Comum
- ID de catálogo: AT-002
- Origem: CATALOGO_607
- Publicação: Catálogo ativo v1.1
- Referência: https://www.dndbeyond.com/monsters/16999-roper
- CA: 20
- PV: 93
- Iniciativa: +5 (15)
- Status: **FICHA INTEGRAL SRD ARQUIVADA — NÃO HOMOLOGADA**

## Habilidade de suporte selecionada (candidata)

**Tentacle (E)**

+7; Agarrado e Envenenado, fuga CD 14.

**Revisão:** SRD 5.2.1; não inventar dano para o tentáculo.

## Mecânica disponível na fonte do pacote

Bloco integral SRD 5.2.1 (texto existente no repositório).

```json
{
  "ficha_integral_texto_local": "Roper | COMUM • ND 5\n\n\nTipo: Aberração  CA: 20  PV: 93  ND: 5\nLarge Aberration, Neutral Evil\nAC 20\nInitiative +5 (15)\nHP 93 (11d10 + 33)\nSpeed 10 ft., Climb 20 ft. Str 18 +4 +4 Dex     8 −1 −1 Con     17 +3 +3 Int       7 −2 −2 Wis     16 +3 +3 Cha      6 −2\n− 2\nSkills Perception +6, Stealth +5\nSenses Darkvision 60 ft.; Passive Perception 16\nLanguages None\nCR 5 (XP 1,800; PB +3)\nTraits\nSpider Climb. The roper can climb difficult surfaces, including along ceilings, without needing to make an ability check.\nActions\nMultiattack. The roper makes two Tentacle attacks, uses Reel, and makes two Bite attacks.\nBite. Melee Attack Roll: +7, reach 5 ft. Hit: 17 (3d8 + 4) Piercing damage.\n\n\n\nTentacle. Melee Attack Roll: +7, reach 60 ft. Hit: The target has the Grappled condition (escape DC 14) from one of six tentacles,\nand the target has the Poisoned condition until the grapple ends. The tentacle can be damaged, freeing a creature it has\nGrappled when destroyed (AC 20, HP 10, Immunity to\nPoison and Psychic damage). Damaging the tentacle deals no damage to the roper, and a destroyed tentacle regrows at the start\nof the roper’s next turn.\nReel. The roper pulls each creature Grappled by it up to 30 feet straight toward it.\nFicha oficial em inglês: SRD 5.2.1, pág. 320."
}
```

### Observações

Esta é uma ficha de pesquisa; a existência de informações não comprova a homologação. A ativação da carta de suporte não gasta ação, seus efeitos seguem SRD e ficha original e a carta utilizada vai para a pilha de descarte. Não inferir condições nem números ausentes.
