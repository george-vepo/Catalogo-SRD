# Greater Star Spawn Emissary

- Posição do deck: 40/40
- Tipo: Aberração
- ND: 21
- Raridade: Mítica
- ID de catálogo: Não atribuído — externa
- Origem: CANDIDATO_EXTERNO_NAO_APROVADO
- Publicação: Van Richten's Guide to Ravenloft (2014/legacy)
- Referência: https://www.dndbeyond.com/monsters?page=176&sort=-type
- CA: Não confirmada neste registro
- PV: Não confirmados neste registro
- Iniciativa: Não confirmada neste registro
- Status: **EXTERNA — SEM FICHA — NÃO HOMOLOGADA**

## Habilidade de suporte selecionada (candidata)

**Mind Cloud (E/D)**

Sabedoria CD 23; 5d12 psíquico e encerramento de magias em alvos elegíveis.

**Revisão:** Ficha externa Legacy não integrada; ação lendária custa 3 ações lendárias na proposta — verificar edição e economia de ações.

## Mecânica disponível na fonte do pacote

Não existe bloco mecânico recuperado neste pacote. Não criar poderes ou números para completar.

```json
{}
```

### Observações

Esta é uma ficha de pesquisa; a existência de informações não comprova a homologação. A ativação da carta de suporte não gasta ação, seus efeitos seguem SRD e ficha original e a carta utilizada vai para a pilha de descarte. Não inferir condições nem números ausentes.
