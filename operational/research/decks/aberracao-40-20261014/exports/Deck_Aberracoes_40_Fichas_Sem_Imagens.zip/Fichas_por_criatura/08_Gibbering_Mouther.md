# Gibbering Mouther

- Posição do deck: 8/40
- Tipo: Aberração
- ND: 2
- Raridade: Comum
- ID de catálogo: AT-001
- Origem: CATALOGO_607
- Publicação: Catálogo ativo v1.1
- Referência: https://www.dndbeyond.com/monsters/5195034-gibbering-mouther
- CA: 9
- PV: 52
- Iniciativa: −1 (9)
- Status: **FICHA INTEGRAL SRD ARQUIVADA — NÃO HOMOLOGADA**

## Habilidade de suporte selecionada (candidata)

**Gibbering (E)**

Sabedoria CD 10; falha e 1d8 determinam comportamento.

**Revisão:** SRD 5.2.1; preservar resultados completos do d8.

## Mecânica disponível na fonte do pacote

Bloco integral SRD 5.2.1 (texto existente no repositório).

```json
{
  "ficha_integral_texto_local": "Gibbering Mouther | COMUM • ND 2\n\n\nTipo: Aberração  CA: 9  PV: 52  ND: 2\nMedium Aberration, Chaotic Neutral\nAC 9\nInitiative −1 (9)\nHP 52 (7d8 + 21)\nSpeed 20 ft., Swim 20 ft. Str  10 +0 +0 Dex     8 −1 −1 Con     16 +3 +3 Int       3 −4 −4 Wis     10 +0 +0 Cha      6 −2\n− 2\nImmunities Prone\nSenses Darkvision 60 ft.; Passive Perception 10\nLanguages None\nCR 2 (XP 450; PB +2)\nTraits\nAberrant Ground. The ground in a 10-foot Emanation originating from the mouther is Difficult Terrain.\nGibbering. The mouther babbles incoherently while it doesn’t have the Incapacitated condition. Wisdom Saving Throw: DC 10,\nany creature that starts its turn within 20 feet of the mouther while it is babbling. Failure: The target rolls 1d8 to determine what\nit does during the current turn: 1–4. The target does nothing. 5–6. The target takes no action or Bonus Action and uses all its\nmovement to move in a random direction. 7–8. The target makes a melee attack against a randomly determined creature within\nits reach or does nothing if it can’t make such an attack.\nActions\nBite. Melee Attack Roll: +2, reach 5 ft. Hit: 7 (2d6)\nPiercing damage. If the target is a Medium or smaller creature, it has the Prone condition. The target dies if it is reduced to 0 Hit\nPoints by this attack. Its body is then absorbed into the mouther, leaving only equipment behind.\nBlinding Spittle (Recharge 5–6). Dexterity Saving Throw: DC 10, each creature in a 10-foot-radius Sphere centered on a point\nwithin 30 feet. Failure: 7 (2d6) Radiant damage, and the target has the Blinded condition until the end of the mouther’s next\nturn.\nFicha oficial em inglês: SRD 5.2.1, pág. 288."
}
```

### Observações

Esta é uma ficha de pesquisa; a existência de informações não comprova a homologação. A ativação da carta de suporte não gasta ação, seus efeitos seguem SRD e ficha original e a carta utilizada vai para a pilha de descarte. Não inferir condições nem números ausentes.
