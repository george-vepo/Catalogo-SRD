# Cranium Rat

- Posição do deck: 2/40
- Tipo: Aberração
- ND: 0
- Raridade: Comum
- ID de catálogo: Não atribuído — externa
- Origem: CANDIDATO_EXTERNO_NAO_APROVADO
- Publicação: Mordenkainen Presents: Monsters of the Multiverse
- Referência: https://www.dndbeyond.com/monsters?page=2&sort=size
- CA: Não confirmada neste registro
- PV: Não confirmados neste registro
- Iniciativa: Não confirmada neste registro
- Status: **EXTERNA — SEM FICHA — NÃO HOMOLOGADA**

## Habilidade de suporte selecionada (candidata)

**Bite (D)**

Ataque +4; 1 perfurante (valor citado na conversa).

**Revisão:** Ficha externa MPMM não integrada: verificar edição e ataque.

## Mecânica disponível na fonte do pacote

Não existe bloco mecânico recuperado neste pacote. Não criar poderes ou números para completar.

```json
{}
```

### Observações

Esta é uma ficha de pesquisa; a existência de informações não comprova a homologação. A ativação da carta de suporte não gasta ação, seus efeitos seguem SRD e ficha original e a carta utilizada vai para a pilha de descarte. Não inferir condições nem números ausentes.
