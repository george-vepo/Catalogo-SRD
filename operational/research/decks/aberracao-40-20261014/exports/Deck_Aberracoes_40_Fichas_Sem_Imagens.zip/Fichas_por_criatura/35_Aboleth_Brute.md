# Aboleth Brute

- Posição do deck: 35/40
- Tipo: Aberração
- ND: 13
- Raridade: Rara
- ID de catálogo: TF-015
- Origem: CATALOGO_607
- Publicação: Dungeon Delver's Guide
- Referência: https://a5e.tools/node/2819
- CA: 18
- PV: 210
- Iniciativa: +2
- Status: **RESUMO DE PESQUISA (NÃO INTEGRAL) — NÃO HOMOLOGADA**

## Habilidade de suporte selecionada (candidata)

**Bite (E/D)**

+11; 4d12+6 perfurante, Agarrado e Contido, fuga CD 19.

**Revisão:** Preservar impossibilidade de morder outro alvo durante o agarrão se pertinente.

## Mecânica disponível na fonte do pacote

Resumo mecânico próprio coletado em fontes secundárias; não é ficha integral.

```json
{
  "fonte_publicacao": "Dungeon Delver's Guide",
  "editora_fonte": "EN Publishing",
  "sistema": "Level Up Advanced 5th Edition (página de ferramenta; não é o A5E SRD)",
  "porte": "Large",
  "tipo_fonte": "aberration",
  "alinhamento": "",
  "nd_fonte": "13",
  "ca": 18,
  "ca_base": "natural armor",
  "pv": 210,
  "formula_pv": "20d10 + 100; bloodied 105",
  "deslocamento": {
    "walk_ft": 10,
    "swim_ft": 40
  },
  "salvaguardas": {
    "DEX": 7,
    "CON": 10,
    "INT": 10,
    "WIS": 10
  },
  "pericias": {
    "Deception": 9,
    "History": 10,
    "Intimidation": 9,
    "Stealth": 7
  },
  "resistencias_dano": [
    "poison",
    "psychic"
  ],
  "imunidades_dano": [],
  "vulnerabilidades_dano": [],
  "imunidades_condicao": [],
  "sentidos": [
    "blindsight 30 ft.",
    "darkvision 120 ft."
  ],
  "percepcao_passiva": 15,
  "idiomas": [
    "Deep Speech",
    "telepathy 120 ft."
  ],
  "bonus_proficiencia": 5,
  "maneuver_dc": 19,
  "tracos": [
    {
      "nome": "Amphibious",
      "resumo_mecanico": "Respira ar e água."
    }
  ],
  "acoes": [
    {
      "nome": "Multiattack",
      "resumo_mecanico": "Faz um ataque de Bite e dois de Tentacle."
    },
    {
      "nome": "Bite",
      "resumo_mecanico": "Ataque corpo a corpo +11, alcance 5 ft.; 4d12+6 piercing. O alvo fica Grappled (escape CD 19) e Restrained enquanto o agarrão durar; não pode morder outra criatura.",
      "ataque": "+11",
      "alcance": "5 ft.",
      "dano": [
        {
          "dados": "4d12+6",
          "tipo": "piercing"
        }
      ],
      "salvaguarda": "escape DC 19"
    },
    {
      "nome": "Tentacle",
      "resumo_mecanico": "Ataque corpo a corpo +11, alcance 15 ft.; 4d6+6 bludgeoning. Criatura atingida faz salvaguarda de Constituição CD 18 ou contrai Sea Change; sucesso concede imunidade à doença por 24h. Enquanto afetada, tem desvantagem em salvaguardas de Sabedoria. Após 1h surgem guelras e pele viscosa; sem ao menos 1h imersa a cada 12h, começa a sufocar. Magia que remove doença em espaço de 4º nível ou superior encerra; também termina 24h após a morte do aboleth.",
      "ataque": "+11",
      "alcance": "15 ft.",
      "dano": [
        {
          "dados": "4d6+6",
          "tipo": "bludgeoning"
        }
      ],
      "salvaguarda": "Constitution DC 18; disease"
    }
  ],
  "acoes_bonus": [
    {
      "nome": "Ink Jet (Recharge 5–6; underwater)",
      "resumo_mecanico": "Expele limo escuro em esfera de raio 30 ft.; a área fica heavily obscured por 1 minuto ou até uma corrente forte dissipar a nuvem. Depois move-se até seu deslocamento sem provocar ataques de oportunidade.",
      "uso": "Recharge 5–6; underwater"
    }
  ],
  "reacoes": [],
  "conjuracao": null,
  "nota_tatica": "Ataca o inimigo mais forte com Bite e Grapple; usa tentáculos nos demais. Quando bloodied, pode usar Ink Jet para escapar.",
  "secoes_nao_listadas": [
    "vulnerabilidades de dano",
    "imunidades a dano e condições",
    "reações",
    "ações lendárias",
    "ações míticas",
    "ações de covil",
    "conjuração"
  ],
  "atributos": {
    "FOR": {
      "valor": 22,
      "modificador": 6
    },
    "DES": {
      "valor": 14,
      "modificador": 2
    },
    "CON": {
      "valor": 20,
      "modificador": 5
    },
    "INT": {
      "valor": 20,
      "modificador": 5
    },
    "SAB": {
      "valor": 20,
      "modificador": 5
    },
    "CAR": {
      "valor": 18,
      "modificador": 4
    }
  },
  "iniciativa": {
    "modificador_base_des": 2,
    "valor_formatado": "+2",
    "origem": "derivada do modificador de Destreza; fonte não informa bônus adicional"
  },
  "fonte_url": "https://a5e.tools/node/2819",
  "variante": "Não indicada na fonte",
  "classe_fonte": "Página de ferramenta da editora; a própria página declara que não é o A5E SRD.",
  "data_verificacao": "2026-10-10",
  "secoes_cobertas": [
    "identidade",
    "porte",
    "tipo",
    "ND",
    "CA",
    "PV e fórmula",
    "deslocamento",
    "atributos e modificadores",
    "salvaguardas",
    "perícias",
    "sentidos",
    "idiomas",
    "defesas",
    "traços",
    "ações",
    "recursos e recargas",
    "CDs e condições",
    "ações bônus"
  ],
  "secoes_nao_listadas_na_fonte": [
    "vulnerabilidades de dano",
    "imunidades a dano e condições",
    "reações",
    "ações lendárias",
    "ações míticas",
    "ações de covil",
    "conjuração"
  ],
  "transcricao_integral": false,
  "observacao_direitos": "Fatos mecânicos e resumo próprio; sem reprodução integral da redação externa."
}
```

### Observações

Esta é uma ficha de pesquisa; a existência de informações não comprova a homologação. A ativação da carta de suporte não gasta ação, seus efeitos seguem SRD e ficha original e a carta utilizada vai para a pilha de descarte. Não inferir condições nem números ausentes.
