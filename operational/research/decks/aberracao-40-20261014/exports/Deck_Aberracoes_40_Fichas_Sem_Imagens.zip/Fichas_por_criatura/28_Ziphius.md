# Ziphius

- Posição do deck: 28/40
- Tipo: Aberração
- ND: 8
- Raridade: Incomum
- ID de catálogo: TF-014
- Origem: CATALOGO_607
- Publicação: Creature Codex
- Referência: https://koboldpress.com/tools/kobold-press-monsters/
- CA: 16
- PV: 135
- Iniciativa: Não confirmada neste registro
- Status: **FICHA DE PESQUISA NÃO VALIDADA — NÃO HOMOLOGADA**

## Habilidade de suporte selecionada (candidata)

**Telepathic Foresight (B→Ativa/E)**

Sabedoria CD 15; vínculo concede vantagem ofensiva ou desvantagem nos ataques do alvo.

**Revisão:** Transferir beneficiário é homebrew; confirmar duração/edição.

## Mecânica disponível na fonte do pacote

Bloco estruturado de pesquisa individual; pode conter lacunas e conflitos de edição.

```json
{
  "estatisticas": {
    "armor_class": 16,
    "hit_points": 135,
    "hit_dice": "10d20+30",
    "ability_scores": {
      "STR": 19,
      "DEX": 13,
      "CON": 16,
      "INT": 9,
      "WIS": 13,
      "CHA": 4
    },
    "speeds": {
      "andar_ft": 10,
      "nadar_ft": 60
    },
    "senses": [
      "blindsight 120 ft."
    ],
    "skills": {
      "Perception": 4
    },
    "saving_throws": {
      "STR": 7
    },
    "languages": [
      "Aquan",
      "telepathy 120 ft."
    ],
    "damage_resistances": [
      "cold",
      "bludgeoning/piercing/slashing não mágicos"
    ],
    "damage_immunities": null,
    "damage_vulnerabilities": null,
    "condition_immunities": [
      "prone"
    ]
  },
  "mecanicas": {
    "traits": [
      {
        "name": "Charge",
        "kind": "passive",
        "legacy_summary": "Após avanço retilíneo de 20 ft. e ataque com barbatana no mesmo turno, soma 5d10 cortante.",
        "status": "INCOMPLETA",
        "attack_bonus": null,
        "range": null,
        "targets": null,
        "damage": null,
        "dc": null,
        "save": null,
        "conditions": null,
        "duration": null,
        "recharge": null,
        "uses": null
      },
      {
        "name": "Siege Monster",
        "kind": "passive",
        "legacy_summary": "Dano dobrado a objetos e construções.",
        "status": "INCOMPLETA",
        "attack_bonus": null,
        "range": null,
        "targets": null,
        "damage": null,
        "dc": null,
        "save": null,
        "conditions": null,
        "duration": null,
        "recharge": null,
        "uses": null
      },
      {
        "name": "Telepathic Foresight",
        "kind": "passive",
        "legacy_summary": "Ação bônus no início do turno; alvo a 120 ft. faz SAB CD15, e vínculo concede vantagem contra alvo ou impõe desvantagem contra criatura até turno seguinte.",
        "status": "INCOMPLETA",
        "attack_bonus": null,
        "range": null,
        "targets": null,
        "damage": null,
        "dc": null,
        "save": null,
        "conditions": null,
        "duration": null,
        "recharge": null,
        "uses": null
      },
      {
        "name": "Water Breathing",
        "kind": "passive",
        "legacy_summary": "Respira apenas na água.",
        "status": "INCOMPLETA",
        "attack_bonus": null,
        "range": null,
        "targets": null,
        "damage": null,
        "dc": null,
        "save": null,
        "conditions": null,
        "duration": null,
        "recharge": null,
        "uses": null
      }
    ],
    "actions": [
      {
        "name": "Multiattack",
        "kind": "action",
        "legacy_summary": "Um ataque de bico e um de garra.",
        "status": "INCOMPLETA",
        "attack_bonus": null,
        "range": null,
        "targets": null,
        "damage": null,
        "dc": null,
        "save": null,
        "conditions": null,
        "duration": null,
        "recharge": null,
        "uses": null
      },
      {
        "name": "Claw",
        "kind": "action",
        "legacy_summary": "+7; 5 ft.; 3d6+4 cortante.",
        "status": "INCOMPLETA",
        "attack_bonus": null,
        "range": null,
        "targets": null,
        "damage": null,
        "dc": null,
        "save": null,
        "conditions": null,
        "duration": null,
        "recharge": null,
        "uses": null
      },
      {
        "name": "Beak",
        "kind": "action",
        "legacy_summary": "+7; 5 ft.; 2d8+4 perfurante; criatura Large ou menor testa FOR CD15 ou é engolida; dentro sofre 4d6 ácido por turno e há regras de regurgitação.",
        "status": "INCOMPLETA",
        "attack_bonus": null,
        "range": null,
        "targets": null,
        "damage": null,
        "dc": null,
        "save": null,
        "conditions": null,
        "duration": null,
        "recharge": null,
        "uses": null
      },
      {
        "name": "Dorsal Fin",
        "kind": "action",
        "legacy_summary": "+7; 10 ft.; 3d10+4 cortante.",
        "status": "INCOMPLETA",
        "attack_bonus": null,
        "range": null,
        "targets": null,
        "damage": null,
        "dc": null,
        "save": null,
        "conditions": null,
        "duration": null,
        "recharge": null,
        "uses": null
      }
    ],
    "bonus_actions": null,
    "reactions": null,
    "legendary_actions": null,
    "lair_actions": null,
    "spellcasting": null,
    "other": null
  }
}
```

### Observações

Esta é uma ficha de pesquisa; a existência de informações não comprova a homologação. A ativação da carta de suporte não gasta ação, seus efeitos seguem SRD e ficha original e a carta utilizada vai para a pilha de descarte. Não inferir condições nem números ausentes.
