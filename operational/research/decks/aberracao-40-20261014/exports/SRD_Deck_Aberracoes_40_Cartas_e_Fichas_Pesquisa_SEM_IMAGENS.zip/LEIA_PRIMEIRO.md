# SRD Card Game — Deck experimental de 40 Aberrações (SEM IMAGENS)

Pacote compilado a partir da branch de pesquisa GitHub `chatgpt/aberracao-40-fichas-imagens-20261014`, em 15/10/2026.

## Conteúdo

- **40 cartas**, uma por arquivo Markdown, na pasta `01_CARTAS_40/`.
- **40 fichas**, uma por criatura em Markdown e outra em JSON, nas pastas `02_FICHAS_40/` e `02_FICHAS_40_JSON/`.
- `TABELA_COMPLETA_40_CARTAS.csv`, incluindo ND, raridade, CA, PV, iniciativa, habilidade de suporte e estado documental.
- `INDICE_40_CARTAS_SEM_IMAGENS.html`, para navegar pelo conjunto, sem arte.
- `03_FONTES_ORIGINAIS/`: CSV original de seleção, fichas de 35 registros do catálogo em pesquisa, **três blocos integrais SRD 5.2.1**, sete registros de pendência, decisões de suporte e README original.
- `04_PESQUISAS_MECANICAS_INDIVIDUAIS/`: **18 registros detalhados** adicionais recuperados do repositório, preservados sem transformar pesquisas parciais em fichas oficiais.
- `MANIFESTO.json`, com rastreabilidade e indicadores de completude.

## Observação crucial sobre fichas completas

O conjunto tem **40 criaturas selecionadas**, mas **NÃO há 40 fichas completas e homologadas** disponíveis no material de origem.

- **3** blocos integrais locais SRD 5.2.1: Gibbering Mouther, Roper e Aboleth (ainda requerem integração/teste na engine).
- **35** fichas/recortes de criaturas identificadas no catálogo 607, em diferentes níveis de auditoria e completude.
- **18** pesquisas mecânicas individuais (detalhes estruturados, muitos ainda marcados como parciais ou com ressalvas).
- **5** candidatas externas sem ficha completa integrada e sem aprovação para o Card Game.

Os números 3, 35 e 18 são **conjuntos sobrepostos**, não somáveis como fichas completas.

Campos não confirmados ficam como **Não confirmado**; não foram estimados ou preenchidos por suposição. A atribuição da licença do SRD foi preservada; material de outros editores foi incluído apenas nos resumos de pesquisa já presentes no repositório.

## Regras de suporte definidas

Cada carta de suporte é utilizada **sem custo de ativação** (não gasta ação, ação bônus nem reação), a carta usada vai para a **pilha de descarte**; efeitos, duração, acúmulo, recargas e demais limitações seguem a ficha de origem e o SRD. A transferência de habilidades próprias para a criatura ativa ainda requer análise individual.

**Nenhuma arte, ilustração ou imagem foi incluída, conforme solicitado.**

Link da fonte: https://github.com/george-vepo/SRD-Card-Game-607-Supervisor/tree/chatgpt/aberracao-40-fichas-imagens-20261014/operational/research/decks/aberracao-40-20261014/

**Este pacote é documental/de pesquisa e não homologação de cartas.**
