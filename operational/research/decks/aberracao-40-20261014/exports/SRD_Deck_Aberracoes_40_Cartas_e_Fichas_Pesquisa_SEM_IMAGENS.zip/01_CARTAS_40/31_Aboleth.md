# CARTA 31/40 — Aboleth

- **Tipo:** Aberração
- **ND:** 10
- **Raridade:** Incomum
- **ID do catálogo:** AT-003
- **Origem:** Catálogo 607
- **Publicação:** Catálogo ativo v1.1
- **CA:** 17
- **PV máximos:** 150
- **Iniciativa:** +7 (17)

## Habilidade de suporte (candidata)

- **Nome:** Dominate Mind (E)
- **Categoria:** Debuff
- **Efeito registrado:** SRD 5.2.1: Sabedoria CD 16, 2/dia; Enfeitiçado e controle conforme ficha.
- **Ressalvas:** Não tratar como vitória automática; usar gatilhos de fim do efeito.

## Regras do suporte

Ativação da carta sem custo de ação, ação bônus ou reação; duração, acúmulo, condições, usos e efeitos seguem a ficha original e o SRD. Após o uso, a carta vai à pilha de descarte. Não presumir homologação da transferência da habilidade à criatura ativa.

## Estado documental

SRD 5.2.1 — bloco integral local (revisão pendente). Carta de pesquisa; **não homologada** para a partida. Consulte a ficha 31_Aboleth.md e os arquivos de origem.

**Fonte:** https://www.dndbeyond.com/sources/dnd/srd-5.2.1
