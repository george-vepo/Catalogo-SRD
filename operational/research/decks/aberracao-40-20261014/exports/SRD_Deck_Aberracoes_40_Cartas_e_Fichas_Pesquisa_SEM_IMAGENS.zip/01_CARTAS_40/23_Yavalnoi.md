# CARTA 23/40 — Yavalnoi

- **Tipo:** Aberração
- **ND:** 6
- **Raridade:** Incomum
- **ID do catálogo:** TF-013
- **Origem:** Catálogo 607
- **Publicação:** Tome of Beasts 2
- **CA:** 16
- **PV máximos:** 126
- **Iniciativa:** Não confirmado

## Habilidade de suporte (candidata)

- **Nome:** Luminous Burst (E)
- **Categoria:** Debuff
- **Efeito registrado:** Sabedoria CD 15; marca alvo e facilita ataques contra ele.
- **Ressalvas:** Recarga 5–6; confirmar ficha integral e respiração aquática.

## Regras do suporte

Ativação da carta sem custo de ação, ação bônus ou reação; duração, acúmulo, condições, usos e efeitos seguem a ficha original e o SRD. Após o uso, a carta vai à pilha de descarte. Não presumir homologação da transferência da habilidade à criatura ativa.

## Estado documental

PESQUISA MECÂNICA INDIVIDUAL — não homologada. Carta de pesquisa; **não homologada** para a partida. Consulte a ficha 23_Yavalnoi.md e os arquivos de origem.

**Fonte:** https://koboldpress.com/tools/kobold-press-monsters/
