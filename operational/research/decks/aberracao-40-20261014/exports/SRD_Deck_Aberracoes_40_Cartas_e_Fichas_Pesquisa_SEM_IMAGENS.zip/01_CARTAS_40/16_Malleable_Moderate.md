# CARTA 16/40 — Malleable, Moderate

- **Tipo:** Aberração
- **ND:** 5
- **Raridade:** Comum
- **ID do catálogo:** TF-276
- **Origem:** Catálogo 607
- **Publicação:** Tome of Beasts 2
- **CA:** 12
- **PV máximos:** 136
- **Iniciativa:** -1 (mod. DES; derivado)

## Habilidade de suporte (candidata)

- **Nome:** Flesh Tendril (D/E)
- **Categoria:** Misto (Dano e Debuff; principal a revisar)
- **Efeito registrado:** +7, 3d6+4 contundente; Agarrado.
- **Ressalvas:** Substitui Psychic Absorption/Psychic Drain dependente de agarrão prévio.

## Regras do suporte

Ativação da carta sem custo de ação, ação bônus ou reação; duração, acúmulo, condições, usos e efeitos seguem a ficha original e o SRD. Após o uso, a carta vai à pilha de descarte. Não presumir homologação da transferência da habilidade à criatura ativa.

## Estado documental

PESQUISA MECÂNICA INDIVIDUAL — não homologada. Carta de pesquisa; **não homologada** para a partida. Consulte a ficha 16_Malleable_Moderate.md e os arquivos de origem.

**Fonte:** https://koboldpress.com/tools/kobold-press-monsters/
