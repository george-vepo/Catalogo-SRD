# CARTA 7/40 — Birgemon Seal

- **Tipo:** Aberração
- **ND:** 2
- **Raridade:** Comum
- **ID do catálogo:** TF-005
- **Origem:** Catálogo 607
- **Publicação:** Tome of Beasts 3
- **CA:** 12
- **PV máximos:** 60
- **Iniciativa:** +2

## Habilidade de suporte (candidata)

- **Nome:** Tendril (E)
- **Categoria:** Debuff
- **Efeito registrado:** Agarrado; dois tentáculos no mesmo alvo podem impor Contido; escape CD 13.
- **Ressalvas:** Dois tentáculos exigem duas aplicações válidas, não apenas um acerto.

## Regras do suporte

Ativação da carta sem custo de ação, ação bônus ou reação; duração, acúmulo, condições, usos e efeitos seguem a ficha original e o SRD. Após o uso, a carta vai à pilha de descarte. Não presumir homologação da transferência da habilidade à criatura ativa.

## Estado documental

RESUMO MECÂNICO DE PESQUISA — não integral. Carta de pesquisa; **não homologada** para a partida. Consulte a ficha 07_Birgemon_Seal.md e os arquivos de origem.

**Fonte:** https://www.5esrd.com/database/creature/birgemon-seal/
