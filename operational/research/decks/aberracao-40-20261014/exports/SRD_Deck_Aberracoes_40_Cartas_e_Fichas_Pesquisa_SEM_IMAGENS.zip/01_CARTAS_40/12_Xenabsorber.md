# CARTA 12/40 — Xenabsorber

- **Tipo:** Aberração
- **ND:** 3
- **Raridade:** Comum
- **ID do catálogo:** TF-006
- **Origem:** Catálogo 607
- **Publicação:** Creature Codex
- **CA:** 15
- **PV máximos:** 65
- **Iniciativa:** +1

## Habilidade de suporte (candidata)

- **Nome:** Slam (D)
- **Categoria:** Dano
- **Efeito registrado:** +5, 1d10+3 contundente.
- **Ressalvas:** Trait Mimicry depende de imitação e alvo elegível; fonte em resumo.

## Regras do suporte

Ativação da carta sem custo de ação, ação bônus ou reação; duração, acúmulo, condições, usos e efeitos seguem a ficha original e o SRD. Após o uso, a carta vai à pilha de descarte. Não presumir homologação da transferência da habilidade à criatura ativa.

## Estado documental

RESUMO MECÂNICO DE PESQUISA — não integral. Carta de pesquisa; **não homologada** para a partida. Consulte a ficha 12_Xenabsorber.md e os arquivos de origem.

**Fonte:** https://www.5esrd.com/database/creature/xenabsorber/
