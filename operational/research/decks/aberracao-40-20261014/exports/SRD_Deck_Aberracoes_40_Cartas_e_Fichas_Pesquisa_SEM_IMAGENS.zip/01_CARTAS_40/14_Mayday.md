# CARTA 14/40 — Mayday

- **Tipo:** Aberração
- **ND:** 4
- **Raridade:** Comum
- **ID do catálogo:** TF-520
- **Origem:** Catálogo 607
- **Publicação:** A5E — diversos suplementos
- **CA:** 14
- **PV máximos:** 300
- **Iniciativa:** Dex +2 (12), Insight +2 (12), Perception +2 (12)

## Habilidade de suporte (candidata)

- **Nome:** Pseudopod (D/E)
- **Categoria:** Misto (Dano e Debuff; principal a revisar)
- **Efeito registrado:** +6, 4d8+4 contundente; aplica Sticky conforme ficha.
- **Ressalvas:** Preservar restrições de alvo não aderido e regras de sair do agarrão/adesão.

## Regras do suporte

Ativação da carta sem custo de ação, ação bônus ou reação; duração, acúmulo, condições, usos e efeitos seguem a ficha original e o SRD. Após o uso, a carta vai à pilha de descarte. Não presumir homologação da transferência da habilidade à criatura ativa.

## Estado documental

RESUMO MECÂNICO DE PESQUISA — não integral. Carta de pesquisa; **não homologada** para a partida. Consulte a ficha 14_Mayday.md e os arquivos de origem.

**Fonte:** https://a5e.tools/node/5326
