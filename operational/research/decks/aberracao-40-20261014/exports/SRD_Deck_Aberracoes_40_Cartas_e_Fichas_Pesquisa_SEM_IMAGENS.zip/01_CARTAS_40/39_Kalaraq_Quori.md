# CARTA 39/40 — Kalaraq Quori

- **Tipo:** Aberração
- **ND:** 19
- **Raridade:** Lendária
- **ID do catálogo:** Ainda não possui
- **Origem:** Candidata externa (não aprovada)
- **Publicação:** Eberron: Rising from the Last War
- **CA:** Não confirmado
- **PV máximos:** Não confirmado
- **Iniciativa:** Não confirmado

## Habilidade de suporte (candidata)

- **Nome:** Swarm of Eyes (E/D)
- **Categoria:** Misto (Dano e Debuff; principal a revisar)
- **Efeito registrado:** Sabedoria CD 21; 10d8 psíquico e possível Cego.
- **Ressalvas:** Ficha externa Eberron não integrada; recarga 6, novos testes.

## Regras do suporte

Ativação da carta sem custo de ação, ação bônus ou reação; duração, acúmulo, condições, usos e efeitos seguem a ficha original e o SRD. Após o uso, a carta vai à pilha de descarte. Não presumir homologação da transferência da habilidade à criatura ativa.

## Estado documental

FICHA EXTERNA NÃO INTEGRADA. Carta de pesquisa; **não homologada** para a partida. Consulte a ficha 39_Kalaraq_Quori.md e os arquivos de origem.

**Fonte:** https://www.dndbeyond.com/monsters?page=177&sort=-type
