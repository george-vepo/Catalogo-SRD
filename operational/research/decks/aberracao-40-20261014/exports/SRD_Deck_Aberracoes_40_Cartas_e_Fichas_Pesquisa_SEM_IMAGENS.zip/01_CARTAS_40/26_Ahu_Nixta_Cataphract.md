# CARTA 26/40 — Ahu-Nixta, Cataphract

- **Tipo:** Aberração
- **ND:** 8
- **Raridade:** Incomum
- **ID do catálogo:** TF-008
- **Origem:** Catálogo 607
- **Publicação:** Tome of Beasts 2
- **CA:** 17
- **PV máximos:** 135
- **Iniciativa:** -1

## Habilidade de suporte (candidata)

- **Nome:** Fear (E)
- **Categoria:** Debuff
- **Efeito registrado:** Magia inata de medo, CD 15.
- **Ressalvas:** Confirmar recursos de magia integral.

## Regras do suporte

Ativação da carta sem custo de ação, ação bônus ou reação; duração, acúmulo, condições, usos e efeitos seguem a ficha original e o SRD. Após o uso, a carta vai à pilha de descarte. Não presumir homologação da transferência da habilidade à criatura ativa.

## Estado documental

RESUMO MECÂNICO DE PESQUISA — não integral. Carta de pesquisa; **não homologada** para a partida. Consulte a ficha 26_Ahu_Nixta_Cataphract.md e os arquivos de origem.

**Fonte:** https://www.5esrd.com/database/creature/ahu-nixta-cataphract/
