# CARTA 15/40 — Asanbosam

- **Tipo:** Aberração
- **ND:** 5
- **Raridade:** Comum
- **ID do catálogo:** TF-003
- **Origem:** Catálogo 607
- **Publicação:** Tome of Beasts 1
- **CA:** 14
- **PV máximos:** 102
- **Iniciativa:** +1

## Habilidade de suporte (candidata)

- **Nome:** Claws (E/D)
- **Categoria:** Misto (Dano e Debuff; principal a revisar)
- **Efeito registrado:** +7, 3d10+4 perfurante; Agarrado/Contido, fuga CD 14 e possível doença.
- **Ressalvas:** Verificar condições, salvaguarda de doença e duração.

## Regras do suporte

Ativação da carta sem custo de ação, ação bônus ou reação; duração, acúmulo, condições, usos e efeitos seguem a ficha original e o SRD. Após o uso, a carta vai à pilha de descarte. Não presumir homologação da transferência da habilidade à criatura ativa.

## Estado documental

RESUMO MECÂNICO DE PESQUISA — não integral. Carta de pesquisa; **não homologada** para a partida. Consulte a ficha 15_Asanbosam.md e os arquivos de origem.

**Fonte:** https://www.5esrd.com/database/creature/asanbosam-3pp/
