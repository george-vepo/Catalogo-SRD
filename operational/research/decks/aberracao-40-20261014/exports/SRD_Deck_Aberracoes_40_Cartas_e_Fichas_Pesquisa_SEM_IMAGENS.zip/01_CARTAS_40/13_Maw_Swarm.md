# CARTA 13/40 — Maw Swarm

- **Tipo:** Aberração
- **ND:** 4
- **Raridade:** Comum
- **ID do catálogo:** TF-275
- **Origem:** Catálogo 607
- **Publicação:** Dungeon Delver's Guide
- **CA:** 13
- **PV máximos:** 71
- **Iniciativa:** +3

## Habilidade de suporte (candidata)

- **Nome:** Bites (D)
- **Categoria:** Dano
- **Efeito registrado:** +5, 4d6+3 perfurante; 2d6+3 quando bloodied.
- **Ressalvas:** Não confundir redução de dado de dano com redução de PV do suporte.

## Regras do suporte

Ativação da carta sem custo de ação, ação bônus ou reação; duração, acúmulo, condições, usos e efeitos seguem a ficha original e o SRD. Após o uso, a carta vai à pilha de descarte. Não presumir homologação da transferência da habilidade à criatura ativa.

## Estado documental

RESUMO MECÂNICO DE PESQUISA — não integral. Carta de pesquisa; **não homologada** para a partida. Consulte a ficha 13_Maw_Swarm.md e os arquivos de origem.

**Fonte:** https://a5e.tools/node/2840
