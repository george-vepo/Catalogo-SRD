# CARTA 1/40 — Ahu-Nixta, Drudge

- **Tipo:** Aberração
- **ND:** 0.5
- **Raridade:** Comum
- **ID do catálogo:** TF-002
- **Origem:** Catálogo 607
- **Publicação:** Tome of Beasts 2
- **CA:** 13
- **PV máximos:** 26
- **Iniciativa:** +1

## Habilidade de suporte (candidata)

- **Nome:** Fear (E)
- **Categoria:** Debuff
- **Efeito registrado:** Magia inata de medo; ficha de pesquisa registra CD 11, 1/dia.
- **Ressalvas:** Conferir a magia integral e recursos.

## Regras do suporte

Ativação da carta sem custo de ação, ação bônus ou reação; duração, acúmulo, condições, usos e efeitos seguem a ficha original e o SRD. Após o uso, a carta vai à pilha de descarte. Não presumir homologação da transferência da habilidade à criatura ativa.

## Estado documental

RESUMO MECÂNICO DE PESQUISA — não integral. Carta de pesquisa; **não homologada** para a partida. Consulte a ficha 01_Ahu_Nixta_Drudge.md e os arquivos de origem.

**Fonte:** https://www.5esrd.com/database/creature/ahu-nixta-drudge/
