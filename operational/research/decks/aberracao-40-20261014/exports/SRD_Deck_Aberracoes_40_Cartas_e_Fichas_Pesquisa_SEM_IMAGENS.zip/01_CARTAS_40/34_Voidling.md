# CARTA 34/40 — Voidling

- **Tipo:** Aberração
- **ND:** 11
- **Raridade:** Rara
- **ID do catálogo:** TF-018
- **Origem:** Catálogo 607
- **Publicação:** Tome of Beasts 1
- **CA:** 15
- **PV máximos:** 180
- **Iniciativa:** Não confirmado

## Habilidade de suporte (candidata)

- **Nome:** Shadow's Grasp (E/D)
- **Categoria:** Misto (Dano e Debuff; principal a revisar)
- **Efeito registrado:** Destreza CD 17; 14d6 necrótico e Contido na falha, conforme ficha.
- **Ressalvas:** Recarga 5–6, duração/testes, edição.

## Regras do suporte

Ativação da carta sem custo de ação, ação bônus ou reação; duração, acúmulo, condições, usos e efeitos seguem a ficha original e o SRD. Após o uso, a carta vai à pilha de descarte. Não presumir homologação da transferência da habilidade à criatura ativa.

## Estado documental

PESQUISA MECÂNICA INDIVIDUAL — não homologada. Carta de pesquisa; **não homologada** para a partida. Consulte a ficha 34_Voidling.md e os arquivos de origem.

**Fonte:** https://koboldpress.com/tools/kobold-press-monsters/
