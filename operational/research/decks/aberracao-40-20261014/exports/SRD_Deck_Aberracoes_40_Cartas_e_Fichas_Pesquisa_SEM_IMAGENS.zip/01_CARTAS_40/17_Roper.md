# CARTA 17/40 — Roper

- **Tipo:** Aberração
- **ND:** 5
- **Raridade:** Comum
- **ID do catálogo:** AT-002
- **Origem:** Catálogo 607
- **Publicação:** Catálogo ativo v1.1
- **CA:** 20
- **PV máximos:** 93
- **Iniciativa:** +5 (15)

## Habilidade de suporte (candidata)

- **Nome:** Tentacle (E)
- **Categoria:** Debuff
- **Efeito registrado:** +7; Agarrado e Envenenado, fuga CD 14.
- **Ressalvas:** SRD 5.2.1; não inventar dano para o tentáculo.

## Regras do suporte

Ativação da carta sem custo de ação, ação bônus ou reação; duração, acúmulo, condições, usos e efeitos seguem a ficha original e o SRD. Após o uso, a carta vai à pilha de descarte. Não presumir homologação da transferência da habilidade à criatura ativa.

## Estado documental

SRD 5.2.1 — bloco integral local (revisão pendente). Carta de pesquisa; **não homologada** para a partida. Consulte a ficha 17_Roper.md e os arquivos de origem.

**Fonte:** https://www.dndbeyond.com/monsters/16999-roper
