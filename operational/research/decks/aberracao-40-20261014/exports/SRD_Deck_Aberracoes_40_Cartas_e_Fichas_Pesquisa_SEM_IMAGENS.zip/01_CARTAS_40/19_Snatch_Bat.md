# CARTA 19/40 — Snatch Bat

- **Tipo:** Aberração
- **ND:** 5
- **Raridade:** Comum
- **ID do catálogo:** TF-278
- **Origem:** Catálogo 607
- **Publicação:** Tome of Beasts 3
- **CA:** 16
- **PV máximos:** 97
- **Iniciativa:** +5 (mod. DES; derivado)

## Habilidade de suporte (candidata)

- **Nome:** Pilfering Bite (D)
- **Categoria:** Dano
- **Efeito registrado:** Ataque +8, 2d4+5 perfurante na opção de dano.
- **Ressalvas:** Não aplicar roubo de item sem regras de equipamentos.

## Regras do suporte

Ativação da carta sem custo de ação, ação bônus ou reação; duração, acúmulo, condições, usos e efeitos seguem a ficha original e o SRD. Após o uso, a carta vai à pilha de descarte. Não presumir homologação da transferência da habilidade à criatura ativa.

## Estado documental

PESQUISA MECÂNICA INDIVIDUAL — não homologada. Carta de pesquisa; **não homologada** para a partida. Consulte a ficha 19_Snatch_Bat.md e os arquivos de origem.

**Fonte:** https://koboldpress.com/tools/kobold-press-monsters/
