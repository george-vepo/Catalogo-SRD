# CARTA 24/40 — Chelicerae

- **Tipo:** Aberração
- **ND:** 7
- **Raridade:** Incomum
- **ID do catálogo:** TF-010
- **Origem:** Catálogo 607
- **Publicação:** Tome of Beasts 1
- **CA:** 16
- **PV máximos:** 153
- **Iniciativa:** Não confirmado

## Habilidade de suporte (candidata)

- **Nome:** Magical Discharge (D)
- **Categoria:** Dano
- **Efeito registrado:** Destreza CD 15; 8d8 força, metade no sucesso.
- **Ressalvas:** Edição revisada versus original: não misturar; recarga especial.

## Regras do suporte

Ativação da carta sem custo de ação, ação bônus ou reação; duração, acúmulo, condições, usos e efeitos seguem a ficha original e o SRD. Após o uso, a carta vai à pilha de descarte. Não presumir homologação da transferência da habilidade à criatura ativa.

## Estado documental

PESQUISA MECÂNICA INDIVIDUAL — não homologada. Carta de pesquisa; **não homologada** para a partida. Consulte a ficha 24_Chelicerae.md e os arquivos de origem.

**Fonte:** https://www.5esrd.com/database/creature/chelicerae-3pp/
