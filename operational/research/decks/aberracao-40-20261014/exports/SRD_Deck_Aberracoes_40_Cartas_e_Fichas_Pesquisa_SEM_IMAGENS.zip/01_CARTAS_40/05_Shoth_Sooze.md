# CARTA 5/40 — Shoth, Sooze

- **Tipo:** Aberração
- **ND:** 1/2
- **Raridade:** Comum
- **ID do catálogo:** TF-273
- **Origem:** Catálogo 607
- **Publicação:** Creature Codex
- **CA:** 12
- **PV máximos:** 49
- **Iniciativa:** +0 (mod. DES; derivado)

## Habilidade de suporte (candidata)

- **Nome:** Warrior (B→Ativa)
- **Categoria:** Buff
- **Efeito registrado:** Proposta: transferir +2 CA da variante Warrior.
- **Ressalvas:** Dependente da escolha de variante; não transformar vantagem condicional em vantagem irrestrita.

## Regras do suporte

Ativação da carta sem custo de ação, ação bônus ou reação; duração, acúmulo, condições, usos e efeitos seguem a ficha original e o SRD. Após o uso, a carta vai à pilha de descarte. Não presumir homologação da transferência da habilidade à criatura ativa.

## Estado documental

PESQUISA MECÂNICA INDIVIDUAL — não homologada. Carta de pesquisa; **não homologada** para a partida. Consulte a ficha 05_Shoth_Sooze.md e os arquivos de origem.

**Fonte:** https://koboldpress.com/tools/kobold-press-monsters/
