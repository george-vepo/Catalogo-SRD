# CARTA 4/40 — Light Eater

- **Tipo:** Aberração
- **ND:** 1/2
- **Raridade:** Comum
- **ID do catálogo:** TF-272
- **Origem:** Catálogo 607
- **Publicação:** Tome of Beasts 3
- **CA:** 14
- **PV máximos:** 26
- **Iniciativa:** +2 (mod. DES; derivado)

## Habilidade de suporte (candidata)

- **Nome:** Tentacle (D)
- **Categoria:** Dano
- **Efeito registrado:** Ataque +4; 1d6+2 contundente.
- **Ressalvas:** Troca de Emergency Flare por depender de gatilho e envolver área.

## Regras do suporte

Ativação da carta sem custo de ação, ação bônus ou reação; duração, acúmulo, condições, usos e efeitos seguem a ficha original e o SRD. Após o uso, a carta vai à pilha de descarte. Não presumir homologação da transferência da habilidade à criatura ativa.

## Estado documental

PESQUISA MECÂNICA INDIVIDUAL — não homologada. Carta de pesquisa; **não homologada** para a partida. Consulte a ficha 04_Light_Eater.md e os arquivos de origem.

**Fonte:** https://koboldpress.com/tools/kobold-press-monsters/
