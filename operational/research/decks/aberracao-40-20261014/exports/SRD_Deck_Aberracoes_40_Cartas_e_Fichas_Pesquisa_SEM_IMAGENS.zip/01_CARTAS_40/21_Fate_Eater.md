# CARTA 21/40 — Fate Eater

- **Tipo:** Aberração
- **ND:** 6
- **Raridade:** Incomum
- **ID do catálogo:** TF-279
- **Origem:** Catálogo 607
- **Publicação:** Tome of Beasts 1
- **CA:** 16
- **PV máximos:** 130
- **Iniciativa:** +1 (mod. DES; derivado)

## Habilidade de suporte (candidata)

- **Nome:** Alter Fate (E/D)
- **Categoria:** Misto (Dano e Debuff; principal a revisar)
- **Efeito registrado:** Carisma CD 15; na falha, 8d8 psíquico e efeito de destino sorteado 1d6, conforme ficha.
- **Ressalvas:** Recarga 5–6; não simplificar tabela de efeitos.

## Regras do suporte

Ativação da carta sem custo de ação, ação bônus ou reação; duração, acúmulo, condições, usos e efeitos seguem a ficha original e o SRD. Após o uso, a carta vai à pilha de descarte. Não presumir homologação da transferência da habilidade à criatura ativa.

## Estado documental

PESQUISA MECÂNICA INDIVIDUAL — não homologada. Carta de pesquisa; **não homologada** para a partida. Consulte a ficha 21_Fate_Eater.md e os arquivos de origem.

**Fonte:** https://koboldpress.com/tools/kobold-press-monsters/
