# CARTA 9/40 — Yann-An-Oed

- **Tipo:** Aberração
- **ND:** 2
- **Raridade:** Comum
- **ID do catálogo:** TF-007
- **Origem:** Catálogo 607
- **Publicação:** Creature Codex
- **CA:** 12
- **PV máximos:** 47
- **Iniciativa:** +0

## Habilidade de suporte (candidata)

- **Nome:** Tentacles (E/D)
- **Categoria:** Misto (Dano e Debuff; principal a revisar)
- **Efeito registrado:** +4, 2d4+2 contundente; Agarrado/Contido, escape CD 12.
- **Ressalvas:** Manter pré-condições de tamanho e limite de alvos não espaciais.

## Regras do suporte

Ativação da carta sem custo de ação, ação bônus ou reação; duração, acúmulo, condições, usos e efeitos seguem a ficha original e o SRD. Após o uso, a carta vai à pilha de descarte. Não presumir homologação da transferência da habilidade à criatura ativa.

## Estado documental

RESUMO MECÂNICO DE PESQUISA — não integral. Carta de pesquisa; **não homologada** para a partida. Consulte a ficha 09_Yann_An_Oed.md e os arquivos de origem.

**Fonte:** https://www.dndgrove.com/bestiary/2/yann-an-oed
