# CARTA 27/40 — Astral Devourer

- **Tipo:** Aberração
- **ND:** 8
- **Raridade:** Incomum
- **ID do catálogo:** TF-009
- **Origem:** Catálogo 607
- **Publicação:** Tome of Beasts 2
- **CA:** 16
- **PV máximos:** 90
- **Iniciativa:** +3

## Habilidade de suporte (candidata)

- **Nome:** Serpent Spray (Cura→Ativa; dano associado)
- **Categoria:** Cura
- **Efeito registrado:** Destreza CD 16; 4d6 perfurante + 4d6 veneno na falha, metade no sucesso. A criatura ativa recuperaria PV iguais ao maior dano perfurante individual efetivamente causado pelo spray (proposta de transferência).
- **Ressalvas:** Ícone: Cura verde. Recarga 6; efeito misto dano + cura; sem cura se não houver dano perfurante causado; a transferência é homebrew não homologado.

## Regras do suporte

Ativação da carta sem custo de ação, ação bônus ou reação; duração, acúmulo, condições, usos e efeitos seguem a ficha original e o SRD. Após o uso, a carta vai à pilha de descarte. Não presumir homologação da transferência da habilidade à criatura ativa.

## Estado documental

RESUMO MECÂNICO DE PESQUISA — não integral. Carta de pesquisa; **não homologada** para a partida. Consulte a ficha 27_Astral_Devourer.md e os arquivos de origem.

**Fonte:** https://www.5esrd.com/database/creature/astral-devourer/
