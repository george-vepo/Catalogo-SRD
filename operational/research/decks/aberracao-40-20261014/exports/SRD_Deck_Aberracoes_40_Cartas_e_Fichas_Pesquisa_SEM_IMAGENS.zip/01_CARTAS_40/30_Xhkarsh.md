# CARTA 30/40 — Xhkarsh

- **Tipo:** Aberração
- **ND:** 9
- **Raridade:** Incomum
- **ID do catálogo:** TF-012
- **Origem:** Catálogo 607
- **Publicação:** Tome of Beasts 1
- **CA:** 18
- **PV máximos:** 171
- **Iniciativa:** Não confirmado

## Habilidade de suporte (candidata)

- **Nome:** Fate-Altering Stinger (E/D)
- **Categoria:** Misto (Dano e Debuff; principal a revisar)
- **Efeito registrado:** +8, 2d10+4 perfurante; Carisma CD 16 pode corromper o destino.
- **Ressalvas:** Fixar edição 2023 antes de executar.

## Regras do suporte

Ativação da carta sem custo de ação, ação bônus ou reação; duração, acúmulo, condições, usos e efeitos seguem a ficha original e o SRD. Após o uso, a carta vai à pilha de descarte. Não presumir homologação da transferência da habilidade à criatura ativa.

## Estado documental

PESQUISA MECÂNICA INDIVIDUAL — não homologada. Carta de pesquisa; **não homologada** para a partida. Consulte a ficha 30_Xhkarsh.md e os arquivos de origem.

**Fonte:** https://koboldpress.com/tools/kobold-press-monsters/
