# CARTA 32/40 — Malleable, Major

- **Tipo:** Aberração
- **ND:** 10
- **Raridade:** Incomum
- **ID do catálogo:** TF-284
- **Origem:** Catálogo 607
- **Publicação:** Tome of Beasts 2
- **CA:** 13
- **PV máximos:** 218
- **Iniciativa:** -1 (mod. DES; derivado)

## Habilidade de suporte (candidata)

- **Nome:** Flesh Tendril (D/E)
- **Categoria:** Misto (Dano e Debuff; principal a revisar)
- **Efeito registrado:** +10, 4d6+6 contundente e possível Agarrado.
- **Ressalvas:** Evita bônus de absorção psíquica muito situacional.

## Regras do suporte

Ativação da carta sem custo de ação, ação bônus ou reação; duração, acúmulo, condições, usos e efeitos seguem a ficha original e o SRD. Após o uso, a carta vai à pilha de descarte. Não presumir homologação da transferência da habilidade à criatura ativa.

## Estado documental

PESQUISA MECÂNICA INDIVIDUAL — não homologada. Carta de pesquisa; **não homologada** para a partida. Consulte a ficha 32_Malleable_Major.md e os arquivos de origem.

**Fonte:** https://koboldpress.com/tools/kobold-press-monsters/
