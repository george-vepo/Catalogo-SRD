# CARTA 29/40 — Shukankor

- **Tipo:** Aberração
- **ND:** 9
- **Raridade:** Incomum
- **ID do catálogo:** TF-283
- **Origem:** Catálogo 607
- **Publicação:** Tome of Beasts 2
- **CA:** 17
- **PV máximos:** 115
- **Iniciativa:** +1 (mod. DES; derivado)

## Habilidade de suporte (candidata)

- **Nome:** Beak (D)
- **Categoria:** Dano
- **Efeito registrado:** +10, 2d8+6 perfurante.
- **Ressalvas:** Many Eyes beneficiaria só testes raros; dano mais aplicável.

## Regras do suporte

Ativação da carta sem custo de ação, ação bônus ou reação; duração, acúmulo, condições, usos e efeitos seguem a ficha original e o SRD. Após o uso, a carta vai à pilha de descarte. Não presumir homologação da transferência da habilidade à criatura ativa.

## Estado documental

PESQUISA MECÂNICA INDIVIDUAL — não homologada. Carta de pesquisa; **não homologada** para a partida. Consulte a ficha 29_Shukankor.md e os arquivos de origem.

**Fonte:** https://koboldpress.com/tools/kobold-press-monsters/
