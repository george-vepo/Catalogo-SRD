# CARTA 33/40 — Ancient Aboleth

- **Tipo:** Aberração
- **ND:** 11
- **Raridade:** Rara
- **ID do catálogo:** TF-017
- **Origem:** Catálogo 607
- **Publicação:** Monstrous Menagerie
- **CA:** 17
- **PV máximos:** 342
- **Iniciativa:** +1

## Habilidade de suporte (candidata)

- **Nome:** Legendary Resistance (B→Ativa)
- **Categoria:** Buff
- **Efeito registrado:** Proposta: a ativa pode transformar falha em resistência em sucesso.
- **Ressalvas:** Fonte tem 3/dia; preservar os usos e limites conforme ficha/SRD. A carta de suporte não possui custo de ativação e segue para o descarte; validar transferência individual à ativa.

## Regras do suporte

Ativação da carta sem custo de ação, ação bônus ou reação; duração, acúmulo, condições, usos e efeitos seguem a ficha original e o SRD. Após o uso, a carta vai à pilha de descarte. Não presumir homologação da transferência da habilidade à criatura ativa.

## Estado documental

RESUMO MECÂNICO DE PESQUISA — não integral. Carta de pesquisa; **não homologada** para a partida. Consulte a ficha 33_Ancient_Aboleth.md e os arquivos de origem.

**Fonte:** https://a5e.tools/node/1459
