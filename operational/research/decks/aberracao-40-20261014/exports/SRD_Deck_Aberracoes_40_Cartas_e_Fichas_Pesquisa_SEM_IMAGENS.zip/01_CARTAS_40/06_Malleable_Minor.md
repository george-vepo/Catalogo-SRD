# CARTA 6/40 — Malleable, Minor

- **Tipo:** Aberração
- **ND:** 1
- **Raridade:** Comum
- **ID do catálogo:** TF-274
- **Origem:** Catálogo 607
- **Publicação:** Tome of Beasts 2
- **CA:** 11
- **PV máximos:** 32
- **Iniciativa:** -1 (mod. DES; derivado)

## Habilidade de suporte (candidata)

- **Nome:** Flesh Tendril (D/E)
- **Categoria:** Misto (Dano e Debuff; principal a revisar)
- **Efeito registrado:** 2d6+3 contundente e Agarrado conforme a ficha.
- **Ressalvas:** Substitui Psychic Absorption por ser situacional.

## Regras do suporte

Ativação da carta sem custo de ação, ação bônus ou reação; duração, acúmulo, condições, usos e efeitos seguem a ficha original e o SRD. Após o uso, a carta vai à pilha de descarte. Não presumir homologação da transferência da habilidade à criatura ativa.

## Estado documental

PESQUISA MECÂNICA INDIVIDUAL — não homologada. Carta de pesquisa; **não homologada** para a partida. Consulte a ficha 06_Malleable_Minor.md e os arquivos de origem.

**Fonte:** https://koboldpress.com/tools/kobold-press-monsters/
