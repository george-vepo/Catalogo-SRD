# CARTA 18/40 — Shoth, Oth

- **Tipo:** Aberração
- **ND:** 5
- **Raridade:** Comum
- **ID do catálogo:** TF-277
- **Origem:** Catálogo 607
- **Publicação:** Creature Codex
- **CA:** 15
- **PV máximos:** 119
- **Iniciativa:** +0 (mod. DES; derivado)

## Habilidade de suporte (candidata)

- **Nome:** Paladin of Shoth (B→Ativa)
- **Categoria:** Buff
- **Efeito registrado:** Proposta: +2 CA da variante Paladino transferidos à ativa.
- **Ressalvas:** Variante escolhida é requisito; manter outros efeitos só se elegíveis.

## Regras do suporte

Ativação da carta sem custo de ação, ação bônus ou reação; duração, acúmulo, condições, usos e efeitos seguem a ficha original e o SRD. Após o uso, a carta vai à pilha de descarte. Não presumir homologação da transferência da habilidade à criatura ativa.

## Estado documental

PESQUISA MECÂNICA INDIVIDUAL — não homologada. Carta de pesquisa; **não homologada** para a partida. Consulte a ficha 18_Shoth_Oth.md e os arquivos de origem.

**Fonte:** https://koboldpress.com/tools/kobold-press-monsters/
