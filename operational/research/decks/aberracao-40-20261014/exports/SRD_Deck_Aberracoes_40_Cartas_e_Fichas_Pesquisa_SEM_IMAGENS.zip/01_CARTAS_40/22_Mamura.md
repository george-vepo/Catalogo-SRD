# CARTA 22/40 — Mamura

- **Tipo:** Aberração
- **ND:** 6
- **Raridade:** Incomum
- **ID do catálogo:** TF-280
- **Origem:** Catálogo 607
- **Publicação:** Tome of Beasts 1
- **CA:** 16
- **PV máximos:** 112
- **Iniciativa:** +4 (mod. DES; derivado)

## Habilidade de suporte (candidata)

- **Nome:** Whiptail Stinger (E/D)
- **Categoria:** Misto (Dano e Debuff; principal a revisar)
- **Efeito registrado:** +7, 1d8+4 perfurante; Constituição CD 15 para veneno/Envenenado e efeitos subsequentes.
- **Ressalvas:** Preservar dano adicional, duração e novos testes.

## Regras do suporte

Ativação da carta sem custo de ação, ação bônus ou reação; duração, acúmulo, condições, usos e efeitos seguem a ficha original e o SRD. Após o uso, a carta vai à pilha de descarte. Não presumir homologação da transferência da habilidade à criatura ativa.

## Estado documental

PESQUISA MECÂNICA INDIVIDUAL — não homologada. Carta de pesquisa; **não homologada** para a partida. Consulte a ficha 22_Mamura.md e os arquivos de origem.

**Fonte:** https://koboldpress.com/tools/kobold-press-monsters/
