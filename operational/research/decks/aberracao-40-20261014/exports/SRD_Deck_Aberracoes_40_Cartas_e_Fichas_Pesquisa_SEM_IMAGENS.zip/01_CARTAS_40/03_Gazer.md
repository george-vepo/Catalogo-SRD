# CARTA 3/40 — Gazer

- **Tipo:** Aberração
- **ND:** 1/2
- **Raridade:** Comum
- **ID do catálogo:** Ainda não possui
- **Origem:** Candidata externa (não aprovada)
- **Publicação:** Mordenkainen Presents: Monsters of the Multiverse
- **CA:** Não confirmado
- **PV máximos:** Não confirmado
- **Iniciativa:** Não confirmado

## Habilidade de suporte (candidata)

- **Nome:** Eye Rays (E/D)
- **Categoria:** Misto (Dano e Debuff; principal a revisar)
- **Efeito registrado:** Dois raios determinados aleatoriamente, com controle/dano conforme edição.
- **Ressalvas:** Ficha externa; sortear raios, não escolher livremente.

## Regras do suporte

Ativação da carta sem custo de ação, ação bônus ou reação; duração, acúmulo, condições, usos e efeitos seguem a ficha original e o SRD. Após o uso, a carta vai à pilha de descarte. Não presumir homologação da transferência da habilidade à criatura ativa.

## Estado documental

FICHA EXTERNA NÃO INTEGRADA. Carta de pesquisa; **não homologada** para a partida. Consulte a ficha 03_Gazer.md e os arquivos de origem.

**Fonte:** https://www.dndbeyond.com/monsters?page=4&sort=type
