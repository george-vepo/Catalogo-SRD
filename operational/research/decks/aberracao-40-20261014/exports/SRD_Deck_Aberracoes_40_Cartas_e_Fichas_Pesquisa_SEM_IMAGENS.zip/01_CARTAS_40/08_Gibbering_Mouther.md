# CARTA 8/40 — Gibbering Mouther

- **Tipo:** Aberração
- **ND:** 2
- **Raridade:** Comum
- **ID do catálogo:** AT-001
- **Origem:** Catálogo 607
- **Publicação:** Catálogo ativo v1.1
- **CA:** 9
- **PV máximos:** 52
- **Iniciativa:** −1 (9)

## Habilidade de suporte (candidata)

- **Nome:** Gibbering (E)
- **Categoria:** Debuff
- **Efeito registrado:** Sabedoria CD 10; falha e 1d8 determinam comportamento.
- **Ressalvas:** SRD 5.2.1; preservar resultados completos do d8.

## Regras do suporte

Ativação da carta sem custo de ação, ação bônus ou reação; duração, acúmulo, condições, usos e efeitos seguem a ficha original e o SRD. Após o uso, a carta vai à pilha de descarte. Não presumir homologação da transferência da habilidade à criatura ativa.

## Estado documental

SRD 5.2.1 — bloco integral local (revisão pendente). Carta de pesquisa; **não homologada** para a partida. Consulte a ficha 08_Gibbering_Mouther.md e os arquivos de origem.

**Fonte:** https://www.dndbeyond.com/monsters/5195034-gibbering-mouther
