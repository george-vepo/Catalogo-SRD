# CARTA 20/40 — Mindwitness

- **Tipo:** Aberração
- **ND:** 5
- **Raridade:** Comum
- **ID do catálogo:** Ainda não possui
- **Origem:** Candidata externa (não aprovada)
- **Publicação:** Volo's Guide to Monsters
- **CA:** Não confirmado
- **PV máximos:** Não confirmado
- **Iniciativa:** Não confirmado

## Habilidade de suporte (candidata)

- **Nome:** Eye Rays (E/D)
- **Categoria:** Misto (Dano e Debuff; principal a revisar)
- **Efeito registrado:** Três raios aleatórios com efeitos de controle/dano.
- **Ressalvas:** Ficha externa Volo não integrada; fixar sorteio e edição.

## Regras do suporte

Ativação da carta sem custo de ação, ação bônus ou reação; duração, acúmulo, condições, usos e efeitos seguem a ficha original e o SRD. Após o uso, a carta vai à pilha de descarte. Não presumir homologação da transferência da habilidade à criatura ativa.

## Estado documental

FICHA EXTERNA NÃO INTEGRADA. Carta de pesquisa; **não homologada** para a partida. Consulte a ficha 20_Mindwitness.md e os arquivos de origem.

**Fonte:** https://www.dndbeyond.com/sources/dnd/vgtm
