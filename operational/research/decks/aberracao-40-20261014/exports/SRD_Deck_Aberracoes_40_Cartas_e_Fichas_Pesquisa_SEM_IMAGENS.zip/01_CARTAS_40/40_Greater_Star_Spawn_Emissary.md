# CARTA 40/40 — Greater Star Spawn Emissary

- **Tipo:** Aberração
- **ND:** 21
- **Raridade:** Mítica
- **ID do catálogo:** Ainda não possui
- **Origem:** Candidata externa (não aprovada)
- **Publicação:** Van Richten's Guide to Ravenloft (2014/legacy)
- **CA:** Não confirmado
- **PV máximos:** Não confirmado
- **Iniciativa:** Não confirmado

## Habilidade de suporte (candidata)

- **Nome:** Mind Cloud (E/D)
- **Categoria:** Misto (Dano e Debuff; principal a revisar)
- **Efeito registrado:** Sabedoria CD 23; 5d12 psíquico e encerramento de magias em alvos elegíveis.
- **Ressalvas:** Ficha externa Legacy não integrada; ação lendária custa 3 ações lendárias na proposta — verificar edição e economia de ações.

## Regras do suporte

Ativação da carta sem custo de ação, ação bônus ou reação; duração, acúmulo, condições, usos e efeitos seguem a ficha original e o SRD. Após o uso, a carta vai à pilha de descarte. Não presumir homologação da transferência da habilidade à criatura ativa.

## Estado documental

FICHA EXTERNA NÃO INTEGRADA. Carta de pesquisa; **não homologada** para a partida. Consulte a ficha 40_Greater_Star_Spawn_Emissary.md e os arquivos de origem.

**Fonte:** https://www.dndbeyond.com/monsters?page=176&sort=-type
