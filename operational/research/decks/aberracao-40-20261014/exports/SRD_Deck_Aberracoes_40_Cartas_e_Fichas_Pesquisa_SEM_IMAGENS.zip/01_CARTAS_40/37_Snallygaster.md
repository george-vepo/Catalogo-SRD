# CARTA 37/40 — Snallygaster

- **Tipo:** Aberração
- **ND:** 15
- **Raridade:** Rara
- **ID do catálogo:** TF-285
- **Origem:** Catálogo 607
- **Publicação:** Tome of Beasts 3
- **CA:** 16
- **PV máximos:** 207
- **Iniciativa:** Não confirmado

## Habilidade de suporte (candidata)

- **Nome:** Regeneration (Cura→Ativa)
- **Categoria:** Cura
- **Efeito registrado:** Proposta: a criatura ativa recupera 15 PV no início do seu turno se tiver pelo menos 1 PV e o efeito de suporte ainda estiver ativo conforme fonte/SRD; respeitar limite dos PV máximos.
- **Ressalvas:** Ícone: Cura verde. A ativação da carta não tem custo; duração e acúmulo seguem a ficha/SRD e a carta vai ao descarte. Ficha local TF-285 segue incompleta, embora a Regeneration esteja documentada na fonte pública.

## Regras do suporte

Ativação da carta sem custo de ação, ação bônus ou reação; duração, acúmulo, condições, usos e efeitos seguem a ficha original e o SRD. Após o uso, a carta vai à pilha de descarte. Não presumir homologação da transferência da habilidade à criatura ativa.

## Estado documental

PESQUISA MECÂNICA INDIVIDUAL — não homologada. Carta de pesquisa; **não homologada** para a partida. Consulte a ficha 37_Snallygaster.md e os arquivos de origem.

**Fonte:** https://www.5esrd.com/database/creature/snallygaster/
