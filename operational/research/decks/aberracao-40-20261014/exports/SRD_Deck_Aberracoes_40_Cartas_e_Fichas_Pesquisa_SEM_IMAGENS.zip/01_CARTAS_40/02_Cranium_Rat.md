# CARTA 2/40 — Cranium Rat

- **Tipo:** Aberração
- **ND:** 0
- **Raridade:** Comum
- **ID do catálogo:** Ainda não possui
- **Origem:** Candidata externa (não aprovada)
- **Publicação:** Mordenkainen Presents: Monsters of the Multiverse
- **CA:** Não confirmado
- **PV máximos:** Não confirmado
- **Iniciativa:** Não confirmado

## Habilidade de suporte (candidata)

- **Nome:** Bite (D)
- **Categoria:** Dano
- **Efeito registrado:** Ataque +4; 1 perfurante (valor citado na conversa).
- **Ressalvas:** Ficha externa MPMM não integrada: verificar edição e ataque.

## Regras do suporte

Ativação da carta sem custo de ação, ação bônus ou reação; duração, acúmulo, condições, usos e efeitos seguem a ficha original e o SRD. Após o uso, a carta vai à pilha de descarte. Não presumir homologação da transferência da habilidade à criatura ativa.

## Estado documental

FICHA EXTERNA NÃO INTEGRADA. Carta de pesquisa; **não homologada** para a partida. Consulte a ficha 02_Cranium_Rat.md e os arquivos de origem.

**Fonte:** https://www.dndbeyond.com/monsters?page=2&sort=size
