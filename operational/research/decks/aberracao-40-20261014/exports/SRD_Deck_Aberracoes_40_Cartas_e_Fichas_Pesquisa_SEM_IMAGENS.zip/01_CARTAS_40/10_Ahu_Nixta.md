# CARTA 10/40 — Ahu-Nixta

- **Tipo:** Aberração
- **ND:** 3
- **Raridade:** Comum
- **ID do catálogo:** TF-001
- **Origem:** Catálogo 607
- **Publicação:** Creature Codex
- **CA:** 14
- **PV máximos:** 67
- **Iniciativa:** +2

## Habilidade de suporte (candidata)

- **Nome:** Fear (E)
- **Categoria:** Debuff
- **Efeito registrado:** Magia de medo, CD 14.
- **Ressalvas:** Confirmar a versão de conjuração e todos os requisitos.

## Regras do suporte

Ativação da carta sem custo de ação, ação bônus ou reação; duração, acúmulo, condições, usos e efeitos seguem a ficha original e o SRD. Após o uso, a carta vai à pilha de descarte. Não presumir homologação da transferência da habilidade à criatura ativa.

## Estado documental

RESUMO MECÂNICO DE PESQUISA — não integral. Carta de pesquisa; **não homologada** para a partida. Consulte a ficha 10_Ahu_Nixta.md e os arquivos de origem.

**Fonte:** https://www.5esrd.com/database/creature/ahu-nixta/
