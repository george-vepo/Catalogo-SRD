# CARTA 35/40 — Aboleth Brute

- **Tipo:** Aberração
- **ND:** 13
- **Raridade:** Rara
- **ID do catálogo:** TF-015
- **Origem:** Catálogo 607
- **Publicação:** Dungeon Delver's Guide
- **CA:** 18
- **PV máximos:** 210
- **Iniciativa:** +2

## Habilidade de suporte (candidata)

- **Nome:** Bite (E/D)
- **Categoria:** Misto (Dano e Debuff; principal a revisar)
- **Efeito registrado:** +11; 4d12+6 perfurante, Agarrado e Contido, fuga CD 19.
- **Ressalvas:** Preservar impossibilidade de morder outro alvo durante o agarrão se pertinente.

## Regras do suporte

Ativação da carta sem custo de ação, ação bônus ou reação; duração, acúmulo, condições, usos e efeitos seguem a ficha original e o SRD. Após o uso, a carta vai à pilha de descarte. Não presumir homologação da transferência da habilidade à criatura ativa.

## Estado documental

RESUMO MECÂNICO DE PESQUISA — não integral. Carta de pesquisa; **não homologada** para a partida. Consulte a ficha 35_Aboleth_Brute.md e os arquivos de origem.

**Fonte:** https://a5e.tools/node/2819
