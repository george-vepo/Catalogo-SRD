# CARTA 36/40 — Forest Emperor

- **Tipo:** Aberração
- **ND:** 15
- **Raridade:** Rara
- **ID do catálogo:** KP-S002
- **Origem:** Catálogo 607
- **Publicação:** Tome of Beasts 2
- **CA:** 18
- **PV máximos:** 161
- **Iniciativa:** +1

## Habilidade de suporte (candidata)

- **Nome:** Rattle (E)
- **Categoria:** Debuff
- **Efeito registrado:** Sabedoria CD 18; pode impor Amedrontado.
- **Ressalvas:** Regra original de som, novos testes e imunidade após sucessos.

## Regras do suporte

Ativação da carta sem custo de ação, ação bônus ou reação; duração, acúmulo, condições, usos e efeitos seguem a ficha original e o SRD. Após o uso, a carta vai à pilha de descarte. Não presumir homologação da transferência da habilidade à criatura ativa.

## Estado documental

RESUMO MECÂNICO DE PESQUISA — não integral. Carta de pesquisa; **não homologada** para a partida. Consulte a ficha 36_Forest_Emperor.md e os arquivos de origem.

**Fonte:** https://www.5esrd.com/database/creature/forest-emperor/
