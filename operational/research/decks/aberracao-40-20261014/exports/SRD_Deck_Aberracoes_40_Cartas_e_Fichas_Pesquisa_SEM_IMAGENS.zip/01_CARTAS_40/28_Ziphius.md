# CARTA 28/40 — Ziphius

- **Tipo:** Aberração
- **ND:** 8
- **Raridade:** Incomum
- **ID do catálogo:** TF-014
- **Origem:** Catálogo 607
- **Publicação:** Creature Codex
- **CA:** 16
- **PV máximos:** 135
- **Iniciativa:** Não confirmado

## Habilidade de suporte (candidata)

- **Nome:** Telepathic Foresight (B→Ativa/E)
- **Categoria:** Buff
- **Efeito registrado:** Sabedoria CD 15; vínculo concede vantagem ofensiva ou desvantagem nos ataques do alvo.
- **Ressalvas:** Transferir beneficiário é homebrew; confirmar duração/edição.

## Regras do suporte

Ativação da carta sem custo de ação, ação bônus ou reação; duração, acúmulo, condições, usos e efeitos seguem a ficha original e o SRD. Após o uso, a carta vai à pilha de descarte. Não presumir homologação da transferência da habilidade à criatura ativa.

## Estado documental

PESQUISA MECÂNICA INDIVIDUAL — não homologada. Carta de pesquisa; **não homologada** para a partida. Consulte a ficha 28_Ziphius.md e os arquivos de origem.

**Fonte:** https://koboldpress.com/tools/kobold-press-monsters/
