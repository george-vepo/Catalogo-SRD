# CARTA 38/40 — Malleable, Massive

- **Tipo:** Aberração
- **ND:** 16
- **Raridade:** Lendária
- **ID do catálogo:** TF-286
- **Origem:** Catálogo 607
- **Publicação:** Tome of Beasts 2
- **CA:** 14
- **PV máximos:** 248
- **Iniciativa:** -1 (mod. DES; derivado)

## Habilidade de suporte (candidata)

- **Nome:** Flesh Tendril (D/E)
- **Categoria:** Misto (Dano e Debuff; principal a revisar)
- **Efeito registrado:** +13, 5d6+8 contundente e Agarrado, fuga CD 18.
- **Ressalvas:** Substitui Psychic Absorption por ser pouco aplicável.

## Regras do suporte

Ativação da carta sem custo de ação, ação bônus ou reação; duração, acúmulo, condições, usos e efeitos seguem a ficha original e o SRD. Após o uso, a carta vai à pilha de descarte. Não presumir homologação da transferência da habilidade à criatura ativa.

## Estado documental

PESQUISA MECÂNICA INDIVIDUAL — não homologada. Carta de pesquisa; **não homologada** para a partida. Consulte a ficha 38_Malleable_Massive.md e os arquivos de origem.

**Fonte:** https://koboldpress.com/tools/kobold-press-monsters/
