# CARTA 11/40 — Astral Snapper

- **Tipo:** Aberração
- **ND:** 3
- **Raridade:** Comum
- **ID do catálogo:** TF-004
- **Origem:** Catálogo 607
- **Publicação:** Creature Codex
- **CA:** 12
- **PV máximos:** 78
- **Iniciativa:** Não confirmado

## Habilidade de suporte (candidata)

- **Nome:** Claws (D)
- **Categoria:** Dano
- **Efeito registrado:** +4, 2d6+2 cortante.
- **Ressalvas:** Substitui Astral Devour (parasitismo fora do fluxo de turno); ficha parcial.

## Regras do suporte

Ativação da carta sem custo de ação, ação bônus ou reação; duração, acúmulo, condições, usos e efeitos seguem a ficha original e o SRD. Após o uso, a carta vai à pilha de descarte. Não presumir homologação da transferência da habilidade à criatura ativa.

## Estado documental

PESQUISA MECÂNICA INDIVIDUAL — não homologada. Carta de pesquisa; **não homologada** para a partida. Consulte a ficha 11_Astral_Snapper.md e os arquivos de origem.

**Fonte:** https://koboldpress.com/tools/kobold-press-monsters/
