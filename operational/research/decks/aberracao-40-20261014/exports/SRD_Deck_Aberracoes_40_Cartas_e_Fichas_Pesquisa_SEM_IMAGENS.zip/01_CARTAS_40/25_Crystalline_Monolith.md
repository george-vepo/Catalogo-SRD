# CARTA 25/40 — Crystalline Monolith

- **Tipo:** Aberração
- **ND:** 7
- **Raridade:** Incomum
- **ID do catálogo:** KP-A001
- **Origem:** Catálogo 607
- **Publicação:** Tome of Beasts 2
- **CA:** 15
- **PV máximos:** 123
- **Iniciativa:** +0

## Habilidade de suporte (candidata)

- **Nome:** Psychic Burst (E/D)
- **Categoria:** Misto (Dano e Debuff; principal a revisar)
- **Efeito registrado:** Inteligência CD 15; 8d6 psíquico e Atordoado na falha.
- **Ressalvas:** Recarga 5–6 e novos testes; confirmar fonte bibliográfica.

## Regras do suporte

Ativação da carta sem custo de ação, ação bônus ou reação; duração, acúmulo, condições, usos e efeitos seguem a ficha original e o SRD. Após o uso, a carta vai à pilha de descarte. Não presumir homologação da transferência da habilidade à criatura ativa.

## Estado documental

RESUMO MECÂNICO DE PESQUISA — não integral. Carta de pesquisa; **não homologada** para a partida. Consulte a ficha 25_Crystalline_Monolith.md e os arquivos de origem.

**Fonte:** https://www.5esrd.com/database/creature/crystalline-monolith/
