# FICHA — Greater Star Spawn Emissary (ordem 40/40)

**Tipo:** Aberração | **ND:** 21 | **Raridade:** Mítica | **ID:** sem ID aprovado

**Fonte:** Van Richten's Guide to Ravenloft (2014/legacy)
**URL de referência:** https://www.dndbeyond.com/monsters?page=176&sort=-type
**Origem:** Candidata externa (não aprovada)
**Situação documental:** FICHA EXTERNA NÃO INTEGRADA

## Atributos principais localizados

- CA: Não confirmado
- PV: Não confirmado
- Iniciativa: Não confirmado

## Suporte candidato

**Mind Cloud (E/D)** — Misto (Dano e Debuff; principal a revisar)

Sabedoria CD 23; 5d12 psíquico e encerramento de magias em alvos elegíveis.

**Ressalva:** Ficha externa Legacy não integrada; ação lendária custa 3 ações lendárias na proposta — verificar edição e economia de ações.

## Informações mecânicas extraídas das pesquisas

Nenhum bloco mecânico integral foi localizado nos arquivos incluídos.

## Atenção

Este material **não é ficha integral homologada**. As informações foram preservadas como pesquisa, sem inventar campos ou poderes ausentes.
