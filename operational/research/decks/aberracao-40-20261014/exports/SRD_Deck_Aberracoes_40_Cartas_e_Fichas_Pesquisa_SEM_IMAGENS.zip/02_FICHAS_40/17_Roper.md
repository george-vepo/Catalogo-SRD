# FICHA — Roper (ordem 17/40)

**Tipo:** Aberração | **ND:** 5 | **Raridade:** Comum | **ID:** AT-002

**Fonte:** Catálogo ativo v1.1
**URL de referência:** https://www.dndbeyond.com/monsters/16999-roper
**Origem:** Catálogo 607
**Situação documental:** SRD 5.2.1 — bloco integral local (revisão pendente)

## Atributos principais localizados

- CA: 20
- PV: 93
- Iniciativa: +5 (15)

## Suporte candidato

**Tentacle (E)** — Debuff

+7; Agarrado e Envenenado, fuga CD 14.

**Ressalva:** SRD 5.2.1; não inventar dano para o tentáculo.

## Texto integral disponível — SRD 5.2.1

Roper | COMUM • ND 5


Tipo: Aberração  CA: 20  PV: 93  ND: 5
Large Aberration, Neutral Evil
AC 20
Initiative +5 (15)
HP 93 (11d10 + 33)
Speed 10 ft., Climb 20 ft. Str 18 +4 +4 Dex     8 −1 −1 Con     17 +3 +3 Int       7 −2 −2 Wis     16 +3 +3 Cha      6 −2
− 2
Skills Perception +6, Stealth +5
Senses Darkvision 60 ft.; Passive Perception 16
Languages None
CR 5 (XP 1,800; PB +3)
Traits
Spider Climb. The roper can climb difficult surfaces, including along ceilings, without needing to make an ability check.
Actions
Multiattack. The roper makes two Tentacle attacks, uses Reel, and makes two Bite attacks.
Bite. Melee Attack Roll: +7, reach 5 ft. Hit: 17 (3d8 + 4) Piercing damage.



Tentacle. Melee Attack Roll: +7, reach 60 ft. Hit: The target has the Grappled condition (escape DC 14) from one of six tentacles,
and the target has the Poisoned condition until the grapple ends. The tentacle can be damaged, freeing a creature it has
Grappled when destroyed (AC 20, HP 10, Immunity to
Poison and Psychic damage). Damaging the tentacle deals no damage to the roper, and a destroyed tentacle regrows at the start
of the roper’s next turn.
Reel. The roper pulls each creature Grappled by it up to 30 feet straight toward it.
Ficha oficial em inglês: SRD 5.2.1, pág. 320.

**Licença:** SRD 5.2.1, Creative Commons Attribution 4.0; ver arquivo de atribuição.
