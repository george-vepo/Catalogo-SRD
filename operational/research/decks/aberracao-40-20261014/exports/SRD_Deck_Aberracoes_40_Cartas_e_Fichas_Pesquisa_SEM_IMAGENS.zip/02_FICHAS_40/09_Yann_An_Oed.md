# FICHA — Yann-An-Oed (ordem 9/40)

**Tipo:** Aberração | **ND:** 2 | **Raridade:** Comum | **ID:** TF-007

**Fonte:** Creature Codex
**URL de referência:** https://www.dndgrove.com/bestiary/2/yann-an-oed
**Origem:** Catálogo 607
**Situação documental:** RESUMO MECÂNICO DE PESQUISA — não integral

## Atributos principais localizados

- CA: 12
- PV: 47
- Iniciativa: +0

## Suporte candidato

**Tentacles (E/D)** — Misto (Dano e Debuff; principal a revisar)

+4, 2d4+2 contundente; Agarrado/Contido, escape CD 12.

**Ressalva:** Manter pré-condições de tamanho e limite de alvos não espaciais.

## Informações mecânicas extraídas das pesquisas

```json
{
  "fonte_publicacao": "Creature Codex",
  "editora_fonte": "Kobold Press / Open Design LLC",
  "sistema": "D&D 5e; bloco mecânico recuperado em referência secundária D&D Grove e conferido com a entrada 5eSRD indexada",
  "porte": "Huge",
  "tipo_fonte": "aberration",
  "alinhamento": "neutral",
  "nd_fonte": "2",
  "ca": 12,
  "ca_base": "natural armor",
  "pv": 47,
  "formula_pv": "5d12 + 15",
  "deslocamento": {
    "walk_ft": 30,
    "swim_ft": 40
  },
  "salvaguardas": {},
  "pericias": {
    "Perception": 4,
    "Stealth": 2
  },
  "resistencias_dano": [],
  "imunidades_dano": [],
  "vulnerabilidades_dano": [],
  "imunidades_condicao": [],
  "sentidos": [
    "blindsight 60 ft."
  ],
  "percepcao_passiva": 14,
  "idiomas": [
    "Aquan",
    "telepathy 120 ft."
  ],
  "bonus_proficiencia": 2,
  "bonus_proficiencia_origem": "derivado do ND 2 pela progressão de D&D 5e; não aparece separado na referência D&D Grove",
  "tracos": [
    {
      "nome": "Amphibious",
      "resumo_mecanico": "Respira ar e água."
    },
    {
      "nome": "Underwater Camouflage",
      "resumo_mecanico": "Tem vantagem em testes de Destreza (Furtividade) realizados debaixo d’água."
    }
  ],
  "acoes": [
    {
      "nome": "Bite",
      "resumo_mecanico": "Ataque corpo a corpo +4, alcance 5 ft.; 11 (2d8+2) perfurante.",
      "ataque": "+4",
      "alcance": "5 ft.",
      "dano": [
        {
          "dados": "2d8+2",
          "tipo": "piercing"
        }
      ]
    },
    {
      "nome": "Tentacles",
      "resumo_mecanico": "Ataque corpo a corpo +4, alcance 15 ft.; 7 (2d4+2) contundente. Alvo Grande ou menor fica agarrado (escape CD 12) e contido enquanto o agarrão durar; o Yann-An-Oed mantém até dois alvos agarrados.",
      "ataque": "+4",
      "alcance": "15 ft.",
      "salvaguarda": "escape DC 12",
      "dano": [
        {
          "dados": "2d4+2",
          "tipo": "bludgeoning"
        }
      ]
    },
    {
      "nome": "Swallow",
      "resumo_mecanico": "Faz um ataque Bite contra criatura Grande ou menor que esteja agarrando; ao acertar, engole o alvo e encerra o agarrão. A vítima fica cega, contida e com cobertura total, sofre 7 (2d6) ácido no início do turno da criatura; só uma vítima pode ser engolida. Se a vítima causar pelo menos 10 de dano em um turno, no fim daquele turno o Yann-An-Oed faz salvaguarda de Constituição CD 11 ou a regurgita caída a até 10 ft. Se a criatura morrer, a vítima deixa de estar contida e pode escapar gastando 10 ft. de movimento, saindo caída.",
      "salvaguarda": "Constitution DC 11",
      "alcance": "alvo agarrado Grande ou menor",
      "dano": [
        {
          "dados": "2d6",
          "tipo": "acid"
        }
      ]
    },
    {
      "nome": "Hoot (Recharges after a Short or Long Rest)",
      "resumo_mecanico": "Cada criatura a até 120 ft. que possa ouvir faz salvaguarda de Sabedoria CD 12; em falha responde ao chamado se puder produzir som. O Yann-An-Oed rastreia por 1 hora qualquer criatura que responder, mesmo se ela estiver escondida por magia ou em outro plano.",
      "uso": "recarrega após descanso curto ou longo",
      "salvaguarda": "Wisdom DC 12",
      "alcance": "120 ft.",
      "duracao": "rastreamento por 1 hora"
    }
  ],
  "secoes_nao_listadas": [
    "salvaguardas",
    "resistências e imunidades",
    "vulnerabilidades",
    "ações bônus",
    "reações",
    "ações lendárias",
    "ações míticas",
    "ações de covil",
    "conjuração"
  ],
  "fontes_adicionais": [
    {
      "titulo": "Índice oficial de monstros 5e da Kobold Press (identidade, ND, porte, tipo e publicação)",
      "url": "https://koboldpress.com/tools/kobold-press-monsters/"
    },
    {
      "titulo": "Página individual 5eSRD (renderização bloqueada por exigência de JavaScript)",
      "url": "https://www.5esrd.com/database/creature/yann-an-oed/"
    },
    {
      "titulo": "Referência secundária D&D Grove; ficha identificada como Creature Codex",
      "url": "https://www.dndgrove.com/bestiary/2/yann-an-oed"
    }
  ],
  "classe_fonte": "Índice oficial da Kobold Press confirma Yann-An-Oed, Creature Codex, ND 2, Huge aberration. Estatísticas e regras foram conferidas em resumo secundário D&D Grove; página individual 5eSRD continuou bloqueada para leitura automatizada.",
  "completa": true,
  "atributos": {
    "FOR": {
      "valor": 15,
      "modificador": 2
    },
    "DES": {
      "valor": 11,
      "modificador": 0
    },
    "CON": {
      "valor": 17,
      "modificador": 3
    },
    "INT": {
      "valor": 8,
      "modificador": -1
    },
    "SAB": {
      "valor": 14,
      "modificador": 2
    },
    "CAR": {
      "valor": 7,
      "modificador": -2
    }
  },
  "iniciativa": {
    "modificador_base_des": 0,
    "valor_formatado": "+0",
    "origem": "derivada do modificador de Destreza; fonte não informa bônus adicional"
  },
  "fonte_url": "https://www.dndgrove.com/bestiary/2/yann-an-oed",
  "variante": "Não indicada na fonte",
  "data_verificacao": "2026-10-10",
  "secoes_cobertas": [
    "identidade",
    "porte",
    "tipo",
    "ND",
    "CA",
    "PV e fórmula",
    "deslocamento",
    "atributos e modificadores",
    "salvaguardas",
    "perícias",
    "sentidos",
    "idiomas",
    "defesas",
    "traços",
    "ações",
    "recursos e recargas",
    "CDs e condições"
  ],
  "secoes_nao_listadas_na_fonte": [
    "salvaguardas",
    "resistências e imunidades",
    "vulnerabilidades",
    "ações bônus",
    "reações",
    "ações lendárias",
    "ações míticas",
    "ações de covil",
    "conjuração"
  ],
  "transcricao_integral": false,
  "observacao_direitos": "Fatos mecânicos e resumo próprio; sem reprodução integral da redação externa."
}
```

## Atenção

Este material **não é ficha integral homologada**. As informações foram preservadas como pesquisa, sem inventar campos ou poderes ausentes.
