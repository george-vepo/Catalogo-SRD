# FICHA — Malleable, Minor (ordem 6/40)

**Tipo:** Aberração | **ND:** 1 | **Raridade:** Comum | **ID:** TF-274

**Fonte:** Tome of Beasts 2
**URL de referência:** https://koboldpress.com/tools/kobold-press-monsters/
**Origem:** Catálogo 607
**Situação documental:** PESQUISA MECÂNICA INDIVIDUAL — não homologada

## Atributos principais localizados

- CA: 11
- PV: 32
- Iniciativa: -1 (mod. DES; derivado)

## Suporte candidato

**Flesh Tendril (D/E)** — Misto (Dano e Debuff; principal a revisar)

2d6+3 contundente e Agarrado conforme a ficha.

**Ressalva:** Substitui Psychic Absorption por ser situacional.

## Informações mecânicas extraídas das pesquisas

```json
{
  "traits": [
    {
      "name": "Amorphous",
      "category": "movement",
      "minimum_gap_inches": 1,
      "no_squeezing_required": true
    },
    {
      "name": "Controlled Mutability",
      "category": "shape_control",
      "temporary_external_shape_change_ends": "end_of_malleable_next_turn",
      "self_action_to_change_shape": {
        "action_economy": "action",
        "any_basic_shape": true,
        "always_looks_like": "inside_out_fleshy_creature",
        "does_not_gain": "target_creature_stats_or_abilities"
      }
    },
    {
      "name": "Psychic Absorption",
      "category": "damage_replacement_healing",
      "trigger": "subjected_to_psychic_damage",
      "damage_received": 0,
      "heal_hit_points": "amount_of_psychic_damage_would_be_dealt"
    },
    {
      "name": "Spider Climb",
      "category": "climbing",
      "can_climb_difficult_surfaces_and_ceiling_without_check": true
    }
  ],
  "actions": [
    {
      "name": "Flesh Tendril",
      "category": "attack",
      "action_economy": "action",
      "attack_type": "melee_weapon",
      "attack_bonus": 5,
      "reach_ft": 5,
      "targets": {
        "count": 1
      },
      "hit": {
        "damage": [
          {
            "dice": "2d6",
            "flat": 3,
            "average": 10,
            "type": "bludgeoning"
          }
        ],
        "target_medium_or_smaller": {
          "condition": "grappled",
          "escape_dc": 12
        }
      },
      "miss": {
        "damage": 0
      }
    },
    {
      "name": "Psychic Drain",
      "category": "single_target_save",
      "action_economy": "action",
      "target": {
        "count": 1,
        "precondition": "grappled_by_malleable"
      },
      "save": {
        "ability": "INT",
        "dc": 12,
        "on_failure": {
          "damage": [
            {
              "dice": "1d8",
              "flat": 0,
              "average": 4,
              "type": "psychic"
            }
          ]
        },
        "on_success": {
          "damage_multiplier": 0.5
        }
      },
      "additional_effect": {
        "reduce_maximum_hit_points_by": "actual_psychic_damage_taken",
        "reduction_ends": "after_target_finishes_long_rest",
        "if_maximum_hp_becomes_0": {
          "death": true,
          "transform_into": "minor_malleable"
        }
      }
    },
    {
      "name": "Join Malleables",
      "category": "group_fusion",
      "action_economy": "action",
      "required_other_minor_malleables_within_ft_10": 3,
      "activation": "each_participant_uses_action_at_same_time",
      "valid_total_participants_and_results": [
        {
          "count": 4,
          "result": "moderate_malleable"
        },
        {
          "count": 8,
          "result": "major_malleable"
        },
        {
          "count": 16,
          "result": "massive_malleable"
        }
      ],
      "new_creature": {
        "hit_points": "sum_of_current_hit_points_of_joining_minors",
        "inherits_all_conditions_spells_and_magical_effects": true,
        "initiative": "same_as_joining_malleables",
        "position": "one_unoccupied_space_previously_containing_a_component"
      }
    }
  ],
  "bonus_actions": [],
  "reactions": [],
  "legendary_actions": [],
  "lair_actions": [],
  "mythic_actions": [],
  "spellcasting": [],
  "other": [
    {
      "name": "Join Malleables sizes",
      "category": "cross_card_dependency",
      "source_ids": [
        "TF-276",
        "TF-284",
        "TF-286"
      ],
      "source_names": [
        "Moderate Malleable",
        "Major Malleable",
        "Massive Malleable"
      ],
      "variant_statblock_policy": "Do not derive those statblocks mechanically from this record; individual versions must be sourced and structured separately."
    }
  ]
}
```

## Estatísticas adicionais da pesquisa individual

```json
{
  "armor_class": 11,
  "hit_points": 32,
  "hit_dice": "5d8+10",
  "ability_scores": {
    "STR": 16,
    "DEX": 8,
    "CON": 14,
    "INT": 15,
    "WIS": 14,
    "CHA": 10
  },
  "speeds": {
    "walk_ft": 30,
    "climb_ft": 30
  },
  "senses": {
    "blindsight_ft": 30,
    "blind_beyond_blindsight": true,
    "passive_perception": 12
  },
  "skills": [],
  "saving_throws": {
    "INT": 4,
    "WIS": 4,
    "CHA": 2
  },
  "languages": {
    "spoken": "all_languages",
    "telepathy_ft": 60
  },
  "damage_resistances": [],
  "damage_immunities": [
    "psychic"
  ],
  "damage_vulnerabilities": [],
  "condition_immunities": [
    "blinded",
    "prone"
  ],
  "armor_class_type": "natural_armor",
  "ability_modifiers": {
    "STR": 3,
    "DEX": -1,
    "CON": 2,
    "INT": 2,
    "WIS": 2,
    "CHA": 0
  }
}
```

## Atenção

Este material **não é ficha integral homologada**. As informações foram preservadas como pesquisa, sem inventar campos ou poderes ausentes.
