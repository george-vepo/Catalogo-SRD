# FICHA — Light Eater (ordem 4/40)

**Tipo:** Aberração | **ND:** 1/2 | **Raridade:** Comum | **ID:** TF-272

**Fonte:** Tome of Beasts 3
**URL de referência:** https://koboldpress.com/tools/kobold-press-monsters/
**Origem:** Catálogo 607
**Situação documental:** PESQUISA MECÂNICA INDIVIDUAL — não homologada

## Atributos principais localizados

- CA: 14
- PV: 26
- Iniciativa: +2 (mod. DES; derivado)

## Suporte candidato

**Tentacle (D)** — Dano

Ataque +4; 1d6+2 contundente.

**Ressalva:** Troca de Emergency Flare por depender de gatilho e envolver área.

## Informações mecânicas extraídas das pesquisas

```json
{
  "traits": [
    {
      "name": "False Appearance",
      "category": "camouflage",
      "preconditions": [
        "motionless",
        "in_dim_light_or_darkness"
      ],
      "effect": "indistinguishable_from_normal_rock"
    },
    {
      "name": "Light Absorption",
      "category": "automatic_light_conversion",
      "trigger": "start_of_light_eater_turn_within_5_ft_of_any_light_source",
      "reduced_source_area_requirement": {
        "light_eater_within_ft": 100
      },
      "conversion": {
        "bright_light": "dim_light",
        "dim_light": "darkness"
      },
      "when_reduces_source_to_darkness": {
        "light_eater_emits": {
          "bright_radius_ft": 20,
          "additional_dim_radius_ft": 20,
          "duration_hours": 1
        },
        "source_extinguished_if": "nonmagical_flame",
        "source_dispelled_if": {
          "created_by_spell_level_lte": 2
        }
      },
      "unsupported_source_type": "magical_light_created_by_spell_level_above_2_no_dispel_specified"
    },
    {
      "name": "Light Sense",
      "category": "light_sensing",
      "pinpoint_light_sources_within_ft": 100,
      "sense_general_direction_light_source_within_miles": 1
    }
  ],
  "actions": [
    {
      "name": "Tentacle",
      "category": "attack",
      "action_economy": "action",
      "attack_type": "melee_weapon",
      "attack_bonus": 4,
      "reach_ft": 5,
      "targets": {
        "count": 1
      },
      "hit": {
        "damage": [
          {
            "dice": "1d6",
            "flat": 2,
            "average": 5,
            "type": "bludgeoning"
          }
        ]
      },
      "miss": {
        "damage": 0
      }
    }
  ],
  "bonus_actions": [],
  "reactions": [
    {
      "name": "Emergency Flare",
      "category": "area_save",
      "action_economy": "reaction",
      "trigger": "takes_damage",
      "recharge": "short_or_long_rest",
      "area": {
        "radius_ft": 30,
        "center": "light_eater"
      },
      "targets": "each_creature_within_30ft",
      "save": {
        "ability": "CON",
        "dc": 12,
        "on_failure": {
          "condition": "blinded",
          "duration": "1_minute",
          "repeat_save": {
            "timing": "end_of_affected_creature_each_turn",
            "ability": "CON",
            "dc": 12,
            "success_ends": true
          }
        },
        "on_success": {
          "condition": null
        }
      }
    }
  ],
  "legendary_actions": [],
  "lair_actions": [],
  "mythic_actions": [],
  "spellcasting": [],
  "other": []
}
```

## Estatísticas adicionais da pesquisa individual

```json
{
  "armor_class": 14,
  "hit_points": 26,
  "hit_dice": "4d6+12",
  "ability_scores": {
    "STR": 8,
    "DEX": 14,
    "CON": 16,
    "INT": 4,
    "WIS": 17,
    "CHA": 8
  },
  "speeds": {
    "walk_ft": 10,
    "fly_ft": 40,
    "hover": true
  },
  "senses": {
    "blindsight_ft": 120,
    "blind_beyond_blindsight": true,
    "passive_perception": 15
  },
  "skills": {
    "Perception": 5,
    "Stealth": 4
  },
  "saving_throws": [],
  "languages": [],
  "damage_resistances": [],
  "damage_immunities": [
    "fire",
    "radiant"
  ],
  "damage_vulnerabilities": [],
  "condition_immunities": [
    "prone"
  ],
  "armor_class_type": "natural_armor",
  "ability_modifiers": {
    "STR": -1,
    "DEX": 2,
    "CON": 3,
    "INT": -3,
    "WIS": 3,
    "CHA": -1
  }
}
```

## Atenção

Este material **não é ficha integral homologada**. As informações foram preservadas como pesquisa, sem inventar campos ou poderes ausentes.
