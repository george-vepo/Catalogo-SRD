# FICHA — Maw Swarm (ordem 13/40)

**Tipo:** Aberração | **ND:** 4 | **Raridade:** Comum | **ID:** TF-275

**Fonte:** Dungeon Delver's Guide
**URL de referência:** https://a5e.tools/node/2840
**Origem:** Catálogo 607
**Situação documental:** RESUMO MECÂNICO DE PESQUISA — não integral

## Atributos principais localizados

- CA: 13
- PV: 71
- Iniciativa: +3

## Suporte candidato

**Bites (D)** — Dano

+5, 4d6+3 perfurante; 2d6+3 quando bloodied.

**Ressalva:** Não confundir redução de dado de dano com redução de PV do suporte.

## Informações mecânicas extraídas das pesquisas

```json
{
  "fonte_publicacao": "Dungeon Delver's Guide",
  "editora_fonte": "EN Publishing",
  "sistema": "Level Up: Advanced 5th Edition (página da ferramenta A5E; não é o A5ESRD; sem conversão para D&D 5e).",
  "terreno_fonte": [
    "Abyss",
    "Water"
  ],
  "porte": "Medium",
  "tipo_fonte": "Aberration",
  "alinhamento": "",
  "nd_fonte": "4",
  "ca": 13,
  "ca_base": "",
  "pv": 71,
  "formula_pv": "11d8 + 22; bloodied 35",
  "deslocamento": {
    "walk_ft": 0,
    "fly_ft": 40,
    "fly_hover": true,
    "swim_ft": 40
  },
  "salvaguardas": {},
  "pericias": {},
  "resistencias_dano": [
    "bludgeoning",
    "piercing",
    "slashing"
  ],
  "imunidades_dano": [],
  "vulnerabilidades_dano": [],
  "imunidades_condicao": [
    "blinded",
    "charmed",
    "frightened",
    "grappled",
    "paralyzed",
    "petrified",
    "prone",
    "restrained",
    "stunned",
    "unconscious"
  ],
  "sentidos": [
    "darkvision 60 ft."
  ],
  "percepcao_passiva": 10,
  "idiomas": [
    "Deep Speech"
  ],
  "bonus_proficiencia": 2,
  "maneuver_dc": 13,
  "tracos": [
    {
      "nome": "Aberrant Physiology",
      "resumo_mecanico": "Não precisa respirar nem dormir."
    },
    {
      "nome": "Swarm",
      "resumo_mecanico": "Pode ocupar o espaço de outra criatura e atravessar aberturas para criatura Tiny; não pode ganhar PV nem PV temporários."
    },
    {
      "nome": "Whispers of the Weird",
      "resumo_mecanico": "Sussurra continuamente. Criatura que inicia turno a até 5 ft. e consegue ouvir faz salvaguarda de Sabedoria CD 13 ou sofre 3d6 psychic."
    }
  ],
  "acoes": [
    {
      "nome": "Bites",
      "resumo_mecanico": "Ataque corpo a corpo +5, alcance 0 ft., um alvo; 4d6+3 piercing, reduzido para 2d6+3 quando a swarm está bloodied.",
      "ataque": "+5",
      "alcance": "0 ft.",
      "dano": [
        {
          "dados": "4d6+3 (ou 2d6+3 quando bloodied)",
          "tipo": "piercing"
        }
      ]
    }
  ],
  "acoes_bonus": [],
  "reacoes": [],
  "conjuracao": null,
  "nota_tatica": "Na seção de combate, move-se até o espaço do não-aberration mais próximo e o ataca; luta até a morte.",
  "secoes_nao_listadas": [
    "salvaguardas",
    "perícias",
    "imunidades e vulnerabilidades a dano",
    "Multiattack",
    "ações bônus",
    "reações",
    "ações lendárias",
    "ações míticas",
    "ações de covil",
    "conjuração"
  ],
  "atributos": {
    "FOR": {
      "valor": 10,
      "modificador": 0
    },
    "DES": {
      "valor": 16,
      "modificador": 3
    },
    "CON": {
      "valor": 14,
      "modificador": 2
    },
    "INT": {
      "valor": 3,
      "modificador": -4
    },
    "SAB": {
      "valor": 10,
      "modificador": 0
    },
    "CAR": {
      "valor": 6,
      "modificador": -2
    }
  },
  "iniciativa": {
    "modificador_base_des": 3,
    "valor_formatado": "+3",
    "origem": "derivada do modificador de Destreza; fonte não informa bônus adicional"
  },
  "fonte_url": "https://a5e.tools/node/2840",
  "variante": "Não indicada na fonte",
  "classe_fonte": "Página de ferramenta da editora; a própria página declara que não é o A5E SRD.",
  "data_verificacao": "2026-10-10",
  "secoes_cobertas": [
    "identidade",
    "porte",
    "tipo",
    "ND",
    "CA",
    "PV e fórmula",
    "deslocamento",
    "atributos e modificadores",
    "salvaguardas",
    "perícias",
    "sentidos",
    "idiomas",
    "defesas",
    "traços",
    "ações",
    "recursos e recargas",
    "CDs e condições"
  ],
  "secoes_nao_listadas_na_fonte": [
    "salvaguardas",
    "perícias",
    "imunidades e vulnerabilidades a dano",
    "Multiattack",
    "ações bônus",
    "reações",
    "ações lendárias",
    "ações míticas",
    "ações de covil",
    "conjuração"
  ],
  "transcricao_integral": false,
  "observacao_direitos": "Fatos mecânicos e resumo próprio; sem reprodução integral da redação externa."
}
```

## Atenção

Este material **não é ficha integral homologada**. As informações foram preservadas como pesquisa, sem inventar campos ou poderes ausentes.
