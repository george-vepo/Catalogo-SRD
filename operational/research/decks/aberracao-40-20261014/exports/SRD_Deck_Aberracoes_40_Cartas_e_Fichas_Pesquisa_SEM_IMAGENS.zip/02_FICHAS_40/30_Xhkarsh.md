# FICHA — Xhkarsh (ordem 30/40)

**Tipo:** Aberração | **ND:** 9 | **Raridade:** Incomum | **ID:** TF-012

**Fonte:** Tome of Beasts 1
**URL de referência:** https://koboldpress.com/tools/kobold-press-monsters/
**Origem:** Catálogo 607
**Situação documental:** PESQUISA MECÂNICA INDIVIDUAL — não homologada

## Atributos principais localizados

- CA: 18
- PV: 171
- Iniciativa: Não confirmado

## Suporte candidato

**Fate-Altering Stinger (E/D)** — Misto (Dano e Debuff; principal a revisar)

+8, 2d10+4 perfurante; Carisma CD 16 pode corromper o destino.

**Ressalva:** Fixar edição 2023 antes de executar.

## Informações mecânicas extraídas das pesquisas

```json
{
  "traits": [
    {
      "name": "Corruption's Bond",
      "kind": "passive",
      "legacy_summary": "Mantém localização, saúde e telepatia sem limite de distância com alvos cujo destino tenha corrompido, inclusive em outros planos.",
      "status": "INCOMPLETA",
      "attack_bonus": null,
      "range": null,
      "targets": null,
      "damage": null,
      "dc": null,
      "save": null,
      "conditions": null,
      "duration": null,
      "recharge": null,
      "uses": null
    },
    {
      "name": "Interdimensional Nature",
      "kind": "passive",
      "legacy_summary": "Dispensa ar, alimentação, líquidos, sono e pressão ambiente.",
      "status": "INCOMPLETA",
      "attack_bonus": null,
      "range": null,
      "targets": null,
      "damage": null,
      "dc": null,
      "save": null,
      "conditions": null,
      "duration": null,
      "recharge": null,
      "uses": null
    }
  ],
  "actions": [
    {
      "name": "Multiattack",
      "kind": "action",
      "legacy_summary": "Dois ataques com garras e uma ferroada alteradora do destino.",
      "status": "INCOMPLETA",
      "attack_bonus": null,
      "range": null,
      "targets": null,
      "damage": null,
      "dc": null,
      "save": null,
      "conditions": null,
      "duration": null,
      "recharge": null,
      "uses": null
    },
    {
      "name": "Claw",
      "kind": "action",
      "legacy_summary": "+8; 5 ft.; 2d8+4 cortante mais 2d8 veneno.",
      "status": "INCOMPLETA",
      "attack_bonus": null,
      "range": null,
      "targets": null,
      "damage": null,
      "dc": null,
      "save": null,
      "conditions": null,
      "duration": null,
      "recharge": null,
      "uses": null
    },
    {
      "name": "Fate-Altering Stinger",
      "kind": "action",
      "legacy_summary": "+8; 5 ft.; 2d10+4 perfurante e salvaguarda CAR CD 16, impondo corrupção do destino e impedimentos a adivinhação/detecção até magia apropriada.",
      "status": "INCOMPLETA",
      "attack_bonus": null,
      "range": null,
      "targets": null,
      "damage": null,
      "dc": null,
      "save": null,
      "conditions": null,
      "duration": null,
      "recharge": null,
      "uses": null
    },
    {
      "name": "Invisibility",
      "kind": "action",
      "legacy_summary": "Torna-se invisível até atacar, usar Seize Strand ou perder concentração.",
      "status": "INCOMPLETA",
      "attack_bonus": null,
      "range": null,
      "targets": null,
      "damage": null,
      "dc": null,
      "save": null,
      "conditions": null,
      "duration": null,
      "recharge": null,
      "uses": null
    },
    {
      "name": "Seize Strand",
      "kind": "action",
      "legacy_summary": "Alvo corrompido faz CAR CD 16; falha produz efeito análogo a geas por 8 horas; uso contra mesmo alvo no máximo uma vez por 24 horas.",
      "status": "INCOMPLETA",
      "attack_bonus": null,
      "range": null,
      "targets": null,
      "damage": null,
      "dc": null,
      "save": null,
      "conditions": null,
      "duration": null,
      "recharge": null,
      "uses": null
    }
  ],
  "bonus_actions": null,
  "reactions": null,
  "legendary_actions": null,
  "lair_actions": null,
  "spellcasting": null,
  "other": null
}
```

## Estatísticas adicionais da pesquisa individual

```json
{
  "armor_class": 18,
  "hit_points": 171,
  "hit_dice": "18d10+72",
  "ability_scores": {
    "STR": 17,
    "DEX": 19,
    "CON": 18,
    "INT": 15,
    "WIS": 16,
    "CHA": 15
  },
  "speeds": {
    "andar_ft": 50,
    "escalar_ft": 30
  },
  "senses": [
    "darkvision 60 ft.",
    "tremorsense 120 ft."
  ],
  "skills": {
    "Insight": 7,
    "Perception": 7,
    "Stealth": 8
  },
  "saving_throws": {
    "CHA": 6
  },
  "languages": [
    "Common",
    "Deep Speech",
    "Undercommon",
    "telepathy 60 ft."
  ],
  "damage_resistances": null,
  "damage_immunities": null,
  "damage_vulnerabilities": null,
  "condition_immunities": null
}
```

## Atenção

Este material **não é ficha integral homologada**. As informações foram preservadas como pesquisa, sem inventar campos ou poderes ausentes.
