# FICHA — Birgemon Seal (ordem 7/40)

**Tipo:** Aberração | **ND:** 2 | **Raridade:** Comum | **ID:** TF-005

**Fonte:** Tome of Beasts 3
**URL de referência:** https://www.5esrd.com/database/creature/birgemon-seal/
**Origem:** Catálogo 607
**Situação documental:** RESUMO MECÂNICO DE PESQUISA — não integral

## Atributos principais localizados

- CA: 12
- PV: 60
- Iniciativa: +2

## Suporte candidato

**Tendril (E)** — Debuff

Agarrado; dois tentáculos no mesmo alvo podem impor Contido; escape CD 13.

**Ressalva:** Dois tentáculos exigem duas aplicações válidas, não apenas um acerto.

## Informações mecânicas extraídas das pesquisas

```json
{
  "fonte_publicacao": "Tome of Beasts 3",
  "editora_fonte": "Kobold Press / Open Design LLC",
  "sistema": "D&D 5e (conteúdo de terceiro hospedado pelo 5eSRD)",
  "porte": "Medium",
  "tipo_fonte": "aberration",
  "alinhamento": "unaligned",
  "nd_fonte": "2",
  "ca": 12,
  "ca_base": "",
  "pv": 60,
  "formula_pv": "8d8 + 24",
  "deslocamento": {
    "walk_ft": 20,
    "swim_ft": 60
  },
  "salvaguardas": {},
  "pericias": {
    "Perception": 3,
    "Stealth": 4
  },
  "resistencias_dano": [
    "acid",
    "cold"
  ],
  "imunidades_dano": [],
  "vulnerabilidades_dano": [],
  "imunidades_condicao": [],
  "sentidos": [
    "darkvision 60 ft."
  ],
  "percepcao_passiva": 13,
  "idiomas": [],
  "bonus_proficiencia": 2,
  "tracos": [
    {
      "nome": "Frozen to the Spot",
      "resumo_mecanico": "Enquanto está sobre neve ou gelo, não pode ser movido contra a vontade."
    },
    {
      "nome": "Hold Breath",
      "resumo_mecanico": "Pode prender a respiração por 90 minutos."
    }
  ],
  "acoes": [
    {
      "nome": "Multiattack",
      "resumo_mecanico": "Faz uma mordida, uma Toothy Maw e três ataques de tentáculo; pode substituir os três tentáculos por Reel."
    },
    {
      "nome": "Bite",
      "resumo_mecanico": "Ataque corpo a corpo +4, alcance 5 ft.; 2d4+2 piercing.",
      "ataque": "+4",
      "alcance": "5 ft.",
      "dano": [
        {
          "dados": "2d4+2",
          "tipo": "piercing"
        }
      ]
    },
    {
      "nome": "Toothy Maw",
      "resumo_mecanico": "Ataque corpo a corpo +4, alcance 5 ft.; 2d6+2 piercing.",
      "ataque": "+4",
      "alcance": "5 ft.",
      "dano": [
        {
          "dados": "2d6+2",
          "tipo": "piercing"
        }
      ]
    },
    {
      "nome": "Tendril",
      "resumo_mecanico": "Ataque corpo a corpo +4, alcance 15 ft.; agarra criatura Medium ou menor (escape CD 13). Cada tentáculo só pode manter uma criatura; dois ou mais tentáculos na mesma criatura também a deixam Restrained.",
      "ataque": "+4",
      "alcance": "15 ft.",
      "salvaguarda": "escape DC 13"
    },
    {
      "nome": "Reel",
      "resumo_mecanico": "Puxa até 10 ft. cada criatura que esteja agarrada."
    }
  ],
  "acoes_bonus": [
    {
      "nome": "Ice Slide",
      "resumo_mecanico": "Se se mover pelo menos 10 ft. em linha reta sobre neve ou gelo no turno, pode deslizar até 40 ft."
    }
  ],
  "reacoes": [],
  "conjuracao": null,
  "nota_tatica": "Pode prender várias criaturas com tentáculos e aproximá-las com Reel.",
  "secoes_nao_listadas": [
    "salvaguardas",
    "imunidades a condições",
    "ações lendárias",
    "ações míticas",
    "ações de covil"
  ],
  "atributos": {
    "FOR": {
      "valor": 12,
      "modificador": 1
    },
    "DES": {
      "valor": 15,
      "modificador": 2
    },
    "CON": {
      "valor": 16,
      "modificador": 3
    },
    "INT": {
      "valor": 4,
      "modificador": -3
    },
    "SAB": {
      "valor": 12,
      "modificador": 1
    },
    "CAR": {
      "valor": 9,
      "modificador": -1
    }
  },
  "iniciativa": {
    "modificador_base_des": 2,
    "valor_formatado": "+2",
    "origem": "derivada do modificador de Destreza; fonte não informa bônus adicional"
  },
  "fonte_url": "https://www.5esrd.com/database/creature/birgemon-seal/",
  "variante": "Não indicada na fonte",
  "classe_fonte": "Referência hospedada pelo 5eSRD; bloco atribuído à Kobold Press/Open Design LLC.",
  "data_verificacao": "2026-10-10",
  "secoes_cobertas": [
    "identidade",
    "porte",
    "tipo",
    "ND",
    "CA",
    "PV e fórmula",
    "deslocamento",
    "atributos e modificadores",
    "salvaguardas",
    "perícias",
    "sentidos",
    "idiomas",
    "defesas",
    "traços",
    "ações",
    "recursos e recargas",
    "CDs e condições",
    "ações bônus"
  ],
  "secoes_nao_listadas_na_fonte": [
    "salvaguardas",
    "imunidades a condições",
    "ações lendárias",
    "ações míticas",
    "ações de covil"
  ],
  "transcricao_integral": false,
  "observacao_direitos": "Fatos mecânicos e resumo próprio; sem reprodução integral da redação externa."
}
```

## Atenção

Este material **não é ficha integral homologada**. As informações foram preservadas como pesquisa, sem inventar campos ou poderes ausentes.
