# FICHA — Cranium Rat (ordem 2/40)

**Tipo:** Aberração | **ND:** 0 | **Raridade:** Comum | **ID:** sem ID aprovado

**Fonte:** Mordenkainen Presents: Monsters of the Multiverse
**URL de referência:** https://www.dndbeyond.com/monsters?page=2&sort=size
**Origem:** Candidata externa (não aprovada)
**Situação documental:** FICHA EXTERNA NÃO INTEGRADA

## Atributos principais localizados

- CA: Não confirmado
- PV: Não confirmado
- Iniciativa: Não confirmado

## Suporte candidato

**Bite (D)** — Dano

Ataque +4; 1 perfurante (valor citado na conversa).

**Ressalva:** Ficha externa MPMM não integrada: verificar edição e ataque.

## Informações mecânicas extraídas das pesquisas

Nenhum bloco mecânico integral foi localizado nos arquivos incluídos.

## Atenção

Este material **não é ficha integral homologada**. As informações foram preservadas como pesquisa, sem inventar campos ou poderes ausentes.
