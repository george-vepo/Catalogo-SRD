# FICHA — Ahu-Nixta (ordem 10/40)

**Tipo:** Aberração | **ND:** 3 | **Raridade:** Comum | **ID:** TF-001

**Fonte:** Creature Codex
**URL de referência:** https://www.5esrd.com/database/creature/ahu-nixta/
**Origem:** Catálogo 607
**Situação documental:** RESUMO MECÂNICO DE PESQUISA — não integral

## Atributos principais localizados

- CA: 14
- PV: 67
- Iniciativa: +2

## Suporte candidato

**Fear (E)** — Debuff

Magia de medo, CD 14.

**Ressalva:** Confirmar a versão de conjuração e todos os requisitos.

## Informações mecânicas extraídas das pesquisas

```json
{
  "fonte_publicacao": "Creature Codex",
  "editora_fonte": "Kobold Press / Open Design LLC",
  "sistema": "D&D 5e (bloco atribuído a Kobold Press, hospedado pelo 5eSRD)",
  "porte": "Large",
  "tipo_fonte": "aberration",
  "alinhamento": "neutral evil",
  "nd_fonte": "3",
  "ca": 14,
  "ca_base": "clockwork armor",
  "pv": 67,
  "formula_pv": "9d10 + 18 (armadura; forma interna com 37 PV, 5d10 + 10)",
  "deslocamento": {
    "walk_ft": 30,
    "fly_ft": 30,
    "swim_ft": 30
  },
  "salvaguardas": {},
  "pericias": {
    "Perception": 3
  },
  "resistencias_dano": [],
  "imunidades_dano": [
    "poison",
    "psychic"
  ],
  "vulnerabilidades_dano": [],
  "imunidades_condicao": [
    "charmed",
    "exhaustion",
    "frightened",
    "paralyzed",
    "petrified",
    "poisoned",
    "prone"
  ],
  "sentidos": [
    "darkvision 60 ft."
  ],
  "percepcao_passiva": 13,
  "idiomas": [
    "Deep Speech",
    "Void Speech"
  ],
  "bonus_proficiencia": 2,
  "bonus_proficiencia_origem": "derivado do ND 3 pela tabela padrão de proficiência de D&D 5e; não impresso no bloco",
  "tracos": [
    {
      "nome": "Clockwork Encasement",
      "resumo_mecanico": "A criatura é protegida por armadura mecânica com manipuladores. Ao chegar a 0 PV, a armadura quebra e a criatura emerge. Na forma interna: CA 12, 37 PV (5d10+10), Força 9 (-1), todos os deslocamentos caem a 20 ft. e perde ações de ataque, mas ainda pode conjurar. Mantém apenas imunidade a dano psíquico e à condição Prone; os demais benefícios de imunidade da armadura se perdem. Os apêndices podem manipular objetos, mas não atacar; as janelas da armadura podem ser abertas sem ação. Pode entrar ou sair da armadura como ação bônus."
    },
    {
      "nome": "Immutable Form",
      "resumo_mecanico": "A armadura mecânica é imune a magias ou efeitos que alterariam sua forma; a criatura também é protegida enquanto permanece dentro dela."
    },
    {
      "nome": "Innate Spellcasting",
      "resumo_mecanico": "Conjuração por Inteligência, CD 14, +6 para acertar com ataques mágicos; sem componentes materiais. Magias à vontade: fear, fire bolt (2d10), telekinesis."
    }
  ],
  "acoes": [
    {
      "nome": "Multiattack",
      "resumo_mecanico": "Faz três ataques corpo a corpo; pode substituir dois ataques por uma magia à vontade."
    },
    {
      "nome": "Whirring Blades",
      "resumo_mecanico": "Ataque corpo a corpo +5, alcance 5 ft.; 2d4+3 slashing.",
      "ataque": "+5",
      "alcance": "5 ft.",
      "dano": [
        {
          "dados": "2d4+3",
          "tipo": "slashing"
        }
      ]
    },
    {
      "nome": "Pronged Scepter",
      "resumo_mecanico": "Ataque corpo a corpo +5, alcance 10 ft.; 1d6+3 piercing.",
      "ataque": "+5",
      "alcance": "10 ft.",
      "dano": [
        {
          "dados": "1d6+3",
          "tipo": "piercing"
        }
      ]
    },
    {
      "nome": "Bashing Rod",
      "resumo_mecanico": "Ataque corpo a corpo +5, alcance 5 ft.; 1d10+3 bludgeoning.",
      "ataque": "+5",
      "alcance": "5 ft.",
      "dano": [
        {
          "dados": "1d10+3",
          "tipo": "bludgeoning"
        }
      ]
    }
  ],
  "acoes_bonus": [
    {
      "nome": "Enter or Exit Clockwork Armor",
      "resumo_mecanico": "Entra ou sai da armadura mecânica como ação bônus; ao emergir aplicam-se as estatísticas internas e as limitações descritas em Clockwork Encasement."
    }
  ],
  "reacoes": [],
  "conjuracao": {
    "atributo": "INT",
    "cd": 14,
    "ataque_magia": "+6",
    "sem_componentes": [
      "material"
    ],
    "at_will": [
      "fear",
      "fire bolt (2d10)",
      "telekinesis"
    ]
  },
  "secoes_nao_listadas": [
    "salvaguardas",
    "resistências de dano",
    "vulnerabilidades",
    "ações especiais além dos traços",
    "reações",
    "ações lendárias",
    "ações míticas",
    "ações de covil"
  ],
  "atributos": {
    "FOR": {
      "valor": 17,
      "modificador": 3
    },
    "DES": {
      "valor": 15,
      "modificador": 2
    },
    "CON": {
      "valor": 14,
      "modificador": 2
    },
    "INT": {
      "valor": 19,
      "modificador": 4
    },
    "SAB": {
      "valor": 13,
      "modificador": 1
    },
    "CAR": {
      "valor": 10,
      "modificador": 0
    }
  },
  "iniciativa": {
    "modificador_base_des": 2,
    "valor_formatado": "+2",
    "origem": "derivada do modificador de Destreza; fonte não informa bônus adicional"
  },
  "fonte_url": "https://www.5esrd.com/database/creature/ahu-nixta/",
  "variante": "Não indicada na fonte",
  "classe_fonte": "Referência hospedada pelo 5eSRD; bloco atribuído à Kobold Press/Open Design LLC.",
  "data_verificacao": "2026-10-10",
  "secoes_cobertas": [
    "identidade",
    "porte",
    "tipo",
    "ND",
    "CA",
    "PV e fórmula",
    "deslocamento",
    "atributos e modificadores",
    "salvaguardas",
    "perícias",
    "sentidos",
    "idiomas",
    "defesas",
    "traços",
    "ações",
    "recursos e recargas",
    "CDs e condições",
    "ações bônus",
    "conjuração"
  ],
  "secoes_nao_listadas_na_fonte": [
    "salvaguardas",
    "resistências de dano",
    "vulnerabilidades",
    "ações especiais além dos traços",
    "reações",
    "ações lendárias",
    "ações míticas",
    "ações de covil"
  ],
  "transcricao_integral": false,
  "observacao_direitos": "Fatos mecânicos e resumo próprio; sem reprodução integral da redação externa."
}
```

## Atenção

Este material **não é ficha integral homologada**. As informações foram preservadas como pesquisa, sem inventar campos ou poderes ausentes.
