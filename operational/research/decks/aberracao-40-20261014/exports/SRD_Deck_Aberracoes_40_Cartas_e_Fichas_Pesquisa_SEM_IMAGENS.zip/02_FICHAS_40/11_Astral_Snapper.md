# FICHA — Astral Snapper (ordem 11/40)

**Tipo:** Aberração | **ND:** 3 | **Raridade:** Comum | **ID:** TF-004

**Fonte:** Creature Codex
**URL de referência:** https://koboldpress.com/tools/kobold-press-monsters/
**Origem:** Catálogo 607
**Situação documental:** PESQUISA MECÂNICA INDIVIDUAL — não homologada

## Atributos principais localizados

- CA: 12
- PV: 78
- Iniciativa: Não confirmado

## Suporte candidato

**Claws (D)** — Dano

+4, 2d6+2 cortante.

**Ressalva:** Substitui Astral Devour (parasitismo fora do fluxo de turno); ficha parcial.

## Informações mecânicas extraídas das pesquisas

```json
{
  "traits": [
    {
      "name": "Astral Devour",
      "category": "passive",
      "previous_summary_for_context": "Hospedeiro submetido a Sabedoria CD 13 ap?s descansos longos: sucesso expulsa criatura ao Plano Material e deixa atordoada por 1 rodada; falha reduz Constitui??o em 1d4, levando ? morte se chegar a 0. Ao sair, redu??o dura at? descanso longo ap?s expuls?o.",
      "status": "PENDENTE_ESTRUTURACAO_INTEGRAL",
      "attack_bonus": null,
      "range": null,
      "target": null,
      "damage": null,
      "save_dc": null,
      "save_ability": null,
      "conditions": null,
      "duration": null,
      "recharge": null,
      "trigger": null,
      "uses": null
    }
  ],
  "actions": [
    {
      "name": "Multiattack",
      "category": "action",
      "previous_summary_for_context": "Dois ataques com Claws; se ambos acertarem mesmo alvo, Sabedoria CD 13 ou ferida forma passagem astral e ativa Astral Devour.",
      "status": "PENDENTE_ESTRUTURACAO_INTEGRAL",
      "attack_bonus": null,
      "range": null,
      "target": null,
      "damage": null,
      "save_dc": null,
      "save_ability": null,
      "conditions": null,
      "duration": null,
      "recharge": null,
      "trigger": null,
      "uses": null
    },
    {
      "name": "Claws",
      "category": "action",
      "previous_summary_for_context": "Ataque corpo a corpo +4, alcance 5 ft.; 2d6+2 cortante.",
      "status": "PENDENTE_ESTRUTURACAO_INTEGRAL",
      "attack_bonus": null,
      "range": null,
      "target": null,
      "damage": null,
      "save_dc": null,
      "save_ability": null,
      "conditions": null,
      "duration": null,
      "recharge": null,
      "trigger": null,
      "uses": null
    }
  ],
  "bonus_actions": null,
  "reactions": null,
  "legendary_actions": null,
  "lair_actions": null,
  "spellcasting": null,
  "other": null
}
```

## Estatísticas adicionais da pesquisa individual

```json
{
  "armor_class": 12,
  "hit_points": 78,
  "hit_dice": "12d8+24",
  "ability_scores": {
    "STR": 12,
    "DEX": 15,
    "CON": 14,
    "INT": 12,
    "WIS": 16,
    "CHA": 8
  },
  "speeds": "40 ft.",
  "senses": [
    "darkvision 60 ft."
  ],
  "skills": {
    "Arcana": 4,
    "Deception": 1,
    "Perception": 5,
    "Stealth": 4
  },
  "saving_throws": {
    "CON": 4
  },
  "languages": [
    "Deep Speech"
  ],
  "damage_resistances": [
    "bludgeoning n?o m?gico",
    "slashing n?o m?gico"
  ],
  "damage_immunities": null,
  "damage_vulnerabilities": null,
  "condition_immunities": null
}
```

## Atenção

Este material **não é ficha integral homologada**. As informações foram preservadas como pesquisa, sem inventar campos ou poderes ausentes.
