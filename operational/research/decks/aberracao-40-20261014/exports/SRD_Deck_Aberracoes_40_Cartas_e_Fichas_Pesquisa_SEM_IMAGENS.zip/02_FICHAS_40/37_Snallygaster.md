# FICHA — Snallygaster (ordem 37/40)

**Tipo:** Aberração | **ND:** 15 | **Raridade:** Rara | **ID:** TF-285

**Fonte:** Tome of Beasts 3
**URL de referência:** https://www.5esrd.com/database/creature/snallygaster/
**Origem:** Catálogo 607
**Situação documental:** PESQUISA MECÂNICA INDIVIDUAL — não homologada

## Atributos principais localizados

- CA: 16
- PV: 207
- Iniciativa: Não confirmado

## Suporte candidato

**Regeneration (Cura→Ativa)** — Cura

Proposta: a criatura ativa recupera 15 PV no início do seu turno se tiver pelo menos 1 PV e o efeito de suporte ainda estiver ativo conforme fonte/SRD; respeitar limite dos PV máximos.

**Ressalva:** Ícone: Cura verde. A ativação da carta não tem custo; duração e acúmulo seguem a ficha/SRD e a carta vai ao descarte. Ficha local TF-285 segue incompleta, embora a Regeneration esteja documentada na fonte pública.

## Informações mecânicas extraídas das pesquisas

```json
{
  "tracos": null,
  "acoes": null,
  "ataques": [],
  "multiataque": null,
  "acoes_bonus": null,
  "reacoes": null,
  "acoes_lendarias": null,
  "acoes_covil": null,
  "conjuracao": [],
  "custos_lendarios": null
}
```

## Estatísticas adicionais da pesquisa individual

```json
{
  "nd_catalogo": "15",
  "nd_fonte": "15",
  "ca": 16,
  "pv": 207,
  "dados_vida": null,
  "porte": null,
  "tipo": null,
  "alinhamento": null,
  "atributos": null,
  "modificadores": null,
  "deslocamentos": null,
  "pericias": null,
  "salvaguardas": null,
  "sentidos": null,
  "percepcao_passiva": null,
  "idiomas": null,
  "resistencias": null,
  "imunidades_dano": null,
  "imunidades_condicao": null,
  "vulnerabilidades": null
}
```

## Atenção

Este material **não é ficha integral homologada**. As informações foram preservadas como pesquisa, sem inventar campos ou poderes ausentes.
