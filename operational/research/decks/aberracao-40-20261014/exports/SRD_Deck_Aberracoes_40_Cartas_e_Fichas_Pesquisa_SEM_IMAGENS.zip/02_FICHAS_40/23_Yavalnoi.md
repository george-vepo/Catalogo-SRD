# FICHA — Yavalnoi (ordem 23/40)

**Tipo:** Aberração | **ND:** 6 | **Raridade:** Incomum | **ID:** TF-013

**Fonte:** Tome of Beasts 2
**URL de referência:** https://koboldpress.com/tools/kobold-press-monsters/
**Origem:** Catálogo 607
**Situação documental:** PESQUISA MECÂNICA INDIVIDUAL — não homologada

## Atributos principais localizados

- CA: 16
- PV: 126
- Iniciativa: Não confirmado

## Suporte candidato

**Luminous Burst (E)** — Debuff

Sabedoria CD 15; marca alvo e facilita ataques contra ele.

**Ressalva:** Recarga 5–6; confirmar ficha integral e respiração aquática.

## Informações mecânicas extraídas das pesquisas

```json
{
  "traits": [
    {
      "name": "Water Breathing",
      "kind": "passive",
      "legacy_summary": "Respira apenas sob a água.",
      "status": "INCOMPLETA",
      "attack_bonus": null,
      "range": null,
      "targets": null,
      "damage": null,
      "dc": null,
      "save": null,
      "conditions": null,
      "duration": null,
      "recharge": null,
      "uses": null
    },
    {
      "name": "Innate Spellcasting",
      "kind": "passive",
      "legacy_summary": "Carisma, CD 15; sem componentes materiais; à vontade ray of enfeeblement/silent image e três usos diários de control water/slow.",
      "status": "INCOMPLETA",
      "attack_bonus": null,
      "range": null,
      "targets": null,
      "damage": null,
      "dc": null,
      "save": null,
      "conditions": null,
      "duration": null,
      "recharge": null,
      "uses": null
    }
  ],
  "actions": [
    {
      "name": "Multiattack",
      "kind": "action",
      "legacy_summary": "Uma mordida, uma garra e uma cauda.",
      "status": "INCOMPLETA",
      "attack_bonus": null,
      "range": null,
      "targets": null,
      "damage": null,
      "dc": null,
      "save": null,
      "conditions": null,
      "duration": null,
      "recharge": null,
      "uses": null
    },
    {
      "name": "Bite",
      "kind": "action",
      "legacy_summary": "+6; 5 ft.; 2d10+3 perfurante.",
      "status": "INCOMPLETA",
      "attack_bonus": null,
      "range": null,
      "targets": null,
      "damage": null,
      "dc": null,
      "save": null,
      "conditions": null,
      "duration": null,
      "recharge": null,
      "uses": null
    },
    {
      "name": "Claw",
      "kind": "action",
      "legacy_summary": "+6; 5 ft.; 1d8+3 cortante.",
      "status": "INCOMPLETA",
      "attack_bonus": null,
      "range": null,
      "targets": null,
      "damage": null,
      "dc": null,
      "save": null,
      "conditions": null,
      "duration": null,
      "recharge": null,
      "uses": null
    },
    {
      "name": "Tail",
      "kind": "action",
      "legacy_summary": "+6; 10 ft.; 2d6+3 contundente.",
      "status": "INCOMPLETA",
      "attack_bonus": null,
      "range": null,
      "targets": null,
      "damage": null,
      "dc": null,
      "save": null,
      "conditions": null,
      "duration": null,
      "recharge": null,
      "uses": null
    },
    {
      "name": "Luminous Burst",
      "kind": "action",
      "legacy_summary": "Recarga 5–6, SAB CD 15 em 30 ft.; envolve inimigos em brilho, suspende respiração aquática e favorece ataques aliados até recuperação por salvaguarda.",
      "status": "INCOMPLETA",
      "attack_bonus": null,
      "range": null,
      "targets": null,
      "damage": null,
      "dc": null,
      "save": null,
      "conditions": null,
      "duration": null,
      "recharge": null,
      "uses": null
    },
    {
      "name": "Call of the Deep",
      "kind": "action",
      "legacy_summary": "1/dia convoca 2d4 caranguejos gigantes ou 1 polvo gigante, chegada em 1d4 rodadas e duração máxima de uma hora; dispensa como ação bônus.",
      "status": "INCOMPLETA",
      "attack_bonus": null,
      "range": null,
      "targets": null,
      "damage": null,
      "dc": null,
      "save": null,
      "conditions": null,
      "duration": null,
      "recharge": null,
      "uses": null
    }
  ],
  "bonus_actions": null,
  "reactions": null,
  "legendary_actions": null,
  "lair_actions": null,
  "spellcasting": null,
  "other": null
}
```

## Estatísticas adicionais da pesquisa individual

```json
{
  "armor_class": 16,
  "hit_points": 126,
  "hit_dice": "12d10+60",
  "ability_scores": {
    "STR": 17,
    "DEX": 14,
    "CON": 20,
    "INT": 12,
    "WIS": 16,
    "CHA": 18
  },
  "speeds": {
    "andar_ft": 10,
    "nadar_ft": 40
  },
  "senses": [
    "darkvision 90 ft."
  ],
  "skills": {
    "Perception": 6
  },
  "saving_throws": {
    "CON": 8,
    "WIS": 6
  },
  "languages": [
    "Aquan",
    "Primordial"
  ],
  "damage_resistances": [
    "cold"
  ],
  "damage_immunities": null,
  "damage_vulnerabilities": null,
  "condition_immunities": null
}
```

## Atenção

Este material **não é ficha integral homologada**. As informações foram preservadas como pesquisa, sem inventar campos ou poderes ausentes.
