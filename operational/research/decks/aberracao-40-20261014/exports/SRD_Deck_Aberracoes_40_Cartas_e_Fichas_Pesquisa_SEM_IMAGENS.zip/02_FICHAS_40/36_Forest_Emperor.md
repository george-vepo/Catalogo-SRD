# FICHA — Forest Emperor (ordem 36/40)

**Tipo:** Aberração | **ND:** 15 | **Raridade:** Rara | **ID:** KP-S002

**Fonte:** Tome of Beasts 2
**URL de referência:** https://www.5esrd.com/database/creature/forest-emperor/
**Origem:** Catálogo 607
**Situação documental:** RESUMO MECÂNICO DE PESQUISA — não integral

## Atributos principais localizados

- CA: 18
- PV: 161
- Iniciativa: +1

## Suporte candidato

**Rattle (E)** — Debuff

Sabedoria CD 18; pode impor Amedrontado.

**Ressalva:** Regra original de som, novos testes e imunidade após sucessos.

## Informações mecânicas extraídas das pesquisas

```json
{
  "fonte_publicacao": "Tome of Beasts 2",
  "editora_fonte": "Kobold Press / Open Design LLC",
  "sistema": "D&D 5e; bloco mecânico conferido em referência secundária que reproduz a página 155 de Tome of Beasts 2",
  "porte": "Huge",
  "tipo_fonte": "aberration",
  "alinhamento": "neutral evil",
  "nd_fonte": "15",
  "ca": 18,
  "ca_base": "natural armor",
  "pv": 161,
  "formula_pv": "14d12 + 70",
  "deslocamento": {
    "walk_ft": 30,
    "climb_ft": 30,
    "fly_ft": 60
  },
  "salvaguardas": {
    "CON": 10,
    "WIS": 10
  },
  "pericias": {
    "Nature": 6,
    "Perception": 10,
    "Stealth": 6
  },
  "resistencias_dano": [],
  "imunidades_dano": [
    "acid",
    "cold",
    "bludgeoning de ataques não mágicos"
  ],
  "vulnerabilidades_dano": [],
  "imunidades_condicao": [],
  "sentidos": [
    "darkvision 60 ft."
  ],
  "percepcao_passiva": 20,
  "idiomas": [
    "Common",
    "Giant"
  ],
  "bonus_proficiencia": 5,
  "bonus_proficiencia_origem": "derivado do ND 15 pela progressão de D&D 5e; não aparece como campo separado na referência consultada",
  "tracos": [
    {
      "nome": "Forest Camouflage",
      "resumo_mecanico": "Tem vantagem em testes de Destreza (Furtividade) para se esconder em terreno de floresta."
    },
    {
      "nome": "Keen Smell",
      "resumo_mecanico": "Tem vantagem em testes de Sabedoria (Percepção) baseados no olfato."
    },
    {
      "nome": "Rattle",
      "resumo_mecanico": "No início do turno de cada criatura que possa ouvi-lo e esteja a até 60 ft., ela faz salvaguarda de Sabedoria CD 18; falha causa medo até o início do próximo turno dela. Após duas salvaguardas bem-sucedidas, a criatura fica imune ao Rattle por 24 horas.",
      "salvaguarda": "Wisdom DC 18",
      "alcance": "60 ft.",
      "duracao": "até o início do próximo turno; imunidade por 24 horas após duas salvaguardas bem-sucedidas"
    }
  ],
  "acoes": [
    {
      "nome": "Multiattack",
      "resumo_mecanico": "Faz dois ataques Acidic Claw e um Tail. Se as duas garras acertarem a mesma criatura, ela faz salvaguarda de Constituição CD 18; em falha, seu máximo de PV diminui em 7 (2d6), e o Forest Emperor recupera a mesma quantidade. A redução termina após descanso longo; a criatura morre se seu máximo chegar a 0.",
      "salvaguarda": "Constitution DC 18"
    },
    {
      "nome": "Acidic Claw",
      "resumo_mecanico": "Ataque corpo a corpo +11, alcance 5 ft.; 16 (3d6+6) cortante e 7 (2d6) ácido.",
      "ataque": "+11",
      "alcance": "5 ft.",
      "dano": [
        {
          "dados": "3d6+6",
          "tipo": "slashing"
        },
        {
          "dados": "2d6",
          "tipo": "acid"
        }
      ]
    },
    {
      "nome": "Tail",
      "resumo_mecanico": "Ataque corpo a corpo +11, alcance 15 ft.; 17 (2d10+6) contundente.",
      "ataque": "+11",
      "alcance": "15 ft.",
      "dano": [
        {
          "dados": "2d10+6",
          "tipo": "bludgeoning"
        }
      ]
    },
    {
      "nome": "Toxic Nectar Spray (Recharge 5–6)",
      "resumo_mecanico": "Projeta ácido em cone de 60 ft.; salvaguarda de Destreza CD 18, 42 (12d6) ácido em falha ou metade em sucesso.",
      "uso": "Recharge 5–6",
      "salvaguarda": "Dexterity DC 18",
      "alcance": "cone de 60 ft.",
      "dano": [
        {
          "dados": "12d6",
          "tipo": "acid"
        }
      ]
    }
  ],
  "secoes_nao_listadas": [
    "ações bônus",
    "reações",
    "ações lendárias",
    "ações míticas",
    "ações de covil",
    "conjuração"
  ],
  "fontes_adicionais": [
    {
      "titulo": "Índice oficial de monstros 5e da Kobold Press (identidade, ND, porte, tipo e publicação)",
      "url": "https://koboldpress.com/tools/kobold-press-monsters/"
    },
    {
      "titulo": "Página individual 5eSRD (bloqueada para leitura direta por exigência de JavaScript)",
      "url": "https://www.5esrd.com/database/creature/forest-emperor/"
    },
    {
      "titulo": "Referência secundária: réplica digital de Tome of Beasts 2, página impressa 155",
      "url": "https://anyflip.com/dhfzu/umbm/basic/151-200"
    }
  ],
  "classe_fonte": "Metadados validados no índice oficial da Kobold Press; estatísticas completas conferidas em referência secundária que reproduz a página 155 de Tome of Beasts 2. O texto da ficha não foi reproduzido.",
  "completa": true,
  "atributos": {
    "FOR": {
      "valor": 23,
      "modificador": 6
    },
    "DES": {
      "valor": 12,
      "modificador": 1
    },
    "CON": {
      "valor": 21,
      "modificador": 5
    },
    "INT": {
      "valor": 12,
      "modificador": 1
    },
    "SAB": {
      "valor": 20,
      "modificador": 5
    },
    "CAR": {
      "valor": 8,
      "modificador": -1
    }
  },
  "iniciativa": {
    "modificador_base_des": 1,
    "valor_formatado": "+1",
    "origem": "derivada do modificador de Destreza; fonte não informa bônus adicional"
  },
  "fonte_url": "https://www.5esrd.com/database/creature/forest-emperor/",
  "variante": "Não indicada na fonte",
  "data_verificacao": "2026-10-10",
  "secoes_cobertas": [
    "identidade",
    "porte",
    "tipo",
    "ND",
    "CA",
    "PV e fórmula",
    "deslocamento",
    "atributos e modificadores",
    "salvaguardas",
    "perícias",
    "sentidos",
    "idiomas",
    "defesas",
    "traços",
    "ações",
    "recursos e recargas",
    "CDs e condições"
  ],
  "secoes_nao_listadas_na_fonte": [
    "ações bônus",
    "reações",
    "ações lendárias",
    "ações míticas",
    "ações de covil",
    "conjuração"
  ],
  "transcricao_integral": false,
  "observacao_direitos": "Fatos mecânicos e resumo próprio; sem reprodução integral da redação externa."
}
```

## Atenção

Este material **não é ficha integral homologada**. As informações foram preservadas como pesquisa, sem inventar campos ou poderes ausentes.
