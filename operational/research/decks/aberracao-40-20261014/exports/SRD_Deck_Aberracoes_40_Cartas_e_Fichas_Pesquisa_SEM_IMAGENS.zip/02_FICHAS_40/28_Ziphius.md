# FICHA — Ziphius (ordem 28/40)

**Tipo:** Aberração | **ND:** 8 | **Raridade:** Incomum | **ID:** TF-014

**Fonte:** Creature Codex
**URL de referência:** https://koboldpress.com/tools/kobold-press-monsters/
**Origem:** Catálogo 607
**Situação documental:** PESQUISA MECÂNICA INDIVIDUAL — não homologada

## Atributos principais localizados

- CA: 16
- PV: 135
- Iniciativa: Não confirmado

## Suporte candidato

**Telepathic Foresight (B→Ativa/E)** — Buff

Sabedoria CD 15; vínculo concede vantagem ofensiva ou desvantagem nos ataques do alvo.

**Ressalva:** Transferir beneficiário é homebrew; confirmar duração/edição.

## Informações mecânicas extraídas das pesquisas

```json
{
  "traits": [
    {
      "name": "Charge",
      "kind": "passive",
      "legacy_summary": "Após avanço retilíneo de 20 ft. e ataque com barbatana no mesmo turno, soma 5d10 cortante.",
      "status": "INCOMPLETA",
      "attack_bonus": null,
      "range": null,
      "targets": null,
      "damage": null,
      "dc": null,
      "save": null,
      "conditions": null,
      "duration": null,
      "recharge": null,
      "uses": null
    },
    {
      "name": "Siege Monster",
      "kind": "passive",
      "legacy_summary": "Dano dobrado a objetos e construções.",
      "status": "INCOMPLETA",
      "attack_bonus": null,
      "range": null,
      "targets": null,
      "damage": null,
      "dc": null,
      "save": null,
      "conditions": null,
      "duration": null,
      "recharge": null,
      "uses": null
    },
    {
      "name": "Telepathic Foresight",
      "kind": "passive",
      "legacy_summary": "Ação bônus no início do turno; alvo a 120 ft. faz SAB CD15, e vínculo concede vantagem contra alvo ou impõe desvantagem contra criatura até turno seguinte.",
      "status": "INCOMPLETA",
      "attack_bonus": null,
      "range": null,
      "targets": null,
      "damage": null,
      "dc": null,
      "save": null,
      "conditions": null,
      "duration": null,
      "recharge": null,
      "uses": null
    },
    {
      "name": "Water Breathing",
      "kind": "passive",
      "legacy_summary": "Respira apenas na água.",
      "status": "INCOMPLETA",
      "attack_bonus": null,
      "range": null,
      "targets": null,
      "damage": null,
      "dc": null,
      "save": null,
      "conditions": null,
      "duration": null,
      "recharge": null,
      "uses": null
    }
  ],
  "actions": [
    {
      "name": "Multiattack",
      "kind": "action",
      "legacy_summary": "Um ataque de bico e um de garra.",
      "status": "INCOMPLETA",
      "attack_bonus": null,
      "range": null,
      "targets": null,
      "damage": null,
      "dc": null,
      "save": null,
      "conditions": null,
      "duration": null,
      "recharge": null,
      "uses": null
    },
    {
      "name": "Claw",
      "kind": "action",
      "legacy_summary": "+7; 5 ft.; 3d6+4 cortante.",
      "status": "INCOMPLETA",
      "attack_bonus": null,
      "range": null,
      "targets": null,
      "damage": null,
      "dc": null,
      "save": null,
      "conditions": null,
      "duration": null,
      "recharge": null,
      "uses": null
    },
    {
      "name": "Beak",
      "kind": "action",
      "legacy_summary": "+7; 5 ft.; 2d8+4 perfurante; criatura Large ou menor testa FOR CD15 ou é engolida; dentro sofre 4d6 ácido por turno e há regras de regurgitação.",
      "status": "INCOMPLETA",
      "attack_bonus": null,
      "range": null,
      "targets": null,
      "damage": null,
      "dc": null,
      "save": null,
      "conditions": null,
      "duration": null,
      "recharge": null,
      "uses": null
    },
    {
      "name": "Dorsal Fin",
      "kind": "action",
      "legacy_summary": "+7; 10 ft.; 3d10+4 cortante.",
      "status": "INCOMPLETA",
      "attack_bonus": null,
      "range": null,
      "targets": null,
      "damage": null,
      "dc": null,
      "save": null,
      "conditions": null,
      "duration": null,
      "recharge": null,
      "uses": null
    }
  ],
  "bonus_actions": null,
  "reactions": null,
  "legendary_actions": null,
  "lair_actions": null,
  "spellcasting": null,
  "other": null
}
```

## Estatísticas adicionais da pesquisa individual

```json
{
  "armor_class": 16,
  "hit_points": 135,
  "hit_dice": "10d20+30",
  "ability_scores": {
    "STR": 19,
    "DEX": 13,
    "CON": 16,
    "INT": 9,
    "WIS": 13,
    "CHA": 4
  },
  "speeds": {
    "andar_ft": 10,
    "nadar_ft": 60
  },
  "senses": [
    "blindsight 120 ft."
  ],
  "skills": {
    "Perception": 4
  },
  "saving_throws": {
    "STR": 7
  },
  "languages": [
    "Aquan",
    "telepathy 120 ft."
  ],
  "damage_resistances": [
    "cold",
    "bludgeoning/piercing/slashing não mágicos"
  ],
  "damage_immunities": null,
  "damage_vulnerabilities": null,
  "condition_immunities": [
    "prone"
  ]
}
```

## Atenção

Este material **não é ficha integral homologada**. As informações foram preservadas como pesquisa, sem inventar campos ou poderes ausentes.
