# FICHA — Xenabsorber (ordem 12/40)

**Tipo:** Aberração | **ND:** 3 | **Raridade:** Comum | **ID:** TF-006

**Fonte:** Creature Codex
**URL de referência:** https://www.5esrd.com/database/creature/xenabsorber/
**Origem:** Catálogo 607
**Situação documental:** RESUMO MECÂNICO DE PESQUISA — não integral

## Atributos principais localizados

- CA: 15
- PV: 65
- Iniciativa: +1

## Suporte candidato

**Slam (D)** — Dano

+5, 1d10+3 contundente.

**Ressalva:** Trait Mimicry depende de imitação e alvo elegível; fonte em resumo.

## Informações mecânicas extraídas das pesquisas

```json
{
  "fonte_publicacao": "Creature Codex",
  "editora_fonte": "Kobold Press / Open Design LLC",
  "sistema": "D&D 5e (bloco atribuído a Kobold Press, hospedado pelo 5eSRD)",
  "porte": "Medium",
  "tipo_fonte": "aberration",
  "alinhamento": "chaotic neutral",
  "nd_fonte": "3",
  "ca": 15,
  "ca_base": "natural armor",
  "pv": 65,
  "formula_pv": "10d8 + 20",
  "deslocamento": {
    "walk_ft": 30
  },
  "salvaguardas": {},
  "pericias": {
    "Deception": 4,
    "Perception": 5
  },
  "resistencias_dano": [],
  "imunidades_dano": [],
  "vulnerabilidades_dano": [],
  "imunidades_condicao": [],
  "sentidos": [
    "darkvision 60 ft."
  ],
  "percepcao_passiva": 15,
  "idiomas": [
    "Common"
  ],
  "bonus_proficiencia": 2,
  "bonus_proficiencia_origem": "derivado do ND 3 pela tabela padrão de proficiência de D&D 5e; não impresso no bloco",
  "tracos": [
    {
      "nome": "Disguise",
      "resumo_mecanico": "Tem vantagem em testes de Deception para se passar pelo tipo de criatura que imita, desde que possua ao menos uma característica desse tipo."
    },
    {
      "nome": "Trait Mimicry",
      "resumo_mecanico": "Como ação bônus, copia uma característica física, ataque ou reação não mágico de besta ou humanoide com ND igual ou inferior a 3 que tenha visto na última semana. Pode manter até cinco características simultâneas, no máximo dois ataques; substitui uma ao usar novamente e perde todas após uma semana sem exposição a besta ou humanoide. Não copia swarm, shapechanger, Change Shape ou características/ataques/reações de Spellcasting. Ataques copiados causam sempre 1d10+3 (8 em média) do tipo normal; CD de salvaguarda fixa 13. Pode copiar condições adicionais do ataque, como grapple ou prone, mas não veneno; precisa satisfazer pré-requisitos. Também copia locomoção natural, não mágica, de besta/humanoide à própria velocidade."
    }
  ],
  "acoes": [
    {
      "nome": "Multiattack",
      "resumo_mecanico": "Faz dois ataques corpo a corpo."
    },
    {
      "nome": "Slam",
      "resumo_mecanico": "Ataque corpo a corpo +5, alcance 5 ft.; 1d10+3 bludgeoning.",
      "ataque": "+5",
      "alcance": "5 ft.",
      "dano": [
        {
          "dados": "1d10+3",
          "tipo": "bludgeoning"
        }
      ]
    }
  ],
  "acoes_bonus": [
    {
      "nome": "Trait Mimicry",
      "resumo_mecanico": "Adquire ou substitui uma característica física, ataque, reação ou modo natural de locomoção elegível observado na última semana, conforme os limites do traço Trait Mimicry."
    }
  ],
  "reacoes": [],
  "conjuracao": null,
  "secoes_nao_listadas": [
    "salvaguardas",
    "resistências, imunidades e vulnerabilidades",
    "imunidades a condições",
    "reações",
    "conjuração",
    "ações lendárias",
    "ações míticas",
    "ações de covil"
  ],
  "atributos": {
    "FOR": {
      "valor": 17,
      "modificador": 3
    },
    "DES": {
      "valor": 12,
      "modificador": 1
    },
    "CON": {
      "valor": 15,
      "modificador": 2
    },
    "INT": {
      "valor": 10,
      "modificador": 0
    },
    "SAB": {
      "valor": 13,
      "modificador": 1
    },
    "CAR": {
      "valor": 15,
      "modificador": 2
    }
  },
  "iniciativa": {
    "modificador_base_des": 1,
    "valor_formatado": "+1",
    "origem": "derivada do modificador de Destreza; fonte não informa bônus adicional"
  },
  "fonte_url": "https://www.5esrd.com/database/creature/xenabsorber/",
  "variante": "Não indicada na fonte",
  "classe_fonte": "Referência hospedada pelo 5eSRD; bloco atribuído à Kobold Press/Open Design LLC.",
  "data_verificacao": "2026-10-10",
  "secoes_cobertas": [
    "identidade",
    "porte",
    "tipo",
    "ND",
    "CA",
    "PV e fórmula",
    "deslocamento",
    "atributos e modificadores",
    "salvaguardas",
    "perícias",
    "sentidos",
    "idiomas",
    "defesas",
    "traços",
    "ações",
    "recursos e recargas",
    "CDs e condições",
    "ações bônus"
  ],
  "secoes_nao_listadas_na_fonte": [
    "salvaguardas",
    "resistências, imunidades e vulnerabilidades",
    "imunidades a condições",
    "reações",
    "conjuração",
    "ações lendárias",
    "ações míticas",
    "ações de covil"
  ],
  "transcricao_integral": false,
  "observacao_direitos": "Fatos mecânicos e resumo próprio; sem reprodução integral da redação externa."
}
```

## Atenção

Este material **não é ficha integral homologada**. As informações foram preservadas como pesquisa, sem inventar campos ou poderes ausentes.
