# FICHA — Gazer (ordem 3/40)

**Tipo:** Aberração | **ND:** 1/2 | **Raridade:** Comum | **ID:** sem ID aprovado

**Fonte:** Mordenkainen Presents: Monsters of the Multiverse
**URL de referência:** https://www.dndbeyond.com/monsters?page=4&sort=type
**Origem:** Candidata externa (não aprovada)
**Situação documental:** FICHA EXTERNA NÃO INTEGRADA

## Atributos principais localizados

- CA: Não confirmado
- PV: Não confirmado
- Iniciativa: Não confirmado

## Suporte candidato

**Eye Rays (E/D)** — Misto (Dano e Debuff; principal a revisar)

Dois raios determinados aleatoriamente, com controle/dano conforme edição.

**Ressalva:** Ficha externa; sortear raios, não escolher livremente.

## Informações mecânicas extraídas das pesquisas

Nenhum bloco mecânico integral foi localizado nos arquivos incluídos.

## Atenção

Este material **não é ficha integral homologada**. As informações foram preservadas como pesquisa, sem inventar campos ou poderes ausentes.
