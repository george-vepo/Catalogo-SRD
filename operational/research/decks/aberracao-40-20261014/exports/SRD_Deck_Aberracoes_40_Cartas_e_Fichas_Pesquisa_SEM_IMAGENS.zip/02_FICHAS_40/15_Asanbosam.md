# FICHA — Asanbosam (ordem 15/40)

**Tipo:** Aberração | **ND:** 5 | **Raridade:** Comum | **ID:** TF-003

**Fonte:** Tome of Beasts 1
**URL de referência:** https://www.5esrd.com/database/creature/asanbosam-3pp/
**Origem:** Catálogo 607
**Situação documental:** RESUMO MECÂNICO DE PESQUISA — não integral

## Atributos principais localizados

- CA: 14
- PV: 102
- Iniciativa: +1

## Suporte candidato

**Claws (E/D)** — Misto (Dano e Debuff; principal a revisar)

+7, 3d10+4 perfurante; Agarrado/Contido, fuga CD 14 e possível doença.

**Ressalva:** Verificar condições, salvaguarda de doença e duração.

## Informações mecânicas extraídas das pesquisas

```json
{
  "fonte_publicacao": "Tome of Beasts 1",
  "editora_fonte": "Kobold Press / Open Design LLC",
  "sistema": "D&D 5e (bloco atribuído a Kobold Press, hospedado pelo 5eSRD)",
  "porte": "Large",
  "tipo_fonte": "aberration",
  "alinhamento": "chaotic evil",
  "nd_fonte": "5",
  "ca": 14,
  "ca_base": "natural armor",
  "pv": 102,
  "formula_pv": "12d10 + 36",
  "deslocamento": {
    "walk_ft": 40,
    "climb_ft": 15
  },
  "salvaguardas": {},
  "pericias": {
    "Acrobatics": 4,
    "Perception": 3,
    "Stealth": 4
  },
  "resistencias_dano": [],
  "imunidades_dano": [],
  "vulnerabilidades_dano": [],
  "imunidades_condicao": [],
  "sentidos": [
    "darkvision 60 ft."
  ],
  "percepcao_passiva": 13,
  "idiomas": [
    "Giant"
  ],
  "bonus_proficiencia": 3,
  "tracos": [
    {
      "nome": "Spider Climb",
      "resumo_mecanico": "Escala superfícies difíceis, inclusive tetos de cabeça para baixo, sem teste de atributo."
    }
  ],
  "acoes": [
    {
      "nome": "Multiattack",
      "resumo_mecanico": "Faz um ataque de Bite e um de Claws."
    },
    {
      "nome": "Bite",
      "resumo_mecanico": "Ataque corpo a corpo +7, alcance 5 ft.; 2d10+4 piercing. Alvo criatura faz salvaguarda de Constituição CD 14; em falha sofre 2d10 poison e contrai doença, ficando Poisoned até a doença terminar. Repete o teste a cada 24 horas: sucesso encerra a doença; falha reduz o máximo de PV em 1d10 (5 em média), redução que dura até a doença terminar. Se o máximo chegar a 0, morre.",
      "ataque": "+7",
      "alcance": "5 ft.",
      "dano": [
        {
          "dados": "2d10+4",
          "tipo": "piercing"
        },
        {
          "dados": "2d10",
          "tipo": "poison em falha na salvaguarda"
        }
      ],
      "salvaguarda": "Constitution DC 14"
    },
    {
      "nome": "Claws",
      "resumo_mecanico": "Ataque corpo a corpo +7, alcance 10 ft.; 3d10+4 piercing e agarra o alvo (fuga CD 14). Enquanto agarrado, fica Restrained e o asanbosam não pode usar Claws contra outro alvo. Alvo criatura faz salvaguarda de Constituição CD 14 ou contrai a doença descrita em Bite.",
      "ataque": "+7",
      "alcance": "10 ft.",
      "dano": [
        {
          "dados": "3d10+4",
          "tipo": "piercing"
        }
      ],
      "salvaguarda": "Constitution DC 14; escape DC 14"
    }
  ],
  "acoes_bonus": [
    {
      "nome": "Arboreal Escape",
      "resumo_mecanico": "Enquanto estiver em uma árvore, usa Disengage ou Hide como ação bônus."
    }
  ],
  "reacoes": [],
  "conjuracao": null,
  "secoes_nao_listadas": [
    "salvaguardas",
    "resistências, imunidades e vulnerabilidades",
    "imunidades a condições",
    "reações",
    "conjuração",
    "ações lendárias",
    "ações míticas",
    "ações de covil"
  ],
  "atributos": {
    "FOR": {
      "valor": 18,
      "modificador": 4
    },
    "DES": {
      "valor": 13,
      "modificador": 1
    },
    "CON": {
      "valor": 17,
      "modificador": 3
    },
    "INT": {
      "valor": 11,
      "modificador": 0
    },
    "SAB": {
      "valor": 10,
      "modificador": 0
    },
    "CAR": {
      "valor": 5,
      "modificador": -3
    }
  },
  "iniciativa": {
    "modificador_base_des": 1,
    "valor_formatado": "+1",
    "origem": "derivada do modificador de Destreza; fonte não informa bônus adicional"
  },
  "fonte_url": "https://www.5esrd.com/database/creature/asanbosam-3pp/",
  "variante": "Não indicada na fonte",
  "classe_fonte": "Referência hospedada pelo 5eSRD; bloco atribuído à Kobold Press/Open Design LLC.",
  "data_verificacao": "2026-10-10",
  "secoes_cobertas": [
    "identidade",
    "porte",
    "tipo",
    "ND",
    "CA",
    "PV e fórmula",
    "deslocamento",
    "atributos e modificadores",
    "salvaguardas",
    "perícias",
    "sentidos",
    "idiomas",
    "defesas",
    "traços",
    "ações",
    "recursos e recargas",
    "CDs e condições",
    "ações bônus"
  ],
  "secoes_nao_listadas_na_fonte": [
    "salvaguardas",
    "resistências, imunidades e vulnerabilidades",
    "imunidades a condições",
    "reações",
    "conjuração",
    "ações lendárias",
    "ações míticas",
    "ações de covil"
  ],
  "transcricao_integral": false,
  "observacao_direitos": "Fatos mecânicos e resumo próprio; sem reprodução integral da redação externa."
}
```

## Atenção

Este material **não é ficha integral homologada**. As informações foram preservadas como pesquisa, sem inventar campos ou poderes ausentes.
