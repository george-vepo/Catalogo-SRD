# FICHA — Ahu-Nixta, Drudge (ordem 1/40)

**Tipo:** Aberração | **ND:** 0.5 | **Raridade:** Comum | **ID:** TF-002

**Fonte:** Tome of Beasts 2
**URL de referência:** https://www.5esrd.com/database/creature/ahu-nixta-drudge/
**Origem:** Catálogo 607
**Situação documental:** RESUMO MECÂNICO DE PESQUISA — não integral

## Atributos principais localizados

- CA: 13
- PV: 26
- Iniciativa: +1

## Suporte candidato

**Fear (E)** — Debuff

Magia inata de medo; ficha de pesquisa registra CD 11, 1/dia.

**Ressalva:** Conferir a magia integral e recursos.

## Informações mecânicas extraídas das pesquisas

```json
{
  "fonte_publicacao": "Tome of Beasts 2",
  "editora_fonte": "Kobold Press / Open Design LLC",
  "sistema": "D&D 5e (conteúdo de terceiro hospedado pelo 5eSRD)",
  "porte": "Medium",
  "tipo_fonte": "aberration",
  "alinhamento": "neutral evil",
  "nd_fonte": "1/2",
  "ca": 13,
  "ca_base": "clockwork armor",
  "pv": 26,
  "formula_pv": "4d8 + 8",
  "deslocamento": {
    "walk_ft": 30,
    "fly_ft": 30,
    "fly_hover": true,
    "swim_ft": 30
  },
  "salvaguardas": {},
  "pericias": {
    "Perception": 2
  },
  "resistencias_dano": [],
  "imunidades_dano": [
    "poison",
    "psychic"
  ],
  "vulnerabilidades_dano": [],
  "imunidades_condicao": [
    "charmed",
    "exhaustion",
    "frightened",
    "paralyzed",
    "petrified",
    "poisoned",
    "prone"
  ],
  "sentidos": [
    "darkvision 60 ft."
  ],
  "percepcao_passiva": 11,
  "idiomas": [
    "Deep Speech",
    "Void Speech"
  ],
  "bonus_proficiencia": 2,
  "tracos": [
    {
      "nome": "Clockwork Encasement",
      "resumo_mecanico": "O ser precisa permanecer na armadura mecânica e morre quando ela chega a 0 PV."
    },
    {
      "nome": "Immutable Form",
      "resumo_mecanico": "A criatura e a armadura são imunes a efeitos que alterem a forma enquanto ela permanecer dentro da armadura."
    },
    {
      "nome": "Innate Spellcasting",
      "resumo_mecanico": "Atributo Inteligência, CD 11, +3 para ataques mágicos; sem componentes materiais."
    }
  ],
  "acoes": [
    {
      "nome": "Whirring Blades",
      "resumo_mecanico": "Ataque corpo a corpo +4, alcance 5 ft.; 2d4+2 slashing.",
      "ataque": "+4",
      "alcance": "5 ft.",
      "dano": [
        {
          "dados": "2d4+2",
          "tipo": "slashing"
        }
      ]
    }
  ],
  "acoes_bonus": [],
  "reacoes": [],
  "conjuracao": {
    "atributo": "INT",
    "cd": 11,
    "ataque_magia": "+3",
    "sem_componentes": [
      "material"
    ],
    "at_will": [
      "firebolt (1d10)"
    ],
    "1/day": [
      "fear"
    ]
  },
  "nota_tatica": "A ficha não informa multiataque; usa um ataque Whirring Blades.",
  "secoes_nao_listadas": [
    "salvaguardas",
    "ações bônus",
    "reações",
    "ações lendárias",
    "ações míticas",
    "ações de covil"
  ],
  "atributos": {
    "FOR": {
      "valor": 15,
      "modificador": 2
    },
    "DES": {
      "valor": 12,
      "modificador": 1
    },
    "CON": {
      "valor": 14,
      "modificador": 2
    },
    "INT": {
      "valor": 12,
      "modificador": 1
    },
    "SAB": {
      "valor": 10,
      "modificador": 0
    },
    "CAR": {
      "valor": 10,
      "modificador": 0
    }
  },
  "iniciativa": {
    "modificador_base_des": 1,
    "valor_formatado": "+1",
    "origem": "derivada do modificador de Destreza; fonte não informa bônus adicional"
  },
  "fonte_url": "https://www.5esrd.com/database/creature/ahu-nixta-drudge/",
  "variante": "Drudge",
  "classe_fonte": "Referência hospedada pelo 5eSRD; bloco atribuído à Kobold Press/Open Design LLC.",
  "data_verificacao": "2026-10-10",
  "secoes_cobertas": [
    "identidade",
    "porte",
    "tipo",
    "ND",
    "CA",
    "PV e fórmula",
    "deslocamento",
    "atributos e modificadores",
    "salvaguardas",
    "perícias",
    "sentidos",
    "idiomas",
    "defesas",
    "traços",
    "ações",
    "recursos e recargas",
    "CDs e condições",
    "conjuração"
  ],
  "secoes_nao_listadas_na_fonte": [
    "salvaguardas",
    "ações bônus",
    "reações",
    "ações lendárias",
    "ações míticas",
    "ações de covil"
  ],
  "transcricao_integral": false,
  "observacao_direitos": "Fatos mecânicos e resumo próprio; sem reprodução integral da redação externa."
}
```

## Atenção

Este material **não é ficha integral homologada**. As informações foram preservadas como pesquisa, sem inventar campos ou poderes ausentes.
