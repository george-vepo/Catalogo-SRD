# FICHA — Ahu-Nixta, Cataphract (ordem 26/40)

**Tipo:** Aberração | **ND:** 8 | **Raridade:** Incomum | **ID:** TF-008

**Fonte:** Tome of Beasts 2
**URL de referência:** https://www.5esrd.com/database/creature/ahu-nixta-cataphract/
**Origem:** Catálogo 607
**Situação documental:** RESUMO MECÂNICO DE PESQUISA — não integral

## Atributos principais localizados

- CA: 17
- PV: 135
- Iniciativa: -1

## Suporte candidato

**Fear (E)** — Debuff

Magia inata de medo, CD 15.

**Ressalva:** Confirmar recursos de magia integral.

## Informações mecânicas extraídas das pesquisas

```json
{
  "fonte_publicacao": "Tome of Beasts 2",
  "editora_fonte": "Kobold Press / Open Design LLC",
  "sistema": "D&D 5e; metadados de identidade conferidos no índice oficial da Kobold Press; bloco mecânico consultado em transcrição secundária comunitária de conteúdo OGL.",
  "porte": "Large",
  "tipo_fonte": "aberration",
  "alinhamento": "neutral evil",
  "nd_fonte": "8",
  "ca": 17,
  "ca_base": "clockwork armor",
  "pv": 135,
  "formula_pv": "18d10 + 36",
  "deslocamento": {
    "walk_ft": 30,
    "fly_ft": 30,
    "fly_hover": true,
    "swim_ft": 30
  },
  "salvaguardas": {},
  "pericias": {
    "Perception": 4
  },
  "resistencias_dano": [],
  "imunidades_dano": [
    "poison",
    "psychic"
  ],
  "vulnerabilidades_dano": [],
  "imunidades_condicao": [
    "charmed",
    "exhaustion",
    "frightened",
    "paralyzed",
    "petrified",
    "poisoned",
    "prone"
  ],
  "sentidos": [
    "darkvision 60 ft."
  ],
  "percepcao_passiva": 14,
  "idiomas": [
    "Deep Speech",
    "Void Speech"
  ],
  "bonus_proficiencia": 3,
  "bonus_proficiencia_origem": "derivado do ND 8 pela progressão de D&D 5e; a transcrição secundária não lista um bônus separado",
  "tracos": [
    {
      "nome": "Clockwork Encasement",
      "resumo_mecanico": "A armadura permite atacar e interagir por meio de manipuladores. Ao chegar a 0 PV, quebra e o ahu-nixta sai. Sem armadura: CA 12, 37 PV (5d10 + 10), Força 9 (-1), todos os deslocamentos 20 ft. e sem ações de ataque; ainda pode conjurar. Apêndices podem manipular objetos, mas não servem para combate. Abrir ou fechar visores não exige ação; entrar ou sair da armadura exige ação bônus."
    },
    {
      "nome": "Immutable Form",
      "resumo_mecanico": "A armadura é imune a magias e efeitos que alterem sua forma; o ahu-nixta também recebe essa proteção enquanto permanecer nela."
    },
    {
      "nome": "Innate Spellcasting",
      "resumo_mecanico": "Usa Inteligência; CD 15 para suas magias e +7 para ataques mágicos. À vontade: fear, fire bolt (2d10) e telekinesis. Não requer componentes materiais."
    }
  ],
  "acoes": [
    {
      "nome": "Multiattack",
      "resumo_mecanico": "Faz três ataques corpo a corpo; pode substituir dois deles por uma magia à vontade. Alternativamente, usa Arcane Cannon duas vezes."
    },
    {
      "nome": "Whirring Blades",
      "resumo_mecanico": "Ataque corpo a corpo +8, alcance 5 ft.; 12 (3d4 + 5) slashing. O alvo faz salvaguarda de Destreza CD 15 ou sofre 5 (2d4) slashing no início do próximo turno.",
      "ataque": "+8",
      "alcance": "5 ft.",
      "dano": [
        {
          "dados": "3d4 + 5",
          "tipo": "slashing"
        },
        {
          "dados": "2d4",
          "tipo": "slashing; salvaguarda de Destreza CD 15 falha"
        }
      ],
      "salvaguarda": "Dexterity DC 15"
    },
    {
      "nome": "Pronged Scepter",
      "resumo_mecanico": "Ataque corpo a corpo +8, alcance 10 ft.; 12 (2d6 + 5) piercing.",
      "ataque": "+8",
      "alcance": "10 ft.",
      "dano": [
        {
          "dados": "2d6 + 5",
          "tipo": "piercing"
        }
      ]
    },
    {
      "nome": "Bashing Rod",
      "resumo_mecanico": "Ataque corpo a corpo +8, alcance 5 ft.; 16 (2d10 + 5) bludgeoning.",
      "ataque": "+8",
      "alcance": "5 ft.",
      "dano": [
        {
          "dados": "2d10 + 5",
          "tipo": "bludgeoning"
        }
      ]
    },
    {
      "nome": "Arcane Cannon",
      "resumo_mecanico": "Ataque mágico à distância +7, alcance 100 ft.; 18 (4d8) force. O alvo faz salvaguarda de Força CD 15 ou cai Prone.",
      "ataque": "+7",
      "alcance": "100 ft.",
      "dano": [
        {
          "dados": "4d8",
          "tipo": "force"
        }
      ],
      "salvaguarda": "Strength DC 15"
    }
  ],
  "acoes_bonus": [],
  "reacoes": [],
  "conjuracao": null,
  "nota_tatica": "",
  "secoes_nao_listadas": [
    "salvaguardas",
    "resistências de dano",
    "vulnerabilidades de dano",
    "ações bônus",
    "reações",
    "ações lendárias",
    "ações míticas",
    "ações de covil"
  ],
  "fontes_adicionais": [
    {
      "titulo": "Índice oficial Kobold Press 5e (nome, variante, Tome of Beasts 2, porte, tipo e ND)",
      "url": "https://koboldpress.com/tools/kobold-press-monsters/"
    },
    {
      "titulo": "D&D Grove (transcrição secundária; omite natação no campo Speed)",
      "url": "https://www.dndgrove.com/bestiary/8/ahu-nixta-cataphract"
    },
    {
      "titulo": "Robinloft (transcrição secundária; indica AC natural armor e omite natação)",
      "url": "https://www.robinloft.com/monsters/ahu-nixta-cataphact/tome-of-beasts-2"
    },
    {
      "titulo": "KPOGL, wiki comunitária não endossada pela editora; transcrição secundária com deslocamento de natação",
      "url": "https://kpogl.wikidot.com/monster:ahu-nixta-cataphact"
    }
  ],
  "classe_fonte": "O índice oficial confirma nome, variante, edição, publicação, porte, tipo e ND. A página 5eSRD associada exige JavaScript; a mecânica foi resumida da wiki comunitária KPOGL, que declara não ser endossada pela Kobold Press. D&D Grove e Robinloft omitem natação; Robinloft também diverge na descrição da CA (natural armor versus clockwork armor). O índice oficial não resolve essas diferenças mecânicas.",
  "completa": true,
  "variante": "Ahu-Nixta Cataphract, D&D 5e, Tome of Beasts 2; não confundir com Ahu-Nixta nem Ahu-Nixta Drudge.",
  "atributos": {
    "FOR": {
      "valor": 20,
      "modificador": 5
    },
    "DES": {
      "valor": 8,
      "modificador": -1
    },
    "CON": {
      "valor": 14,
      "modificador": 2
    },
    "INT": {
      "valor": 19,
      "modificador": 4
    },
    "SAB": {
      "valor": 13,
      "modificador": 1
    },
    "CAR": {
      "valor": 10,
      "modificador": 0
    }
  },
  "iniciativa": {
    "modificador_base_des": -1,
    "valor_formatado": "-1",
    "origem": "derivada do modificador de Destreza; fonte não informa bônus adicional"
  },
  "fonte_url": "https://kpogl.wikidot.com/monster:ahu-nixta-cataphact",
  "data_verificacao": "2026-10-10",
  "secoes_cobertas": [
    "identidade",
    "porte",
    "tipo",
    "ND",
    "CA",
    "PV e fórmula",
    "deslocamento",
    "atributos e modificadores",
    "salvaguardas",
    "perícias",
    "sentidos",
    "idiomas",
    "defesas",
    "traços",
    "ações",
    "recursos e recargas",
    "CDs e condições"
  ],
  "secoes_nao_listadas_na_fonte": [
    "salvaguardas",
    "resistências de dano",
    "vulnerabilidades de dano",
    "ações bônus",
    "reações",
    "ações lendárias",
    "ações míticas",
    "ações de covil"
  ],
  "transcricao_integral": false,
  "observacao_direitos": "Fatos mecânicos e resumo próprio; sem reprodução integral da redação externa."
}
```

## Atenção

Este material **não é ficha integral homologada**. As informações foram preservadas como pesquisa, sem inventar campos ou poderes ausentes.
