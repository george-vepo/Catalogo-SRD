# FICHA — Chelicerae (ordem 24/40)

**Tipo:** Aberração | **ND:** 7 | **Raridade:** Incomum | **ID:** TF-010

**Fonte:** Tome of Beasts 1
**URL de referência:** https://www.5esrd.com/database/creature/chelicerae-3pp/
**Origem:** Catálogo 607
**Situação documental:** PESQUISA MECÂNICA INDIVIDUAL — não homologada

## Atributos principais localizados

- CA: 16
- PV: 153
- Iniciativa: Não confirmado

## Suporte candidato

**Magical Discharge (D)** — Dano

Destreza CD 15; 8d8 força, metade no sucesso.

**Ressalva:** Edição revisada versus original: não misturar; recarga especial.

## Informações mecânicas extraídas das pesquisas

```json
{
  "traits": [
    {
      "name": "Magic Resistance",
      "category": "passive",
      "previous_summary_for_context": "Vantagem em salvaguardas contra magias e efeitos m?gicos.",
      "status": "PENDENTE_ESTRUTURACAO_INTEGRAL",
      "attack_bonus": null,
      "range": null,
      "target": null,
      "damage": null,
      "save_dc": null,
      "save_ability": null,
      "conditions": null,
      "duration": null,
      "recharge": null,
      "trigger": null,
      "uses": null
    },
    {
      "name": "Spider Climb",
      "category": "passive",
      "previous_summary_for_context": "Escala superf?cies dif?ceis e tetos sem teste.",
      "status": "PENDENTE_ESTRUTURACAO_INTEGRAL",
      "attack_bonus": null,
      "range": null,
      "target": null,
      "damage": null,
      "save_dc": null,
      "save_ability": null,
      "conditions": null,
      "duration": null,
      "recharge": null,
      "trigger": null,
      "uses": null
    }
  ],
  "actions": [
    {
      "name": "Multiattack",
      "category": "action",
      "previous_summary_for_context": "Um Bite e dois Claws; pode substituir Bite por Spellcasting.",
      "status": "PENDENTE_ESTRUTURACAO_INTEGRAL",
      "attack_bonus": null,
      "range": null,
      "target": null,
      "damage": null,
      "save_dc": null,
      "save_ability": null,
      "conditions": null,
      "duration": null,
      "recharge": null,
      "trigger": null,
      "uses": null
    },
    {
      "name": "Bite",
      "category": "action",
      "previous_summary_for_context": "Ataque +9, alcance 5 ft., 2d10+6 perfurante; Constitui??o CD 15 contra envenenamento e inconsci?ncia; pode agarrar alvo M?dio ou menor, escape CD 15.",
      "status": "PENDENTE_ESTRUTURACAO_INTEGRAL",
      "attack_bonus": null,
      "range": null,
      "target": null,
      "damage": null,
      "save_dc": null,
      "save_ability": null,
      "conditions": null,
      "duration": null,
      "recharge": null,
      "trigger": null,
      "uses": null
    },
    {
      "name": "Claw",
      "category": "action",
      "previous_summary_for_context": "Ataque +9, alcance 10 ft., 2d8+6 cortante.",
      "status": "PENDENTE_ESTRUTURACAO_INTEGRAL",
      "attack_bonus": null,
      "range": null,
      "target": null,
      "damage": null,
      "save_dc": null,
      "save_ability": null,
      "conditions": null,
      "duration": null,
      "recharge": null,
      "trigger": null,
      "uses": null
    },
    {
      "name": "Magical Discharge",
      "category": "action",
      "previous_summary_for_context": "Recarga especial: Destreza CD 15 em 15 ft., 8d8 force (metade no sucesso). Recarrega ao sifonar magia ou descansar.",
      "status": "PENDENTE_ESTRUTURACAO_INTEGRAL",
      "attack_bonus": null,
      "range": null,
      "target": null,
      "damage": null,
      "save_dc": null,
      "save_ability": null,
      "conditions": null,
      "duration": null,
      "recharge": null,
      "trigger": null,
      "uses": null
    },
    {
      "name": "Spellcasting",
      "category": "action",
      "previous_summary_for_context": "Intelig?ncia CD 15, ? vontade mage hand/minor illusion; 1/dia cada haste, hold person, invisibility e phantasmal killer.",
      "status": "PENDENTE_ESTRUTURACAO_INTEGRAL",
      "attack_bonus": null,
      "range": null,
      "target": null,
      "damage": null,
      "save_dc": null,
      "save_ability": null,
      "conditions": null,
      "duration": null,
      "recharge": null,
      "trigger": null,
      "uses": null
    }
  ],
  "bonus_actions": [
    {
      "name": "Nimble Moves",
      "category": "bonus_action",
      "previous_summary_for_context": "Dash ou Disengage como a??o b?nus.",
      "status": "PENDENTE_ESTRUTURACAO_INTEGRAL",
      "attack_bonus": null,
      "range": null,
      "target": null,
      "damage": null,
      "save_dc": null,
      "save_ability": null,
      "conditions": null,
      "duration": null,
      "recharge": null,
      "trigger": null,
      "uses": null
    },
    {
      "name": "Siphon Magic",
      "category": "bonus_action",
      "previous_summary_for_context": "Conjurador agarrado faz INT CD 15 ou perde espa?o de magia de n?vel m?ximo dispon?vel; Chelicerae recupera uso de Spellcasting.",
      "status": "PENDENTE_ESTRUTURACAO_INTEGRAL",
      "attack_bonus": null,
      "range": null,
      "target": null,
      "damage": null,
      "save_dc": null,
      "save_ability": null,
      "conditions": null,
      "duration": null,
      "recharge": null,
      "trigger": null,
      "uses": null
    }
  ],
  "reactions": null,
  "legendary_actions": null,
  "lair_actions": null,
  "spellcasting": null,
  "other": null
}
```

## Estatísticas adicionais da pesquisa individual

```json
{
  "armor_class": 16,
  "hit_points": 153,
  "hit_dice": "18d10+54",
  "ability_scores": {
    "STR": 22,
    "DEX": 17,
    "CON": 17,
    "INT": 18,
    "WIS": 15,
    "CHA": 14
  },
  "speeds": "andar 40 ft., escalar 30 ft.",
  "senses": [
    "darkvision 60 ft."
  ],
  "skills": {
    "Acrobatics": 6,
    "Athletics": 9,
    "Perception": 5,
    "Stealth": 6
  },
  "saving_throws": {
    "CHA": 5,
    "DEX": 6,
    "WIS": 5
  },
  "languages": [
    "entende Common mas n?o fala"
  ],
  "damage_resistances": null,
  "damage_immunities": [
    "poison"
  ],
  "damage_vulnerabilities": null,
  "condition_immunities": [
    "charmed",
    "poisoned"
  ]
}
```

## Atenção

Este material **não é ficha integral homologada**. As informações foram preservadas como pesquisa, sem inventar campos ou poderes ausentes.
