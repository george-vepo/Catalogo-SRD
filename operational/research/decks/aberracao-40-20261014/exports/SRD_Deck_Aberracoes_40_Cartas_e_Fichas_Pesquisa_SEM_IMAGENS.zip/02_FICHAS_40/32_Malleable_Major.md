# FICHA — Malleable, Major (ordem 32/40)

**Tipo:** Aberração | **ND:** 10 | **Raridade:** Incomum | **ID:** TF-284

**Fonte:** Tome of Beasts 2
**URL de referência:** https://koboldpress.com/tools/kobold-press-monsters/
**Origem:** Catálogo 607
**Situação documental:** PESQUISA MECÂNICA INDIVIDUAL — não homologada

## Atributos principais localizados

- CA: 13
- PV: 218
- Iniciativa: -1 (mod. DES; derivado)

## Suporte candidato

**Flesh Tendril (D/E)** — Misto (Dano e Debuff; principal a revisar)

+10, 4d6+6 contundente e possível Agarrado.

**Ressalva:** Evita bônus de absorção psíquica muito situacional.

## Informações mecânicas extraídas das pesquisas

```json
{
  "traits": [
    {
      "name": "Absorb Malleable",
      "category": "absorption",
      "action_economy": "bonus_action",
      "requires_target": {
        "one_of": [
          "minor_malleable",
          "moderate_malleable"
        ],
        "within_ft": 5
      },
      "effect": {
        "consume_target": true,
        "heal_hit_points": "target_current_hit_points",
        "inherit_targets_conditions_spells_and_magical_effects": true
      }
    },
    {
      "name": "Amorphous",
      "category": "movement",
      "minimum_passable_gap_inches": 1,
      "no_squeezing": true
    },
    {
      "name": "Controlled Mutability",
      "category": "transformation",
      "external_changes_end": "end_of_malleable_next_turn",
      "self_change_action": "action",
      "self_choose_any_shape": true,
      "retains_flesh_inside_out": true,
      "does_not_gain_other_creatures_statistics_or_abilities": true
    },
    {
      "name": "Psychic Absorption",
      "category": "psychic_damage_to_healing",
      "trigger": "subjected_to_psychic_damage",
      "damage_taken": 0,
      "heal": "the_psychic_damage_value_that_would_be_taken"
    },
    {
      "name": "Spider Climb",
      "category": "movement",
      "climb_difficult_surfaces_and_ceiling_without_check": true
    }
  ],
  "actions": [
    {
      "name": "Multiattack",
      "category": "multiattack",
      "action_economy": "action",
      "sequence": [
        {
          "attack": "Flesh Tendril",
          "count": 3
        }
      ]
    },
    {
      "name": "Flesh Tendril",
      "category": "attack",
      "action_economy": "action",
      "attack_type": "melee_weapon",
      "attack_bonus": 10,
      "reach_ft": 10,
      "targets": {
        "count": 1
      },
      "hit": {
        "damage": [
          {
            "dice": "4d6",
            "flat": 6,
            "average": 20,
            "type": "bludgeoning"
          }
        ],
        "grapple": {
          "target_max_size": "Huge",
          "escape_dc": 16
        }
      }
    },
    {
      "name": "Psychic Drain",
      "category": "target_save",
      "action_economy": "action",
      "precondition": "one_creature_grappled_by_malleable",
      "save": {
        "ability": "INT",
        "dc": 16,
        "on_failure": {
          "damage": [
            {
              "dice": "10d8",
              "type": "psychic",
              "average": 45
            }
          ]
        },
        "on_success": {
          "damage_multiplier": 0.5
        }
      },
      "secondary_effect": {
        "reduce_max_hp_by": "actual_psychic_damage_taken",
        "duration": "until_long_rest",
        "if_hp_max_becomes_0": {
          "dies": true,
          "becomes": "minor_malleable"
        }
      }
    },
    {
      "name": "Join Malleables",
      "category": "fusion",
      "action_economy": "action",
      "required_actors": "participants_all_use_actions_simultaneously_within_10ft",
      "options": [
        {
          "participants": 2,
          "each": "major_malleable",
          "result": "massive_malleable"
        }
      ],
      "effect": {
        "new_hp": "sum_current_hp_of_all_fused_creatures",
        "inherit": "all_conditions_spells_and_magical_effects",
        "initiative": "participants_initiative",
        "spawn_space": "one_previous_participant_location"
      }
    },
    {
      "name": "Separate Malleables",
      "category": "split",
      "action_economy": "action",
      "choose_exactly_one": [
        {
          "result_creature": "minor_malleable",
          "count": 8,
          "hp_each": "floor(current_hp/8)"
        },
        {
          "result_creature": "moderate_malleable",
          "count": 2,
          "hp_each": "floor(current_hp/2)"
        }
      ],
      "inherit": "all_conditions_spells_and_magical_effects",
      "initiative": "original_creature",
      "spawn_spaces": "unoccupied_spaces_previously_occupied_by_original_creature"
    }
  ],
  "bonus_actions": [
    {
      "name": "Absorb Malleable",
      "category": "absorption",
      "action_economy": "bonus_action",
      "targets": [
        "minor_malleable",
        "moderate_malleable"
      ],
      "range_ft": 5
    }
  ],
  "reactions": [
    {
      "name": "Sudden Separation",
      "category": "split_reaction",
      "action_economy": "reaction",
      "trigger": "single_attack_causes_20_or_more_damage",
      "may_use": "Separate Malleables",
      "triggering_damage_distribution": "divide_evenly_among_resulting_creatures",
      "odd_damage_rounding": null
    }
  ],
  "legendary_actions": [],
  "lair_actions": [],
  "mythic_actions": [],
  "spellcasting": [],
  "other": [
    {
      "name": "Cross-record dependency",
      "category": "fusion_cards",
      "ids": [
        "TF-274",
        "TF-276",
        "TF-286"
      ]
    }
  ]
}
```

## Estatísticas adicionais da pesquisa individual

```json
{
  "armor_class": 13,
  "hit_points": 218,
  "hit_dice": "23d12+69",
  "ability_scores": {
    "STR": 22,
    "DEX": 8,
    "CON": 17,
    "INT": 19,
    "WIS": 16,
    "CHA": 10
  },
  "speeds": {
    "walk_ft": 40,
    "climb_ft": 40
  },
  "senses": {
    "blindsight_ft": 90,
    "blind_beyond_blindsight": true,
    "passive_perception": 13
  },
  "skills": [],
  "saving_throws": {
    "INT": 8,
    "WIS": 7,
    "CHA": 4
  },
  "languages": {
    "spoken": "all_languages",
    "telepathy_ft": 120
  },
  "damage_resistances": [],
  "damage_immunities": [
    "psychic"
  ],
  "damage_vulnerabilities": [],
  "condition_immunities": [
    "blinded",
    "prone"
  ],
  "armor_class_type": "natural_armor",
  "ability_modifiers": {
    "STR": 6,
    "DEX": -1,
    "CON": 3,
    "INT": 4,
    "WIS": 3,
    "CHA": 0
  }
}
```

## Atenção

Este material **não é ficha integral homologada**. As informações foram preservadas como pesquisa, sem inventar campos ou poderes ausentes.
