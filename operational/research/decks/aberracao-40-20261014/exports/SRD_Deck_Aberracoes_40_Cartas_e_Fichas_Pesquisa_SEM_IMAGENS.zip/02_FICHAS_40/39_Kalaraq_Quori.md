# FICHA — Kalaraq Quori (ordem 39/40)

**Tipo:** Aberração | **ND:** 19 | **Raridade:** Lendária | **ID:** sem ID aprovado

**Fonte:** Eberron: Rising from the Last War
**URL de referência:** https://www.dndbeyond.com/monsters?page=177&sort=-type
**Origem:** Candidata externa (não aprovada)
**Situação documental:** FICHA EXTERNA NÃO INTEGRADA

## Atributos principais localizados

- CA: Não confirmado
- PV: Não confirmado
- Iniciativa: Não confirmado

## Suporte candidato

**Swarm of Eyes (E/D)** — Misto (Dano e Debuff; principal a revisar)

Sabedoria CD 21; 10d8 psíquico e possível Cego.

**Ressalva:** Ficha externa Eberron não integrada; recarga 6, novos testes.

## Informações mecânicas extraídas das pesquisas

Nenhum bloco mecânico integral foi localizado nos arquivos incluídos.

## Atenção

Este material **não é ficha integral homologada**. As informações foram preservadas como pesquisa, sem inventar campos ou poderes ausentes.
