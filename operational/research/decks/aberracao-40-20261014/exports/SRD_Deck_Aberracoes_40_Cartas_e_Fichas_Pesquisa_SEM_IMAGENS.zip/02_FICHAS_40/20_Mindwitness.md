# FICHA — Mindwitness (ordem 20/40)

**Tipo:** Aberração | **ND:** 5 | **Raridade:** Comum | **ID:** sem ID aprovado

**Fonte:** Volo's Guide to Monsters
**URL de referência:** https://www.dndbeyond.com/sources/dnd/vgtm
**Origem:** Candidata externa (não aprovada)
**Situação documental:** FICHA EXTERNA NÃO INTEGRADA

## Atributos principais localizados

- CA: Não confirmado
- PV: Não confirmado
- Iniciativa: Não confirmado

## Suporte candidato

**Eye Rays (E/D)** — Misto (Dano e Debuff; principal a revisar)

Três raios aleatórios com efeitos de controle/dano.

**Ressalva:** Ficha externa Volo não integrada; fixar sorteio e edição.

## Informações mecânicas extraídas das pesquisas

Nenhum bloco mecânico integral foi localizado nos arquivos incluídos.

## Atenção

Este material **não é ficha integral homologada**. As informações foram preservadas como pesquisa, sem inventar campos ou poderes ausentes.
