# Proveniência

Imagens reutilizadas de caminhos já versionados em george-vepo/Catalogo-SRD; reempacotamento NÃO aprova adequação visual, licença ou distribuição externa. Confirmar situação antes de reuso público.

Registros de ficha selecionados do arquivo `docs/catalogo/data/fichas-607.json` da branch main. Somente entradas com `status_ficha=FICHA INTEGRAL LOCAL` e texto integral real representam fichas completas; outras são índices parciais. O JSON fornecido pelo usuário mantém atributos resumidos e links de pesquisa, não se torna automaticamente ficha oficial. Arte não é ficha e não estabelece mecânica.
